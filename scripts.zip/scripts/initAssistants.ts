
import { initializeApp, cert } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
// Make sure to provide your service account key by creating this file
// import serviceAccount from "./serviceAccountKey.json"; 

// Mock service account for type correctness. Replace with your actual key.
const serviceAccount = {
    type: "service_account",
    project_id: "your-project-id",
    private_key_id: "your-private-key-id",
    private_key: "your-private-key",
    client_email: "your-client-email",
    client_id: "your-client-id",
    auth_uri: "https://accounts.google.com/o/oauth2/auth",
    token_uri: "https://oauth2.googleapis.com/token",
    auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    client_x509_cert_url: "your-client-cert-url"
};


initializeApp({
  // @ts-ignore
  credential: cert(serviceAccount)
});

const db = getFirestore();

const assistants = [
  {
    id: "leila",
    name: "ليلى",
    role: "مساعدة استقبال ومبيعات",
    visible: true,
    language: "ar",
    entrypoint: "pre_login",
    access: ["public", "sales"],
    promptStyle: "ودود، واضح، مشجع"
  },
  {
    id: "sally",
    name: "سالي",
    role: "مديرة تنفيذية واستشارية",
    visible: true,
    language: "ar",
    entrypoint: "post_login",
    access: ["marketing", "review", "admin"],
    promptStyle: "تحليلي، استشاري، رسمي"
  },
  {
    id: "infinity",
    name: "إنفينيتي",
    role: "دعم فني للمنصة",
    visible: true,
    language: "ar",
    entrypoint: "post_login",
    access: ["support", "tech"],
    promptStyle: "محايد، تقني، سريع"
  },
  {
    id: "noura",
    name: "نورا",
    role: "مساعد داخلي للتحليل والتخطيط",
    visible: true,
    language: "ar,en",
    entrypoint: "dashboard",
    access: ["internal", "analytics"],
    promptStyle: "تحليلي، دقيق، موجه للنتائج"
  },
  {
    id: "k",
    name: "K",
    role: "مدير مشروع تفاعلي لصاحب العمل",
    visible: false,
    entrypoint: "background",
    access: ["owner", "suggestions"],
    promptStyle: "ذكي، شخصي، مبادر"
  },
  {
    id: "k2",
    name: "K2",
    role: "نظام إداري مشترك",
    visible: false,
    entrypoint: "background",
    access: ["shared_memory", "team"],
    promptStyle: "تنسيقي، خلفي، شامل"
  },
  {
    id: "ki_researcher1",
    name: "KI الباحث 1",
    role: "باحث خارجي",
    visible: false,
    entrypoint: "on_demand",
    access: ["external_search"],
    promptStyle: "تحقيقي، عالمي"
  },
  {
    id: "ki_researcher2",
    name: "KI الباحث 2",
    role: "محلل داخلي للبيانات",
    visible: false,
    entrypoint: "realtime",
    access: ["internal_analytics"],
    promptStyle: "مرجعي، باطني"
  },
  {
    id: "ki_executor",
    name: "KI Executor",
    role: "منفّذ مهام (كود / صور / محتوى)",
    visible: false,
    entrypoint: "auto",
    access: ["code", "content", "images"],
    promptStyle: "وظيفي، مباشر"
  }
];

// Add default brand identity
const defaultCompany = {
    id: "alkayan-infinity",
    companyName: "انفنتي الكيان",
    companyDescription: "للتكنولوجيا الحديثة والتسويق الرقمي والدعايه والاعلان. اهلا بيك فالمستقبل",
    knowledgeBase: "نحن نقدم باقات متنوعة تشمل التسويق الرقمي، تصميم الهوية البصرية، وإدارة حسابات التواصل. نستهدف الشركات الناشئة والمتوسطة في السعودية. يجب أن تكون جميع المخرجات باللغة العربية الفصحى وبنبرة احترافية.",
    tone: "احترافي",
    style: "إقناعي",
    language: "ar",
    logoUrl: "",
    assistants: assistants,
    legalInfo: {
        legalName: "",
        address: "",
        taxId: "",
        registrationNumber: ""
    },
    bankingInfo: {
        bankName: "",
        accountNumber: "",
        iban: ""
    },
    aiPolicy: {
        reviewRequired: true,
        enableImages: false,
        enableCodeGeneration: false,
        guardLevel: "high",
    },
};

async function init() {
  const batch = db.batch();

  // Set the assistants in their own collection
  assistants.forEach((a) => {
    const ref = db.collection("assistants").doc(a.id);
    batch.set(ref, a);
  });

  // Set the default company with the assistants embedded
  const companyRef = db.collection("companies").doc(defaultCompany.id);
  batch.set(companyRef, defaultCompany);

  await batch.commit();
  console.log("✅ Default company and assistants have been successfully set in Firestore.");
}

init().catch(console.error);
