
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { LeilaChat } from '@/components/landing/leila-chat';
import { Logo } from '@/components/icons/logo';
import { ArrowLeft } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen bg-white dark:bg-black">
      <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between p-4 bg-white/80 dark:bg-black/80 backdrop-blur-sm">
        <Logo />
        <Button asChild>
          <Link href="/login">
            تسجيل الدخول
            <ArrowLeft className="mr-2 h-4 w-4" />
          </Link>
        </Button>
      </header>

      <main className="flex-grow pt-24 pb-12">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-4 text-center lg:text-right">
              <h1 className="text-4xl md:text-6xl font-bold tracking-tighter text-black dark:text-white font-headline">
                انفنتي الكيان
              </h1>
              <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto lg:mx-0">
                للتكنولوجيا الحديثة والتسويق الرقمي والدعايه والاعلان
              </p>
               <p className="text-2xl md:text-3xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto lg:mx-0">
                اهلا بيك فالمستقبل
              </p>
               <p className="text-2xl md:text-3xl text-gray-800 dark:text-gray-100 font-bold tracking-wider max-w-2xl mx-auto lg:mx-0">
                01062916666
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-end pt-4">
                <Button size="lg" asChild>
                  <Link href="/login">
                    ابدأ الآن
                    <ArrowLeft className="mr-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="#leila">
                    تحدث إلى ليلى
                  </Link>
                </Button>
              </div>
            </div>

            <div id="leila" className="w-full max-w-md mx-auto lg:mx-0">
               <LeilaChat />
            </div>
          </div>
        </div>
      </main>

       <footer className="py-6 bg-gray-50 dark:bg-gray-900/50">
        <div className="container mx-auto px-4 text-center text-sm text-gray-500 dark:text-gray-400">
          <p>&copy; 2025 Infinity Alkayan. All Rights Reserved.</p>
          <p className="mt-1">Alkayan Marketing Agency &reg; 2020-2025</p>
        </div>
      </footer>
    </div>
  );
}
