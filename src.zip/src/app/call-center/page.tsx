

'use client'

import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, Send, Bot, User, ArrowLeft, ShieldQuestion, Mic, UserCheck, FileEdit, UserPlus, Ticket, FileText, Star, MessageSquarePlus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ThumbsDown, ThumbsUp, MessageSquareWarning, Clock, CircleCheck } from "lucide-react";


type ConversationType = 'client';

const conversations: { id: string; name: string; avatar: string; lastMessage: string; time: string; unread: number; type: ConversationType, assistant: string; status: 'in-progress' | 'review' | 'closed', clientInfo: { status: string; requests: number; } }[] = [
    { id: 'CONV001', name: 'أحمد العلي (عميل)', avatar: 'https://placehold.co/100x100.png?text=A', lastMessage: 'تمام، في الانتظار.', time: '10:45 ص', unread: 2, type: 'client', assistant: 'سالي', status: 'in-progress', clientInfo: { status: 'عميل حالي', requests: 5 } },
    { id: 'CONV005', name: 'نورة سالم (عميل)', avatar: 'https://placehold.co/100x100.png?text=N', lastMessage: 'شكرًا ليلى، هذا مفيد جدًا!', time: '11:20 ص', unread: 0, type: 'client', assistant: 'ليلى', status: 'review', clientInfo: { status: 'عميل جديد', requests: 1 } },
    { id: 'CONV006', name: 'ياسر أمين (عميل)', avatar: 'https://placehold.co/100x100.png?text=Y', lastMessage: 'تم حل المشكلة، شكرًا.', time: 'أمس', unread: 0, type: 'client', assistant: 'سالي', status: 'closed', clientInfo: { status: 'عميل مخلص', requests: 12 } },
];

const initialMessages: { [key: string]: any[] } = {
    'CONV001': [
        { id: 'MSG01', role: 'other', content: 'مرحباً، هل تم الانتهاء من التعديلات على الشعار؟', time: '10:30 ص', sender: 'أحمد العلي' },
        { id: 'MSG02a', role: 'me-assistant', content: 'أهلاً أحمد، فريق التصميم يعمل عليها الآن. سأوافيك بالتحديثات فوراً.', time: '10:34 ص', sender: 'سالي' },
        { id: 'MSG04', role: 'other', content: 'تمام، في الانتظار.', time: '10:45 ص', sender: 'أحمد العلي' },
    ],
    'CONV005': [
        { id: 'MSG10', role: 'other', content: 'مرحباً، أود الاستفسار عن باقة التسويق الرقمي.', time: '11:15 ص', sender: 'نورة سالم' },
        { id: 'MSG11', role: 'assistant', content: 'أهلاً بكِ نورة، أنا ليلى. باقة التسويق الرقمي تشمل إدارة حملات التواصل الاجتماعي ومحركات البحث. هل لديكِ أي أسئلة محددة عنها؟', time: '11:16 ص', sender: 'ليلى' },
        { id: 'MSG12', role: 'other', content: 'نعم، كم عدد المنصات التي تتم إدارتها في الباقة؟', time: '11:18 ص', sender: 'نورة سالم' },
        { id: 'MSG13', role: 'assistant', content: 'الباقة تشمل إدارة 3 منصات من اختيارك. هل تودين معرفة المزيد؟', time: '11:19 ص', sender: 'ليلى' },
        { id: 'MSG14', role: 'other', content: 'شكرًا ليلى، هذا مفيد جدًا!', time: '11:20 ص', sender: 'نورة سالم' },
    ],
    'CONV006': [
         { id: 'MSG20', role: 'other', content: 'لدي مشكلة في الوصول للحساب.', time: '12:00 م', sender: 'ياسر أمين' },
         { id: 'MSG21', role: 'me-assistant', content: 'أهلاً ياسر، تم إعادة تعيين كلمة المرور. هل يمكنك المحاولة الآن؟', time: '12:05 م', sender: 'سالي' },
         { id: 'MSG22', role: 'other', content: 'تم حل المشكلة، شكرًا.', time: '12:10 م', sender: 'ياسر أمين' },
    ]
};

const teamMembers = [
    { id: 'TM01', name: 'فاطمة السيد' },
    { id: 'TM02', name: 'خالد المصري' },
];

const assistants = [
    { id: 'leila', name: 'ليلى' },
    { id: 'sally', name: 'سالي' },
];

const aiCoachingFeedback = {
    isApproved: false,
    feedback: "النبرة جيدة ولكن الرد يفتقر إلى التعاطف. حاول أن تكون أكثر تفهمًا لمشكلة العميل.",
    suggestedImprovement: "أتفهم تمامًا إحباطك أستاذ أحمد. فريقنا يعمل بأقصى سرعة على طلبك وسأحرص شخصيًا على إعلامك بالتحديثات أولًا بأول. شكرًا لصبرك."
}

type MessageRole = 'me' | 'other' | 'assistant' | 'me-assistant' | 'whisper';
type ConversationStatus = 'in-progress' | 'review' | 'closed';

const statusConfig: { [key in ConversationStatus]: { text: string, icon: React.ElementType, color: string } } = {
    'in-progress': { text: 'قيد التنفيذ', icon: Clock, color: 'text-blue-500' },
    'review': { text: 'تحتاج مراجعة', icon: MessageSquareWarning, color: 'text-yellow-500' },
    'closed': { text: 'مغلقة', icon: CircleCheck, color: 'text-green-500' },
}


export default function CallCenterPage() {
    const [selectedConversation, setSelectedConversation] = useState(conversations[0]);
    const [messages, setMessages] = useState<any[]>(initialMessages[conversations[0].id]);
    const [newMessage, setNewMessage] = useState('');
    const [whisperMessage, setWhisperMessage] = useState('');
    const [isSupervisorMode, setIsSupervisorMode] = useState(false);


    const handleSelectConversation = (conv: typeof conversations[0]) => {
        setSelectedConversation(conv);
        setMessages(initialMessages[conv.id] || []);
        setIsSupervisorMode(false);
    }

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !selectedConversation) return;
        const newMsg = {
            id: `MSG${Date.now()}`,
            role: isSupervisorMode ? 'me' : 'me-assistant' as const,
            sender: isSupervisorMode ? 'المشرف' : selectedConversation.assistant,
            content: newMessage,
            time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
        };
        setMessages([...messages, newMsg]);
        setNewMessage('');
    }
    
    const handleSendWhisper = (e: React.FormEvent) => {
        e.preventDefault();
        if (!whisperMessage.trim() || !selectedConversation) return;
        const newMsg = {
            id: `WSP${Date.now()}`,
            role: 'whisper' as const,
            content: whisperMessage,
            sender: 'المشرف',
            time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
        };
        setMessages([...messages, newMsg]);
        setWhisperMessage('');
    }

    const getMessageAvatar = (role: MessageRole, sender?: string) => {
        const fallback = sender ? sender.charAt(0) : 'U';
        switch (role) {
            case 'me-assistant':
            case 'me':
                return <AvatarImage src="https://placehold.co/100x100.png" alt="User" data-ai-hint="person" />;
            case 'assistant':
                return <AvatarFallback><Bot size={18} /></AvatarFallback>;
            default:
                return (
                    <>
                        <AvatarImage src={selectedConversation.avatar} alt={selectedConversation.name} data-ai-hint="person" />
                        <AvatarFallback>{fallback}</AvatarFallback>
                    </>
                );
        }
    }


    return (
        <TooltipProvider>
            <div className="h-screen flex flex-col bg-background">
                <header className="p-4 border-b flex items-center justify-between shrink-0">
                    <div className="flex items-center gap-4">
                        <Button variant="outline" size="icon" asChild>
                            <Link href="/dashboard">
                                <ArrowLeft className="h-4 w-4" />
                            </Link>
                        </Button>
                        <div>
                            <h1 className="text-xl font-bold tracking-tight font-headline">مركز الاتصال الذكي</h1>
                            <p className="text-sm text-muted-foreground">مراقبة، توجيه، وتدريب تفاعلات العملاء مع المساعدين.</p>
                        </div>
                    </div>
                </header>
                <div className="flex-grow grid grid-cols-1 md:grid-cols-12 h-[calc(100vh-73px)] overflow-hidden">
                    {/* Conversations List */}
                    <div className="md:col-span-4 lg:col-span-3 border-l flex flex-col bg-muted/20">
                        <div className="p-4 border-b shrink-0">
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input placeholder="بحث في محادثات العملاء..." className="pr-9 bg-background" />
                            </div>
                        </div>
                        <ScrollArea className="flex-grow">
                            {conversations.map(conv => {
                                const StatusIcon = statusConfig[conv.status].icon;
                                return (
                                    <div key={conv.id}
                                        className={cn(
                                            "flex items-start gap-3 p-4 cursor-pointer border-b hover:bg-muted/50",
                                            selectedConversation?.id === conv.id && "bg-muted"
                                        )}
                                        onClick={() => handleSelectConversation(conv)}
                                    >
                                        <Avatar className="h-12 w-12 border-2" data-ai-hint="person">
                                            <AvatarImage src={conv.avatar} alt={conv.name} />
                                            <AvatarFallback>{conv.name.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1 overflow-hidden">
                                            <div className="flex justify-between items-center">
                                                <p className="font-semibold truncate">{conv.name}</p>
                                                <p className="text-xs text-muted-foreground shrink-0">{conv.time}</p>
                                            </div>
                                            <div className="flex justify-between items-center mt-1">
                                                <p className="text-sm text-muted-foreground truncate">{conv.lastMessage}</p>
                                                {conv.unread > 0 && <Badge className="w-5 h-5 flex items-center justify-center p-0 shrink-0">{conv.unread}</Badge>}
                                            </div>
                                            <div className="flex items-center gap-4 mt-2">
                                                <Badge variant="outline" className="text-xs">
                                                    <Bot className="w-3 h-3 ml-1" />
                                                    {conv.assistant}
                                                </Badge>
                                                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                                    <StatusIcon className={`w-3 h-3 ${statusConfig[conv.status].color}`} />
                                                    <span>{statusConfig[conv.status].text}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })}
                        </ScrollArea>
                    </div>

                    {/* Chat Area & Control Panel */}
                    <div className="md:col-span-8 lg:col-span-9 flex h-full">
                        {selectedConversation ? (
                            <div className="flex-1 grid grid-cols-12 overflow-hidden h-full">
                                {/* Chat Display */}
                                <main className="col-span-12 lg:col-span-8 flex flex-col h-full bg-muted/10">
                                     <div className="p-4 border-b flex items-center justify-between gap-3 shrink-0 bg-background">
                                        <div className="flex items-center gap-3">
                                            <Avatar className="h-10 w-10">
                                                <AvatarImage src={selectedConversation.avatar} alt={selectedConversation.name} data-ai-hint="person" />
                                                <AvatarFallback>{selectedConversation.name.charAt(0)}</AvatarFallback>
                                            </Avatar>
                                            <div>
                                                <h2 className="text-lg font-semibold">{selectedConversation.name}</h2>
                                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                                    <Bot className="w-3 h-3" />
                                                    <span>تتم بواسطة {selectedConversation.assistant}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <ScrollArea className="flex-grow p-4">
                                        <div className="space-y-6">
                                            {messages.map((msg: any) => (
                                                <div key={msg.id} className={cn("flex items-end gap-3", msg.role === 'me-assistant' || msg.role === 'me' ? "justify-end" : "justify-start")}>
                                                    {(msg.role !== 'me-assistant' && msg.role !== 'me' && msg.role !== 'whisper') && (
                                                        <Avatar className="w-8 h-8">
                                                            {getMessageAvatar(msg.role, msg.sender)}
                                                        </Avatar>
                                                    )}
                                                    {msg.role === 'whisper' && (
                                                        <div className="w-full flex items-center justify-center my-2">
                                                            <div className="w-full max-w-md mx-auto p-2 rounded-md bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-200 text-sm flex items-center gap-2">
                                                                <Mic className="w-4 h-4" />
                                                                <div><span className="font-semibold">{msg.sender}:</span> {msg.content}</div>
                                                            </div>
                                                        </div>
                                                    )}
                                                    {msg.role !== 'whisper' && (
                                                        <div className="space-y-1 max-w-xs md:max-w-md">
                                                            <div className={cn(
                                                                "rounded-xl px-4 py-2 text-sm shadow-sm",
                                                                msg.role === 'me' ? 'bg-primary text-primary-foreground rounded-br-none'
                                                                    : msg.role === 'me-assistant' ? 'bg-secondary text-secondary-foreground rounded-br-none'
                                                                        : msg.role === 'assistant' ? 'bg-primary text-primary-foreground rounded-bl-none'
                                                                            : 'bg-background rounded-bl-none'
                                                            )}>
                                                                {msg.content}
                                                            </div>
                                                            <div className={cn("flex items-center gap-2 text-xs text-muted-foreground px-1", msg.role === 'me-assistant' || msg.role === 'me' ? 'justify-end' : 'justify-start')}>
                                                                {(msg.role === 'me-assistant' || msg.role === 'assistant') && <Bot className="w-3 h-3 text-blue-500" />}
                                                                {(msg.role === 'me-assistant' || msg.role === 'me' || msg.role === 'assistant') && <span className="font-medium text-xs">{msg.sender}</span>}
                                                                <span>{msg.time}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                    {(msg.role === 'me-assistant' || msg.role === 'me') && (
                                                        <Avatar className="w-8 h-8">
                                                           {getMessageAvatar(msg.role, msg.sender)}
                                                        </Avatar>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </ScrollArea>
                                    <div className="p-4 border-t bg-background shrink-0">
                                        <form onSubmit={handleSendMessage} className="relative">
                                            <Label htmlFor="newMessage" className="text-xs font-semibold text-muted-foreground">
                                                {isSupervisorMode ? 'أنت ترد الآن كمشرف مباشر' : `الرد بواسطة ${selectedConversation.assistant} (سيتم تحليله بواسطة المدرب K)`}
                                            </Label>
                                            <Textarea
                                                id="newMessage"
                                                placeholder="اكتب ردك هنا..."
                                                className="flex-1 pr-24 min-h-[60px] mt-1"
                                                value={newMessage}
                                                onChange={(e) => setNewMessage(e.target.value)}
                                            />
                                            <Button type="submit" size="icon" className="absolute left-3 bottom-3">
                                                <Send className="h-5 w-5" />
                                            </Button>
                                        </form>
                                    </div>
                                </main>

                                {/* Control Panel Sidebar */}
                                <aside className="col-span-12 lg:col-span-4 border-r flex flex-col bg-muted/30">
                                    <div className="p-4 border-b shrink-0 bg-background/50">
                                        <h2 className="text-lg font-semibold">لوحة التحكم</h2>
                                        <p className="text-sm text-muted-foreground">إدارة وتوجيه المحادثة</p>
                                    </div>
                                    <ScrollArea className="flex-grow p-4">
                                        <Accordion type="multiple" defaultValue={['item-1', 'item-2', 'item-3']} className="w-full space-y-4">
                                            <Card>
                                                <AccordionItem value="item-1" className="border-b-0">
                                                    <AccordionTrigger className="p-4">
                                                        <CardTitle className="text-base flex items-center gap-2">
                                                            <UserCheck className="w-5 h-5" />
                                                            معلومات العميل
                                                        </CardTitle>
                                                    </AccordionTrigger>
                                                    <AccordionContent className="px-4 pb-4">
                                                        <div className="space-y-2 text-sm">
                                                            <div className="flex justify-between">
                                                                <span className="text-muted-foreground">الحالة:</span>
                                                                <span className="font-medium">{selectedConversation.clientInfo.status}</span>
                                                            </div>
                                                            <div className="flex justify-between">
                                                                <span className="text-muted-foreground">الطلبات السابقة:</span>
                                                                <span className="font-medium">{selectedConversation.clientInfo.requests}</span>
                                                            </div>
                                                        </div>
                                                    </AccordionContent>
                                                </AccordionItem>
                                            </Card>

                                            <Card>
                                                 <AccordionItem value="item-2" className="border-b-0">
                                                    <AccordionTrigger className="p-4">
                                                        <CardTitle className="text-base">ملاحظات المدرب K</CardTitle>
                                                    </AccordionTrigger>
                                                    <AccordionContent className="px-4 pb-4 space-y-4">
                                                        <div className={cn("p-3 rounded-md text-sm", aiCoachingFeedback.isApproved ? "bg-green-100/60 dark:bg-green-900/40 text-green-900 dark:text-green-200" : "bg-yellow-100/60 dark:bg-yellow-900/40 text-yellow-900 dark:text-yellow-200")}>
                                                            <div className="font-semibold flex items-center gap-2">
                                                                {aiCoachingFeedback.isApproved ? <ThumbsUp className="w-4 h-4"/> : <ThumbsDown className="w-4 h-4"/>}
                                                                <span>{aiCoachingFeedback.isApproved ? "الرد معتمد" : "يحتاج تحسين"}</span>
                                                            </div>
                                                            <p className="mt-1">{aiCoachingFeedback.feedback}</p>
                                                        </div>

                                                        {!aiCoachingFeedback.isApproved && (
                                                            <div>
                                                                <Label className="text-xs font-semibold">الاقتراح:</Label>
                                                                <div className="p-3 mt-1 rounded-md bg-muted text-sm border">
                                                                    {aiCoachingFeedback.suggestedImprovement}
                                                                </div>
                                                            </div>
                                                        )}
                                                        <div className="flex gap-2">
                                                            <Button className="w-full" size="sm" variant="outline">
                                                                <FileEdit className="ml-2 h-4 w-4" />
                                                                تعديل الرد
                                                            </Button>
                                                            <Button className="w-full" size="sm">
                                                                <Send className="ml-2 h-4 w-4" />
                                                                {aiCoachingFeedback.isApproved ? 'إرسال' : 'استخدم الاقتراح'}
                                                            </Button>
                                                        </div>
                                                    </AccordionContent>
                                                </AccordionItem>
                                            </Card>
                                            
                                            <Card>
                                                <AccordionItem value="item-3" className="border-b-0">
                                                    <AccordionTrigger className="p-4">
                                                        <CardTitle className="text-base">إدارة المحادثة</CardTitle>
                                                    </AccordionTrigger>
                                                    <AccordionContent className="px-4 pb-4 space-y-4">
                                                        <div className="space-y-2">
                                                            <Label htmlFor="status">حالة المحادثة</Label>
                                                            <Select defaultValue={selectedConversation.status}>
                                                                <SelectTrigger id="status">
                                                                    <SelectValue placeholder="تغيير الحالة" />
                                                                </SelectTrigger>
                                                                <SelectContent>
                                                                    {Object.entries(statusConfig).map(([key, value]) => (
                                                                        <SelectItem key={key} value={key}>
                                                                            <div className="flex items-center gap-2">
                                                                                <value.icon className={`w-4 h-4 ${value.color}`} />
                                                                                <span>{value.text}</span>
                                                                            </div>
                                                                        </SelectItem>
                                                                    ))}
                                                                </SelectContent>
                                                            </Select>
                                                        </div>
                                                        <Separator />
                                                        <form onSubmit={handleSendWhisper} className="space-y-2">
                                                            <Label htmlFor="whisper" className="text-sm">توجيه للموظف (لا يراه العميل)</Label>
                                                            <div className="flex gap-2">
                                                                <Input id="whisper" placeholder="مثال: اسأله عن الميزانية..." value={whisperMessage} onChange={(e) => setWhisperMessage(e.target.value)} />
                                                                <Button type="submit" variant="secondary" size="icon"><Mic className="w-4 h-4" /></Button>
                                                            </div>
                                                        </form>
                                                        <Button className="w-full" variant={isSupervisorMode ? 'default' : 'outline'} onClick={() => setIsSupervisorMode(!isSupervisorMode)}>
                                                            <ShieldQuestion className="ml-2 h-4 w-4" />
                                                            {isSupervisorMode ? 'العودة لوضع المساعد' : 'تولي المحادثة كمشرف'}
                                                        </Button>
                                                    </AccordionContent>
                                                </AccordionItem>
                                            </Card>
                                            
                                            <Card>
                                                <AccordionItem value="item-4" className="border-b-0">
                                                    <AccordionTrigger className="p-4">
                                                        <CardTitle className="text-base">إجراءات سريعة</CardTitle>
                                                    </AccordionTrigger>
                                                    <AccordionContent className="px-4 pb-4">
                                                        <div className="grid grid-cols-2 gap-2">
                                                            <Button variant="outline" size="sm"><MessageSquarePlus className="w-4 h-4 ml-1" /> طلب معلومات</Button>
                                                            <Button variant="outline" size="sm"><Ticket className="w-4 h-4 ml-1" /> إنشاء تذكرة</Button>
                                                            <Button variant="outline" size="sm"><FileText className="w-4 h-4 ml-1" /> إرسال فاتورة</Button>
                                                            <Button variant="outline" size="sm"><Star className="w-4 h-4 ml-1" /> طلب تقييم</Button>
                                                        </div>
                                                    </AccordionContent>
                                                </AccordionItem>
                                            </Card>

                                        </Accordion>
                                    </ScrollArea>
                                </aside>
                            </div>
                        ) : (
                             <div className="col-span-12 flex items-center justify-center h-full text-muted-foreground">
                                <p>الرجاء تحديد محادثة لعرضها.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </TooltipProvider>
    );
}
