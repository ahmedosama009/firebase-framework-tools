import { LoginForm } from '@/components/auth/login-form';
import { Logo } from '@/components/icons/logo';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-black p-4">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8">
            <Link href="/" aria-label="العودة للصفحة الرئيسية">
              <Logo />
            </Link>
        </div>
        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-headline">مرحباً بعودتك</CardTitle>
            <CardDescription>
              سجل الدخول للمتابعة إلى انفنتي الكيان
            </CardDescription>
          </CardHeader>
          <CardContent>
            <LoginForm />
          </CardContent>
        </Card>
        <p className="mt-4 text-center text-sm text-muted-foreground">
          ليس لديك حساب؟{' '}
          <Link href="#" className="font-semibold text-accent hover:underline">
            أنشئ حساباً
          </Link>
        </p>
      </div>
    </div>
  );
}
