
'use client'

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Building, Users, Briefcase } from "lucide-react";
import { getCompanies, ICompanyData } from '@/lib/data/super-panel';
import { useRouter } from 'next/navigation';
import { useBrand } from '@/components/settings/brand-provider';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';

function CompanyCardSkeleton() {
    return (
        <Card>
            <CardHeader>
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2 mt-2" />
            </CardHeader>
            <CardContent className="space-y-3">
                <Skeleton className="h-5 w-full" />
                <Skeleton className="h-5 w-full" />
            </CardContent>
            <CardContent>
                 <Skeleton className="h-10 w-full" />
            </CardContent>
        </Card>
    )
}


export default function SuperPanelPage() {
    const [companies, setCompanies] = useState<ICompanyData[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const router = useRouter();
    const { setBrand } = useBrand();

    useEffect(() => {
        async function loadCompanies() {
            setIsLoading(true);
            try {
                const fetchedCompanies = await getCompanies();
                setCompanies(fetchedCompanies);
            } catch (error) {
                console.error("Failed to load companies:", error);
            } finally {
                setIsLoading(false);
            }
        }
        loadCompanies();
    }, []);

    const handleManageCompany = (company: ICompanyData) => {
        // Set the selected company's brand identity in the global context
        // This simulates "logging in" or "switching to" that company's view
        setBrand(company.brand);
        // Navigate to that company's dashboard
        router.push('/app/dashboard');
    };

    return (
        <div className="container mx-auto py-8 px-4">
            <header className="text-center mb-8">
                <h1 className="text-4xl font-bold tracking-tight font-headline">لوحة التحكم العليا</h1>
                <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">إدارة جميع الشركات والوكالات المسجلة في المنصة.</p>
            </header>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {isLoading ? (
                    [...Array(4)].map((_, i) => <CompanyCardSkeleton key={i} />)
                ) : (
                    companies.map((company) => (
                        <Card key={company.id} className="flex flex-col">
                            <CardHeader>
                                <div className="flex items-center gap-3">
                                    <div className="p-3 bg-muted rounded-full">
                                        <Building className="w-6 h-6 text-muted-foreground" />
                                    </div>
                                    <div>
                                        <CardTitle className="text-xl font-headline">{company.brand.companyName}</CardTitle>
                                        <CardDescription>ID: {company.id}</CardDescription>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="flex-grow space-y-3 text-sm">
                                <div className="flex items-center justify-between">
                                    <span className="text-muted-foreground flex items-center gap-2"><Briefcase className="w-4 h-4"/> العملاء</span>
                                    <span className="font-bold">{company.stats.clientCount}</span>
                                </div>
                                <div className="flex items-center justify-between">
                                     <span className="text-muted-foreground flex items-center gap-2"><Users className="w-4 h-4"/> أعضاء الفريق</span>
                                    <span className="font-bold">{company.stats.teamMemberCount}</span>
                                </div>
                            </CardContent>
                            <CardContent>
                                <Button className="w-full" onClick={() => handleManageCompany(company)}>
                                    <ArrowLeft className="mr-2 h-4 w-4" />
                                    إدارة الشركة
                                </Button>
                            </CardContent>
                        </Card>
                    ))
                )}
            </div>
        </div>
    );
}
