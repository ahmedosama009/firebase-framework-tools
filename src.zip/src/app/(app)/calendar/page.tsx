
'use client'

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, PlusCircle, CheckCircle, Clock, Briefcase } from "lucide-react";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, getDay, isToday } from "date-fns";
import { ar } from "date-fns/locale";
import { cn } from '@/lib/utils';

const eventTypes = {
  meeting: { label: 'اجتماع', color: 'bg-blue-500' },
  deadline: { label: 'موعد تسليم', color: 'bg-red-500' },
  task: { label: 'مهمة', color: 'bg-yellow-500' },
  personal: { label: 'شخصي', color: 'bg-green-500' },
};

const sampleEvents = [
  { date: new Date(2024, 6, 8), title: 'اجتماع بداية المشروع', type: 'meeting' },
  { date: new Date(2024, 6, 10), title: 'تسليم التصاميم الأولية', type: 'deadline' },
  { date: new Date(2024, 6, 10), title: 'متابعة مع العميل', type: 'meeting' },
  { date: new Date(2024, 6, 15), title: 'كتابة محتوى المدونة', type: 'task' },
  { date: new Date(2024, 6, 22), title: 'مراجعة أداء الحملة', type: 'deadline' },
  { date: new Date(2024, 7, 1), title: 'إطلاق حملة أغسطس', type: 'task' },
];


export default function CalendarPage() {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedFilters, setSelectedFilters] = useState<string[]>(Object.keys(eventTypes));

    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    const daysInMonth = eachDayOfInterval({ start, end });
    const startingDay = getDay(start);

    const handleFilterChange = (type: string) => {
        setSelectedFilters(prev => 
            prev.includes(type) ? prev.filter(f => f !== type) : [...prev, type]
        );
    };

    const filteredEvents = sampleEvents.filter(event => selectedFilters.includes(event.type));

    return (
        <div className="flex flex-col h-[calc(100vh-120px)] bg-background">
            <header className="flex items-center justify-between pb-4 border-b">
                <div className="flex items-center gap-4">
                     <h1 className="text-2xl font-bold tracking-tight font-headline">التقويم</h1>
                    <div className="flex items-center gap-2">
                        <Button variant="outline" size="icon" onClick={() => setCurrentDate(subMonths(currentDate, 1))}>
                            <ChevronRight className="h-4 w-4" />
                        </Button>
                        <span className="text-lg font-semibold w-32 text-center">
                            {format(currentDate, "MMMM yyyy", { locale: ar })}
                        </span>
                        <Button variant="outline" size="icon" onClick={() => setCurrentDate(addMonths(currentDate, 1))}>
                            <ChevronLeft className="h-4 w-4" />
                        </Button>
                         <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())}>
                            اليوم
                        </Button>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    {/* View switcher can be enabled later */}
                    {/* <Button variant="outline">شهري</Button> */}
                    <Button>
                        <PlusCircle className="ml-2 h-4 w-4" />
                        إضافة حدث
                    </Button>
                </div>
            </header>

            <div className="flex flex-1 overflow-hidden mt-4">
                {/* Sidebar */}
                <aside className="w-64 pl-4 pr-4 space-y-6">
                    <Card>
                        <CardContent className="p-2">
                            <Calendar
                                mode="single"
                                selected={currentDate}
                                onSelect={(date) => date && setCurrentDate(date)}
                                locale={ar}
                            />
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-base">تصفية الأحداث</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            {Object.entries(eventTypes).map(([key, { label, color }]) => (
                                <div key={key} className="flex items-center space-x-2 space-x-reverse">
                                    <Checkbox 
                                        id={key} 
                                        checked={selectedFilters.includes(key)}
                                        onCheckedChange={() => handleFilterChange(key)}
                                        style={{ color: `var(--${color.replace('bg-', 'color-')})` }}
                                    />
                                    <span className={`h-2 w-2 rounded-full ${color}`}></span>
                                    <Label htmlFor={key} className="flex-1 text-sm font-medium">{label}</Label>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </aside>
                
                {/* Main Calendar Grid */}
                <main className="flex-1 bg-background border rounded-lg overflow-auto">
                    <div className="grid grid-cols-7 h-full">
                        {/* Calendar Header */}
                        {['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'].map(day => (
                            <div key={day} className="text-center font-semibold p-2 border-b border-l text-sm text-muted-foreground">
                                {day}
                            </div>
                        ))}
                        
                        {/* Empty cells for padding */}
                        {Array.from({ length: startingDay }).map((_, i) => (
                             <div key={`empty-${i}`} className="border-b border-l bg-muted/30"></div>
                        ))}

                        {/* Calendar Days */}
                        {daysInMonth.map((day) => {
                             const dayEvents = filteredEvents.filter(e => format(e.date, 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd'));
                             return (
                                <div key={day.toString()} className={cn(
                                    "border-b border-l p-2 flex flex-col min-h-[120px]",
                                    !isSameMonth(day, currentDate) && "bg-muted/30 text-muted-foreground"
                                )}>
                                    <span className={cn(
                                        "font-semibold self-end",
                                        isToday(day) && "bg-primary text-primary-foreground rounded-full h-6 w-6 flex items-center justify-center"
                                    )}>
                                        {format(day, 'd')}
                                    </span>
                                    <div className="space-y-1 mt-1 flex-1 overflow-y-auto">
                                        {dayEvents.map((event, index) => (
                                            <Badge key={index} className={`text-white text-xs w-full justify-start truncate ${eventTypes[event.type as keyof typeof eventTypes].color}`}>
                                                {event.title}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </main>
            </div>
        </div>
    );
}
