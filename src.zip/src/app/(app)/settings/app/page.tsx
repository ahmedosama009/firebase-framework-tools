
import { AppSettingsForm } from "@/components/settings/app-settings";

export default function AppSettingsPage() {
    return (
        <AppSettingsForm />
    )
}
