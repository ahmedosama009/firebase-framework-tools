
import { BrandForm } from "@/components/settings/brand-form";

export default function BrandSettingsPage() {
    return (
        <BrandForm />
    )
}
