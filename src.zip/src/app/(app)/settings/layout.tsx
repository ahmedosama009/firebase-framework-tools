
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export default function SettingsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
      <div className="space-y-6">
         <Button asChild variant="ghost">
            <Link href="/settings">
                <ArrowRight className="ml-2 h-4 w-4" />
                العودة إلى كل الإعدادات
            </Link>
        </Button>
        {children}
      </div>
  );
}
