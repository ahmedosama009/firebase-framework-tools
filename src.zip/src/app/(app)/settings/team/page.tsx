
import { TeamSettingsForm } from "@/components/settings/team-settings";

export default function TeamSettingsPage() {
    return (
        <TeamSettingsForm />
    )
}
