

'use client'

import { useState } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useBrand } from "@/components/settings/brand-provider";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Edit, Eye, EyeOff, Globe, MessageCircle, BarChart2, Code, Search, Loader2 } from "lucide-react";
import { Assistant } from "@/lib/types";
import { EditAssistantDialog } from "@/components/settings/edit-assistant-dialog";

const accessIcons: { [key: string]: React.ElementType } = {
    'public': Globe,
    'sales': MessageCircle,
    'marketing': BarChart2,
    'code': Code,
    'external_search': Search,
    'internal_analytics': BarChart2,
    'owner': Globe,
    'suggestions': Globe,
    'shared_memory': Globe,
    'team': Globe,
    'content': Globe,
    'images': Globe,
    'review': Globe,
    'admin': Globe,
    'support': Globe,
    'tech': Globe,
    'internal': Globe,
    'analytics': Globe,
};

export default function AssistantsSettingsPage() {
    const { brand, setBrand, isLoaded } = useBrand();
    const [selectedAssistant, setSelectedAssistant] = useState<Assistant | null>(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);

    const handleEditClick = (assistant: Assistant) => {
        setSelectedAssistant(assistant);
        setIsDialogOpen(true);
    };

    const handleSaveAssistant = (updatedAssistant: Assistant) => {
         if (!brand) return;
        const updatedAssistants = brand.assistants.map(a => 
            a.id === updatedAssistant.id ? updatedAssistant : a
        );
        setBrand({ ...brand, assistants: updatedAssistants });
        setIsDialogOpen(false);
    };

    return (
        <div className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle>إعدادات المساعدين</CardTitle>
                    <CardDescription>
                        إدارة وتخصيص قدرات وأداء جميع المساعدين الذكاء الاصطناعي، بما في ذلك المساعدين الذين يعملون في الخلفية.
                    </CardDescription>
                </CardHeader>
                <CardContent className="grid gap-6 md:grid-cols-2">
                    {!isLoaded ? (
                         [...Array(6)].map((_, i) => (
                            <Card key={i}><CardContent className="p-6"><Loader2 className="animate-spin"/></CardContent></Card>
                         ))
                    ) : (
                        brand.assistants?.map((assistant) => (
                            <Card key={assistant.id} className="flex flex-col">
                                <CardHeader className="flex flex-row items-center gap-4 space-y-0">
                                    <Avatar className="h-12 w-12">
                                        <AvatarImage src={assistant.avatarUrl} alt={assistant.name} data-ai-hint="avatar" />
                                        <AvatarFallback>{assistant.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <CardTitle className="text-lg font-headline">{assistant.name}</CardTitle>
                                        <Badge variant={assistant.visible ? 'default' : 'secondary'} className={`mt-1 ${assistant.visible ? 'bg-green-500/20 text-green-700' : ''}`}>
                                            {assistant.visible ? <Eye className="ml-1 w-3 h-3" /> : <EyeOff className="ml-1 w-3 h-3" />}
                                            {assistant.visible ? 'مرئي للمستخدم' : 'يعمل في الخلفية'}
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent className="flex-grow space-y-4">
                                    <p className="text-sm text-muted-foreground">{assistant.role}</p>
                                    <div>
                                        <h4 className="text-xs font-semibold mb-2 text-muted-foreground uppercase tracking-wider">مجالات الوصول</h4>
                                        <div className="flex flex-wrap gap-2">
                                            {assistant.access && assistant.access.map(acc => {
                                                const Icon = accessIcons[acc] || Globe;
                                                return (
                                                    <Badge key={acc} variant="outline" className="flex items-center gap-1.5">
                                                        <Icon className="h-3.5 w-3.5" />
                                                        <span>{acc}</span>
                                                    </Badge>
                                                )
                                            })}
                                            {assistant.access?.length === 0 && (
                                                <p className="text-xs text-muted-foreground">لا توجد صلاحيات وصول.</p>
                                            )}
                                        </div>
                                    </div>
                                </CardContent>
                                <CardFooter>
                                    <Button variant="outline" className="w-full" onClick={() => handleEditClick(assistant)}>
                                        <Edit className="ml-2 h-4 w-4" />
                                        تعديل المساعد
                                    </Button>
                                </CardFooter>
                            </Card>
                        ))
                    )}
                </CardContent>
            </Card>

            {selectedAssistant && (
                <EditAssistantDialog
                    isOpen={isDialogOpen}
                    setIsOpen={setIsDialogOpen}
                    assistant={selectedAssistant}
                    onSave={handleSaveAssistant}
                />
            )}
        </div>
    );
}
