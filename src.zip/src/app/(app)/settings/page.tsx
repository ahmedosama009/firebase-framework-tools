
import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, Building, AppWindow, CreditCard, Handshake, Users2, Bot, ArrowLeft } from "lucide-react";

const settingsCategories = [
    { 
        href: '/settings/brand',
        icon: Building,
        title: 'الشركة',
        description: 'إدارة هوية الشركة، المعلومات القانونية والبنكية.'
    },
    { 
        href: '/settings/team',
        icon: Users2,
        title: 'الفريق',
        description: 'دعوة وإدارة أعضاء فريق العمل وصلاحياتهم.'
    },
    { 
        href: '/settings/client-portal',
        icon: Handshake,
        title: 'واجهة العملاء',
        description: 'تخصيص الواجهة التي يتفاعل معها عملاؤك.'
    },
    { 
        href: '/settings/assistants',
        icon: Bot,
        title: 'المساعدين',
        description: 'تخصيص وإدارة قدرات المساعدين الذكاء الاصطناعي.'
    },
    { 
        href: '/settings/user',
        icon: User,
        title: 'المستخدم',
        description: 'إدارة تفاصيل ملفك الشخصي وتفضيلاتك.'
    },
    { 
        href: '/settings/app',
        icon: AppWindow,
        title: 'التطبيق',
        description: 'تخصيص مظهر التطبيق، الثيمات، واللغة.'
    },
    { 
        href: '/settings/subscription',
        icon: CreditCard,
        title: 'الاشتراك والفواتير',
        description: 'عرض وإدارة باقتك الحالية وتفاصيل الدفع.'
    },
];

export default function SettingsPage() {
    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold tracking-tight font-headline">الإعدادات</h1>
                <p className="text-muted-foreground">
                    إدارة إعدادات حسابك، الهوية التجارية، الاشتراكات، والمزيد.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {settingsCategories.map((category) => (
                    <Card key={category.href} className="flex flex-col hover:shadow-lg transition-shadow">
                        <CardHeader className="flex-grow">
                            <div className="flex items-center gap-4">
                                <div className="p-3 bg-muted rounded-full">
                                    <category.icon className="w-6 h-6 text-muted-foreground" />
                                </div>
                                <div>
                                    <CardTitle className="text-xl font-headline">{category.title}</CardTitle>
                                    <CardDescription className="mt-1">{category.description}</CardDescription>
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent>
                             <Button asChild variant="outline" className="w-full">
                                <Link href={`${category.href}`}>
                                    <ArrowLeft className="mr-2 h-4 w-4" />
                                    الانتقال إلى الإعدادات
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
