
import { UserSettingsForm } from "@/components/settings/user-settings";

export default function UserSettingsPage() {
    return (
        <UserSettingsForm />
    )
}
