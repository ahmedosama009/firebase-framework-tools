
import { ClientPortalForm } from "@/components/settings/client-portal-form";

export default function ClientPortalSettingsPage() {
    return (
        <ClientPortalForm />
    )
}
