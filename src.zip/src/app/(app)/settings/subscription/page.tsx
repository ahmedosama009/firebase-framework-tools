
import { SubscriptionSettings } from "@/components/settings/subscription-settings";

export default function SubscriptionSettingsPage() {
    return (
        <SubscriptionSettings />
    )
}
