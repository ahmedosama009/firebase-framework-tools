

'use client'

import { useState } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useBrand } from "@/components/settings/brand-provider";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Edit, CheckCircle, Search, BarChart2, PlusSquare, Settings, EyeOff, Eye, Code, Globe, MessageCircle } from "lucide-react";
import Link from "next/link";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Assistant } from "@/lib/types";
import { EditAssistantDialog } from "@/components/settings/edit-assistant-dialog";
import { Skeleton } from "@/components/ui/skeleton";

const accessIcons: { [key: string]: React.ElementType } = {
    'public': Globe,
    'sales': MessageCircle,
    'marketing': BarChart2,
    'code': Code,
    'external_search': Search
};

// Mock data for usage stats - in a real app, this would come from a database.
const usageStats: { [key: string]: { interactions: number; tasksCompleted: number } } = {
    'leila': { interactions: 124, tasksCompleted: 15 },
    'sally': { interactions: 88, tasksCompleted: 42 },
    'infinity': { interactions: 210, tasksCompleted: 7 },
    'noura': { interactions: 65, tasksCompleted: 33 },
};

const AssistantCardSkeleton = () => (
    <Card className="flex flex-col">
        <CardHeader className="flex flex-row items-center gap-4 space-y-0">
            <Skeleton className="h-16 w-16 rounded-full" />
            <div className="space-y-2">
                <Skeleton className="h-6 w-24" />
                <Skeleton className="h-4 w-16" />
            </div>
        </CardHeader>
        <CardContent className="flex-grow space-y-4">
            <Skeleton className="h-4 w-full" />
            <div className="space-y-2">
                <Skeleton className="h-4 w-20" />
                <div className="flex flex-wrap gap-2">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-20" />
                </div>
            </div>
             <div className="space-y-2">
                <Skeleton className="h-4 w-28" />
                <div className="flex gap-4">
                    <Skeleton className="h-5 w-24" />
                    <Skeleton className="h-5 w-24" />
                </div>
            </div>
        </CardContent>
        <CardFooter>
            <Skeleton className="h-10 w-full" />
        </CardFooter>
    </Card>
);


export default function AssistantsPage() {
    const { brand, setBrand, isLoaded } = useBrand();
    const [selectedAssistant, setSelectedAssistant] = useState<Assistant | null>(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);

    const handleEditClick = (assistant: Assistant) => {
        setSelectedAssistant(assistant);
        setIsDialogOpen(true);
    };

    const handleSaveAssistant = (updatedAssistant: Assistant) => {
        if (!brand) return;
        const updatedAssistants = brand.assistants.map(a => 
            a.id === updatedAssistant.id ? updatedAssistant : a
        );
        setBrand({ ...brand, assistants: updatedAssistants });
        setIsDialogOpen(false);
    };

    const visibleAssistants = brand.assistants?.filter(a => a.visible) || [];

    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight font-headline">المساعدين</h1>
                    <p className="text-muted-foreground">إدارة وتخصيص قدرات وأداء المساعدين الذكاء الاصطناعي.</p>
                </div>
                <Button asChild variant="outline">
                    <Link href="/settings/assistants">
                        <Settings className="ml-2 h-4 w-4" />
                        إعدادات المساعدين
                    </Link>
                </Button>
            </div>
            
            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                { !isLoaded ? (
                    [...Array(3)].map((_, i) => <AssistantCardSkeleton key={i} />)
                ) : (
                    visibleAssistants.map((assistant) => {
                        const stats = usageStats[assistant.id] || { interactions: 0, tasksCompleted: 0 };
                        return (
                            <Card key={assistant.id} className="flex flex-col">
                                <CardHeader className="flex flex-row items-center gap-4 space-y-0">
                                    <Avatar className="h-16 w-16">
                                        <AvatarImage src={assistant.avatarUrl} alt={assistant.name} data-ai-hint="avatar" />
                                        <AvatarFallback>{assistant.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <CardTitle className="text-xl font-headline">{assistant.name}</CardTitle>
                                        <Badge variant={'default'} className={'mt-1 bg-green-500/20 text-green-700'}>
                                            <CheckCircle className="ml-1 w-3 h-3" />
                                            نشط
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent className="flex-grow space-y-4">
                                    <p className="text-sm text-muted-foreground">{assistant.role}</p>
                                    
                                    <div>
                                        <h4 className="text-sm font-semibold mb-2">مجالات الوصول</h4>
                                        <div className="flex flex-wrap gap-2">
                                            {assistant.access && assistant.access.map(acc => {
                                                const Icon = accessIcons[acc];
                                                return (
                                                    <Badge key={acc} variant="outline" className="flex items-center gap-1.5">
                                                        {Icon && <Icon className="h-3.5 w-3.5" />}
                                                        <span>{acc}</span>
                                                    </Badge>
                                                )
                                            })}
                                            {assistant.access?.length === 0 && (
                                                <p className="text-xs text-muted-foreground">لا توجد صلاحيات وصول.</p>
                                            )}
                                        </div>
                                    </div>
                                    <div>
                                        <h4 className="text-sm font-semibold mb-2">إحصائيات الأداء</h4>
                                        <div className="flex gap-4 text-sm">
                                            <div className="flex items-center gap-1.5">
                                                <strong className="font-bold">{stats.interactions}</strong>
                                                <span className="text-muted-foreground">تفاعل</span>
                                            </div>
                                            <div className="flex items-center gap-1.5">
                                                <strong className="font-bold">{stats.tasksCompleted}</strong>
                                                <span className="text-muted-foreground">مهمة منجزة</span>
                                            </div>
                                        </div>
                                    </div>

                                </CardContent>
                                <CardFooter>
                                    <Button variant="outline" className="w-full" onClick={() => handleEditClick(assistant)}>
                                        <Edit className="ml-2 h-4 w-4" />
                                        تعديل المساعد
                                    </Button>
                                </CardFooter>
                            </Card>
                        )
                    })
                )}
            </div>

            {selectedAssistant && (
                <EditAssistantDialog
                    isOpen={isDialogOpen}
                    setIsOpen={setIsDialogOpen}
                    assistant={selectedAssistant}
                    onSave={handleSaveAssistant}
                />
            )}
        </div>
    );
}
