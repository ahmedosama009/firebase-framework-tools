

'use client';

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { PlusCircle, Columns, KanbanSquare, Bot } from "lucide-react";
import { SpaceCard } from "@/components/spaces/space-card";
import { CreateSpaceDialog } from "@/components/spaces/create-space-dialog";
import { Space } from "@/lib/types";
import { useBrand } from '@/components/settings/brand-provider';

const sampleSpaces: Space[] = [
    { 
        id: "SP001", 
        name: "حملة إطلاق مجموعة الصيف", 
        description: "حملة تسويقية متكاملة لإطلاق تشكيلة الأزياء الصيفية الجديدة.",
        generatedContent: "",
        createdAt: "2024-05-01",
        status: 'تخطيط',
        tasksCount: 3,
        teamAvatars: ['https://placehold.co/100x100.png?text=A', 'https://placehold.co/100x100.png?text=F']
    },
    { 
        id: "SP002", 
        name: "محتوى شهر يوليو للسوشيال ميديا", 
        description: "خطة محتوى لمنصات التواصل الاجتماعي لشهر يوليو، تركز على زيادة التفاعل.",
        generatedContent: "",
        createdAt: "2024-04-22",
        status: 'قيد التنفيذ',
        tasksCount: 8,
        teamAvatars: ['https://placehold.co/100x100.png?text=K', 'https://placehold.co/100x100.png?text=S', 'https://placehold.co/100x100.png?text=A']
    },
    { 
        id: "SP003", 
        name: "حملة إعلانات Google Ads للربع الثالث", 
        description: "حملة إعلانية مدفوعة على محرك بحث جوجل لاستهداف عملاء جدد.",
        generatedContent: "",
        createdAt: "2024-06-10",
        status: 'مكتمل',
        tasksCount: 5,
        teamAvatars: ['https://placehold.co/100x100.png?text=K']
    },
];

export default function SpacesPage() {
    const [spaces, setSpaces] = useState<Space[]>(sampleSpaces);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const { brand, isLoaded } = useBrand();

    const handleCreateSpace = (newSpace: Omit<Space, 'generatedContent' | 'tasks'>) => {
        const spaceWithDefaults: Space = {
            ...newSpace,
            generatedContent: '', 
            status: 'تخطيط',
            tasksCount: 0,
            teamAvatars: [],
            tasks: []
        };
        setSpaces(prevSpaces => [spaceWithDefaults, ...prevSpaces]);
    }
    
    const scheduledSpaces = spaces.filter(s => s.status === 'قيد التنفيذ' || s.status === 'مكتمل');
    const planningSpaces = spaces.filter(s => s.status === 'تخطيط');

    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight font-headline">المساحات (Spaces)</h1>
                    <p className="text-muted-foreground">خطط ونظم حملاتك ومحتواك في مساحات عمل مرنة.</p>
                </div>
                <div className="flex items-center gap-2">
                    <Button variant="outline">
                        <Bot className="ml-2 h-4 w-4" />
                        اقتراح حملة
                    </Button>
                    <Button onClick={() => setIsDialogOpen(true)} disabled={!isLoaded}>
                        <PlusCircle className="ml-2 h-4 w-4" />
                        إنشاء مساحة عمل
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                {/* Planning Column */}
                <div className="space-y-4">
                    <div className="flex items-center gap-3">
                         <div className="p-2 bg-yellow-100 dark:bg-yellow-900/50 rounded-lg">
                            <KanbanSquare className="h-6 w-6 text-yellow-600 dark:text-yellow-400" />
                        </div>
                        <div>
                            <h2 className="text-xl font-bold">الأفكار والحملات</h2>
                            <p className="text-sm text-muted-foreground">مساحات في مرحلة التخطيط والإعداد.</p>
                        </div>
                    </div>
                    <div className="space-y-4">
                        {planningSpaces.map(space => (
                            <SpaceCard key={space.id} space={space} />
                        ))}
                         {planningSpaces.length === 0 && (
                            <div className="text-center py-10 border-2 border-dashed rounded-lg">
                                <p className="text-muted-foreground">لا توجد مساحات في مرحلة التخطيط حاليًا.</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Scheduled Column */}
                <div className="space-y-4">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-100 dark:bg-green-900/50 rounded-lg">
                            <Columns className="h-6 w-6 text-green-600 dark:text-green-400" />
                        </div>
                         <div>
                            <h2 className="text-xl font-bold">الأجندة والمهام</h2>
                            <p className="text-sm text-muted-foreground">الحملات والمهام قيد التنفيذ أو المكتملة.</p>
                        </div>
                    </div>
                    <div className="space-y-4">
                        {scheduledSpaces.map(space => (
                            <SpaceCard key={space.id} space={space} />
                        ))}
                         {scheduledSpaces.length === 0 && (
                            <div className="text-center py-10 border-2 border-dashed rounded-lg">
                                <p className="text-muted-foreground">لا توجد حملات مجدولة حاليًا.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            
            {isLoaded && (
              <CreateSpaceDialog
                  isOpen={isDialogOpen}
                  setIsOpen={setIsDialogOpen}
                  onCreateSpace={handleCreateSpace}
              />
            )}
        </div>
    )
}
