
// src/app/(app)/spaces/[id]/page.tsx
'use client'

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Bot, CheckCircle, Clock, ClipboardList, PlusCircle, Sparkles, Wand2 } from "lucide-react";
import { Space, Task } from "@/lib/types";
import Link from "next/link";
import { Textarea } from '@/components/ui/textarea';
import { useBrand } from '@/components/settings/brand-provider';
import { generateSpaceContent, suggestTasksForSpaceAction } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { TaskBoard } from '@/components/spaces/task-board';

// Mock data - In a real app, you'd fetch this based on the [id] param
const sampleSpaces: Space[] = [
    { 
        id: "SP001", 
        name: "حملة إطلاق مجموعة الصيف", 
        description: "حملة تسويقية متكاملة لإطلاق تشكيلة الأزياء الصيفية الجديدة. الجمهور المستهدف: الشباب بين 18-30 سنة. الرسالة الرئيسية: الانتعاش والأناقة.",
        generatedContent: "انطلق هذا الصيف بأناقة لا مثيل لها مع تشكيلتنا الجديدة! ألوان زاهية وتصاميم عصرية تعكس روح الشباب. #صيف_2024 #أناقة_الصيف",
        createdAt: "2024-05-01",
        status: 'تخطيط',
        tasksCount: 3,
        teamAvatars: ['https://placehold.co/100x100.png?text=A', 'https://placehold.co/100x100.png?text=F'],
        tasks: [
            { id: 'T1', title: 'تحديد المنصات الإعلانية', status: 'completed' },
            { id: 'T2', title: 'تصميم 5 إعلانات صور', status: 'in-progress' },
            { id: 'T3', title: 'كتابة نسخة الإعلانات', status: 'todo' },
        ]
    },
    { 
        id: "SP002", 
        name: "محتوى شهر يوليو للسوشيال ميديا", 
        description: "خطة محتوى لمنصات التواصل الاجتماعي لشهر يوليو، تركز على زيادة التفاعل.",
        generatedContent: "",
        createdAt: "2024-04-22",
        status: 'قيد التنفيذ',
        tasksCount: 8,
        teamAvatars: ['https://placehold.co/100x100.png?text=K', 'https://placehold.co/100x100.png?text=S', 'https://placehold.co/100x100.png?text=A'],
        tasks: []
    },
];

const statusMap: { [key: string]: { text: string; icon: React.ElementType; color: string } } = {
    'تخطيط': { text: 'تخطيط', icon: ClipboardList, color: 'bg-yellow-500' },
    'قيد التنفيذ': { text: 'قيد التنفيذ', icon: Clock, color: 'bg-blue-500' },
    'مكتمل': { text: 'مكتمل', icon: CheckCircle, color: 'bg-green-500' },
};

export default function SpaceDetailsPage({ params }: { params: { id:string } }) {
    const space = sampleSpaces.find(s => s.id === params.id) ?? sampleSpaces[0];
    const statusInfo = statusMap[space.status];
    
    const [generatedContent, setGeneratedContent] = useState(space.generatedContent);
    const [isGeneratingContent, setIsGeneratingContent] = useState(false);
    const [tasks, setTasks] = useState<Task[]>(space.tasks || []);
    const [isGeneratingTasks, setIsGeneratingTasks] = useState(false);
    const { brand, isLoaded } = useBrand();
    const { toast } = useToast();

    const handleGenerateContent = async () => {
        setIsGeneratingContent(true);
        try {
            const content = await generateSpaceContent(space.description, brand);
            setGeneratedContent(content);
            toast({
                title: "تم إنشاء المحتوى بنجاح!",
                description: "يمكنك الآن مراجعة المحتوى وتعديله.",
            });
        } catch (error) {
            toast({
                title: "فشل إنشاء المحتوى",
                description: "حدث خطأ أثناء التواصل مع الذكاء الاصطناعي.",
                variant: "destructive",
            });
        } finally {
            setIsGeneratingContent(false);
        }
    }

    const handleSuggestTasks = async () => {
        setIsGeneratingTasks(true);
        try {
            const suggestedTasks = await suggestTasksForSpaceAction(space.description, generatedContent);
            const newTasks: Task[] = suggestedTasks.map((task, index) => ({
                id: `task-${Date.now()}-${index}`,
                title: task.title,
                status: 'todo'
            }));
            setTasks(prevTasks => [...prevTasks, ...newTasks]);
            toast({
                title: "تم اقتراح المهام بنجاح!",
                description: "تمت إضافة المهام الجديدة إلى لوحة المهام في قسم 'قيد الانتظار'.",
            });
        } catch (error) {
             toast({
                title: "فشل اقتراح المهام",
                description: "حدث خطأ أثناء التواصل مع الذكاء الاصطناعي.",
                variant: "destructive",
            });
        } finally {
            setIsGeneratingTasks(false);
        }
    };


    return (
        <div className="space-y-8">
            <header className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                    <div className="flex items-center gap-3 mb-2">
                        <div>
                             <Badge className={`flex items-center gap-1.5 py-1 px-3 text-sm mb-2 text-white ${statusInfo.color}`}>
                                <statusInfo.icon className="w-4 h-4" />
                                <span>{statusInfo.text}</span>
                            </Badge>
                            <h1 className="text-3xl font-bold tracking-tight font-headline">{space.name}</h1>
                            <p className="text-muted-foreground mt-1 max-w-2xl">{space.description}</p>
                        </div>
                    </div>
                     <Link href="/spaces">
                        <Button variant="link" className="p-0 h-auto">
                            <ArrowLeft className="ml-2 h-4 w-4" />
                            العودة إلى كل المساحات
                        </Button>
                    </Link>
                </div>
                 <Button>
                    <PlusCircle className="ml-2 h-4 w-4" />
                    إضافة مهمة يدوياً
                </Button>
            </header>
            
            <Separator />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                {/* Main Content Area */}
                <main className="lg:col-span-2 space-y-8">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Wand2 className="text-primary"/> المحتوى الذكي</CardTitle>
                            <CardDescription>إنشاء ومراجعة المحتوى الخاص بهذه الحملة.</CardDescription>
                        </CardHeader>
                        <CardContent>
                             {isGeneratingContent ? (
                                <div className="space-y-4">
                                    <Skeleton className="h-8 w-1/4" />
                                    <Skeleton className="h-24 w-full" />
                                    <Skeleton className="h-10 w-32" />
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    <Textarea 
                                        value={generatedContent}
                                        onChange={(e) => setGeneratedContent(e.target.value)}
                                        placeholder="سيظهر المحتوى الذي تم إنشاؤه بواسطة الذكاء الاصطناعي هنا..."
                                        className="min-h-[200px] text-base"
                                    />
                                    <div className="flex gap-2">
                                        <Button onClick={handleGenerateContent} disabled={!isLoaded || isGeneratingContent}>
                                            <Sparkles className="ml-2 h-4 w-4" />
                                            {generatedContent ? 'إعادة إنشاء المحتوى' : 'إنشاء المحتوى الآن'}
                                        </Button>
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                            <div>
                                <CardTitle className="flex items-center gap-2"><ClipboardList className="text-primary"/> لوحة المهام</CardTitle>
                                <CardDescription>تنظيم وتتبع المهام الخاصة بهذه المساحة.</CardDescription>
                            </div>
                            <Button variant="outline" onClick={handleSuggestTasks} disabled={isGeneratingTasks}>
                                <Bot className="ml-2 h-4 w-4" />
                                {isGeneratingTasks ? 'جاري الاقتراح...' : 'اقتراح مهام'}
                            </Button>
                        </CardHeader>
                        <CardContent>
                            <TaskBoard initialTasks={tasks} setTasks={setTasks} />
                        </CardContent>
                    </Card>

                </main>

                {/* Sidebar/Info Area */}
                <aside className="space-y-6">
                      <Card>
                        <CardHeader>
                            <CardTitle className="text-base">الأجندة</CardTitle>
                        </CardHeader>
                        <CardContent>
                             <p className="text-sm text-muted-foreground">قيد الإنشاء...</p>
                        </CardContent>
                     </Card>
                </aside>
            </div>
        </div>
    );
}
