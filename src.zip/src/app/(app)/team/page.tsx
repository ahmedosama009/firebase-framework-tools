
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Mail, ShieldCheck } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

type Role = "مدير" | "عضو فريق" | "مشاهد";

const teamMembers = [
    { name: "أحمد العلي", role: "مدير" as Role, email: "ahmad@example.com", avatar: "https://placehold.co/100x100.png", status: "online", permissions: "إدارة كاملة للنظام" },
    { name: "فاطمة السيد", role: "عضو فريق" as Role, email: "fatima@example.com", avatar: "https://placehold.co/100x100.png", status: "offline", permissions: "إنشاء وتعديل المحتوى" },
    { name: "خالد المصري", role: "عضو فريق" as Role, email: "khalid@example.com", avatar: "https://placehold.co/100x100.png", status: "online", permissions: "إنشاء وتعديل المحتوى" },
    { name: "سارة إبراهيم", role: "مشاهد" as Role, email: "sara@example.com", avatar: "https://placehold.co/100x100.png", status: "away", permissions: "مشاهدة فقط" },
];

const roleColors: { [key in Role]: string } = {
    "مدير": "bg-primary/20 text-primary",
    "عضو فريق": "bg-blue-500/20 text-blue-500",
    "مشاهد": "bg-gray-500/20 text-gray-500",
};


export default function TeamPage() {
    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight font-headline">إدارة الفريق</h1>
                    <p className="text-muted-foreground">إضافة، تعديل، وإدارة أعضاء فريق عملك وصلاحياتهم.</p>
                </div>
                <Button>
                    <PlusCircle className="ml-2 h-4 w-4" />
                    دعوة عضو جديد
                </Button>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {teamMembers.map((member) => (
                    <Card key={member.email}>
                        <CardContent className="p-6 text-center">
                            <div className="relative inline-block">
                                <Avatar className="h-24 w-24 mb-4" data-ai-hint="person">
                                    <AvatarImage src={member.avatar} />
                                    <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                {member.status === 'online' && <span className="absolute bottom-4 right-0 block h-4 w-4 rounded-full bg-green-500 border-2 border-card" />}
                            </div>
                            <CardTitle className="text-xl font-headline">{member.name}</CardTitle>
                            <Badge variant="secondary" className={`mt-2 ${roleColors[member.role]}`}>{member.role}</Badge>
                        </CardContent>
                        <CardContent className="border-t p-4 space-y-2 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2">
                                <Mail className="w-4 h-4" />
                                <span>{member.email}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <ShieldCheck className="w-4 h-4" />
                                <span>{member.permissions}</span>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
