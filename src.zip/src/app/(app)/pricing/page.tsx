
'use client';

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Bot, Box, Users, Infinity as InfinityIcon, Sparkles } from "lucide-react";
import { PricingPlan } from '@/lib/types';
import { getPricingPlans } from '@/lib/data/pricing';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

const limitIcons: { [key: string]: React.ElementType } = {
    spaces: Box,
    assistants: Bot,
    teamMembers: Users,
    aiInteractions: InfinityIcon
};

const limitLabels: { [key: string]: string } = {
    spaces: "مساحة عمل",
    assistants: "مساعد ذكي",
    teamMembers: "عضو فريق",
    aiInteractions: "تفاعل ذكاء اصطناعي"
};

export default function PricingPage() {
    const [pricingPlans, setPricingPlans] = useState<PricingPlan[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        async function loadPlans() {
            setIsLoading(true);
            const fetchedPlans = await getPricingPlans();
            setPricingPlans(fetchedPlans);
            setIsLoading(false);
        }
        loadPlans();
    }, []);

    return (
        <div className="space-y-8">
            <header className="text-center">
                <h1 className="text-4xl font-bold tracking-tight font-headline">عروض وباقات مرنة</h1>
                <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">اختر الباقة التي تناسب حجم أعمالك وأهدافك التسويقية. جميع الباقات قابلة للتخصيص.</p>
                 <Badge variant="outline" className="mt-4 text-base py-2 px-4 border-yellow-400 bg-yellow-50 dark:bg-yellow-900/50 text-yellow-700 dark:text-yellow-300">
                    <Sparkles className="ml-2 h-5 w-5 text-yellow-500"/>
                    عرض خاص للمشتركين الجدد: احصل على 3 أيام تجريبية مجانية!
                </Badge>
            </header>
            
            {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
                    {[...Array(3)].map((_, i) => <PlanSkeleton key={i} />)}
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto items-start">
                    {pricingPlans.map((plan) => (
                        <Card key={plan.id} className={cn('flex flex-col', plan.isPopular ? 'border-primary shadow-2xl' : '')}>
                            {plan.isPopular && (
                                <div className="bg-primary text-primary-foreground text-center py-1.5 text-sm font-semibold">الأكثر شيوعاً</div>
                            )}
                            <CardHeader className={cn("text-center pb-4", plan.colorClass, plan.colorClass ? 'text-white' : '')}>
                                <CardTitle className="text-2xl font-headline">{plan.name}</CardTitle>
                                <CardDescription className={cn(plan.colorClass ? 'text-white/80' : '')}>{plan.description}</CardDescription>
                            </CardHeader>
                            <CardContent className="flex-grow space-y-6 pt-6">
                                <div className="text-center">
                                    <span className="text-4xl font-bold">{plan.price}</span>
                                    {plan.priceUnit && <span className="text-muted-foreground"> {plan.priceUnit}</span>}
                                </div>
                                <div className="space-y-4">
                                    <div>
                                        <h4 className="text-sm font-semibold text-center mb-2 text-muted-foreground">الميزات الأساسية</h4>
                                        <ul className="space-y-3 text-right">
                                            {plan.features.map((feature, index) => (
                                                <li key={index} className="flex items-center gap-2">
                                                    <Check className="text-green-500 w-5 h-5" />
                                                    <span className="flex-1">{feature}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    <Separator />
                                    <div>
                                        <h4 className="text-sm font-semibold text-center mb-3 text-muted-foreground">حدود الاستخدام</h4>
                                        <ul className="space-y-3 text-right">
                                           {Object.entries(plan.limits).map(([key, value]) => {
                                             const Icon = limitIcons[key as keyof typeof limitIcons];
                                             const label = limitLabels[key as keyof typeof limitLabels];
                                             return (
                                                <li key={key} className="flex items-center gap-2 text-sm">
                                                    <Icon className="text-muted-foreground w-4 h-4"/>
                                                    <span className="flex-1">{label}</span>
                                                    <span className="font-semibold">{value === 'unlimited' ? 'غير محدود' : value}</span>
                                                </li>
                                             )
                                           })}
                                        </ul>
                                    </div>
                                </div>
                            </CardContent>
                            <CardFooter>
                                <Button asChild className="w-full" variant={plan.isPopular ? 'default' : 'outline'}>
                                    {plan.price === 'تواصل معنا' ? 
                                    <Link href="/messages">تواصل معنا</Link>
                                    : 
                                    <Link href={`/subscribe?plan=${plan.id}`}>ابدأ الفترة التجريبية</Link>
                                    }
                                </Button>
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
}


const PlanSkeleton = () => (
    <Card className="flex flex-col">
        <CardHeader className="text-center">
            <Skeleton className="h-7 w-3/4 mx-auto" />
            <Skeleton className="h-4 w-full mx-auto mt-2" />
        </CardHeader>
        <CardContent className="flex-grow space-y-6">
            <div className="text-center space-y-2">
                <Skeleton className="h-10 w-1/2 mx-auto" />
                <Skeleton className="h-4 w-1/4 mx-auto" />
            </div>
            <div className="space-y-3">
                {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-5 w-full" />)}
            </div>
        </CardContent>
        <CardFooter>
            <Skeleton className="h-10 w-full" />
        </CardFooter>
    </Card>
);
