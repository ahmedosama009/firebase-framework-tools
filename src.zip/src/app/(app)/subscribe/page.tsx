

'use client';

import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CreditCard, Loader2, ShieldCheck } from "lucide-react";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';

function SubscribeContent() {
    const searchParams = useSearchParams();
    const planId = searchParams.get('plan');

    // In a real app, you would fetch plan details based on planId
    const planName = planId === 'plan_basic' ? 'الباقة الأساسية' : 
                     planId === 'plan_pro' ? 'الباقة الاحترافية' : 'باقة مخصصة';

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would integrate with PaySky
        alert('سيتم هنا الربط مع بوابة الدفع PaySky.');
    };

    return (
        <div className="flex min-h-screen items-center justify-center bg-muted p-4">
            <div className="w-full max-w-2xl space-y-8">
                <div className="text-center">
                    <h1 className="text-3xl font-bold tracking-tight font-headline">إتمام الاشتراك</h1>
                    <p className="text-muted-foreground mt-2">أنت على بعد خطوة واحدة من تفعيل باقة: <span className="font-bold text-primary">{planName}</span></p>
                </div>

                <Card className="shadow-lg">
                    <CardHeader>
                        <CardTitle>تفاصيل الدفع</CardTitle>
                        <CardDescription>
                            سيتم توجيهك إلى بوابة الدفع الآمنة الخاصة بـ PaySky.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800">
                                <h3 className="font-semibold text-blue-800 dark:text-blue-200">فترة تجريبية لمدة 3 أيام</h3>
                                <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                                    سيتم خصم 50 جنيهًا مصريًا كرسوم تأكيد قابلة للاسترداد. بعد 3 أيام، سيتم خصم قيمة الاشتراك تلقائيًا ما لم تقم بالإلغاء.
                                </p>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="coupon">كود الخصم (اختياري)</Label>
                                <div className="flex gap-2">
                                    <Input id="coupon" placeholder="أدخل كود الفاوتشر" />
                                    <Button type="button" variant="secondary">تطبيق</Button>
                                </div>
                            </div>
                            
                             <div className="space-y-4">
                                <Label>اختر طريقة الدفع</Label>
                                <div className="grid grid-cols-2 gap-4">
                                    <Button variant="outline" className="h-16 flex-col gap-1">
                                         <CreditCard className="w-6 h-6"/>
                                        <span>بطاقة ائتمانية</span>
                                    </Button>
                                    <Button variant="outline" className="h-16 flex-col gap-1">
                                        <img src="https://www.paysky.io/images/logo-light.svg" alt="PaySky" className="h-6 w-auto dark:hidden"/>
                                         <img src="https://www.paysky.io/images/logo-dark.svg" alt="PaySky" className="h-6 w-auto hidden dark:block"/>
                                        <span>محفظة PaySky</span>
                                    </Button>
                                </div>
                            </div>

                            <Button type="submit" className="w-full text-lg py-6">
                                <ShieldCheck className="ml-2 h-5 w-5" />
                                الانتقال للدفع الآمن
                            </Button>
                        </form>
                    </CardContent>
                </Card>

                 <div className="text-center text-sm text-muted-foreground">
                    <p>جميع المعاملات المالية مؤمنة بواسطة PaySky.</p>
                     <Link href="/pricing">
                        <Button variant="link" className="mt-2">العودة لاختيار باقة أخرى</Button>
                     </Link>
                </div>
            </div>
        </div>
    );
}

export default function SubscribePage() {
    return (
        <Suspense fallback={<div className="flex h-screen w-full items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
            <SubscribeContent />
        </Suspense>
    );
}
