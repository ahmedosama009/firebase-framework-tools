
'use client';

import * as React from "react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Filter, ChevronDown, CheckCircle, Clock, XCircle, LayoutGrid, List, Bot, ThumbsUp, ThumbsDown, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuCheckboxItem } from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";

const initialTasks = [
    { id: 'TASK-01', title: "تصميم هوية بصرية لشركة الأفق", status: 'completed', approvalStatus: 'approved', priority: 'high', assignee: { name: 'فاطمة السيد', avatar: 'https://placehold.co/100x100.png?text=F' }, clientName: 'شركة الأفق', dueDate: '2024-06-25', createdBy: 'human' },
    { id: 'TASK-02', title: "إطلاق حملة إعلانية لمنتج جديد", status: 'in-progress', approvalStatus: 'approved', priority: 'high', assignee: { name: 'خالد المصري', avatar: 'https://placehold.co/100x100.png?text=K' }, clientName: 'القمة الرقمية', dueDate: '2024-07-05', createdBy: 'human' },
    { id: 'TASK-03', title: "كتابة 4 مقالات للمدونة حول 'التسويق المستدام'", status: 'todo', approvalStatus: 'review', priority: 'medium', assignee: { name: 'سارة إبراهيم', avatar: 'https://placehold.co/100x100.png?text=S' }, clientName: 'حلول إبداع', dueDate: '2024-07-10', createdBy: 'ai' },
    { id: 'TASK-04', title: "مراجعة تقرير الأداء الشهري", status: 'in-progress', approvalStatus: 'approved', priority: 'low', assignee: { name: 'أحمد العلي', avatar: 'https://placehold.co/100x100.png?text=A' }, clientName: 'شركة الأفق', dueDate: '2024-06-30', createdBy: 'human' },
    { id: 'TASK-05', title: "تحديث تصميم صفحة الهبوط الرئيسية", status: 'todo', approvalStatus: 'approved', priority: 'high', assignee: { name: 'فاطمة السيد', avatar: 'https://placehold.co/100x100.png?text=F' }, clientName: 'مجموعة الإنجاز', dueDate: '2024-07-15', createdBy: 'human' },
    { id: 'TASK-06', title: "إنشاء فيديو ترويجي قصير لخدمة التصوير", status: 'todo', approvalStatus: 'rejected', priority: 'medium', assignee: { name: 'خالد المصري', avatar: 'https://placehold.co/100x100.png?text=K' }, clientName: 'رواد المستقبل', dueDate: '2024-07-20', createdBy: 'ai' },
];

type TaskStatus = 'todo' | 'in-progress' | 'completed';
type ApprovalStatus = 'review' | 'approved' | 'rejected';
type ViewMode = 'board' | 'list';

const statusMap: { [key in TaskStatus]: { text: string; icon: React.ElementType; color: string } } = {
    'completed': { text: 'مكتمل', icon: CheckCircle, color: 'text-green-500' },
    'in-progress': { text: 'قيد التنفيذ', icon: Clock, color: 'text-blue-500' },
    'todo': { text: 'قيد الانتظار', icon: Clock, color: 'text-gray-500' },
};

const approvalStatusMap: { [key in ApprovalStatus]: { text: string; icon: React.ElementType; color: string; bg: string } } = {
    'approved': { text: 'معتمد', icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-100' },
    'review': { text: 'للمراجعة', icon: AlertCircle, color: 'text-yellow-600', bg: 'bg-yellow-100' },
    'rejected': { text: 'مرفوض', icon: XCircle, color: 'text-red-600', bg: 'bg-red-100' },
};

const priorityMap = {
    'high': { text: 'عالية', color: 'bg-red-500' },
    'medium': { text: 'متوسطة', color: 'bg-yellow-500' },
    'low': { text: 'منخفضة', color: 'bg-green-500' },
}

const taskColumns: { [key in TaskStatus]: string } = {
    'todo': 'قيد الانتظار',
    'in-progress': 'قيد التنفيذ',
    'completed': 'مكتمل',
};

const TaskCard = ({ task }: { task: typeof initialTasks[0] }) => {
    const ApprovalIcon = approvalStatusMap[task.approvalStatus as ApprovalStatus].icon;
    const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';
    return (
        <Card className="mb-4 hover:shadow-lg transition-shadow duration-200">
            <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                    <Badge variant="outline" className={`flex items-center gap-1 text-xs font-semibold ${approvalStatusMap[task.approvalStatus as ApprovalStatus].bg} ${approvalStatusMap[task.approvalStatus as ApprovalStatus].color}`}>
                        <ApprovalIcon className="w-3 h-3" />
                        <span>{approvalStatusMap[task.approvalStatus as ApprovalStatus].text}</span>
                    </Badge>
                     <Badge variant="secondary" className="flex items-center gap-1 py-1">
                        <span>{priorityMap[task.priority as keyof typeof priorityMap].text}</span>
                        <span className={`w-2 h-2 rounded-full ${priorityMap[task.priority as keyof typeof priorityMap].color}`}></span>
                    </Badge>
                </div>
                
                <p className="font-semibold text-base mb-2 flex items-center gap-2">
                    {task.createdBy === 'ai' && <Bot className="w-4 h-4 text-blue-500" />}
                    {task.title}
                </p>
                <p className="text-sm text-muted-foreground mb-3">للعميل: <span className="font-medium text-foreground">{task.clientName}</span></p>

                {task.approvalStatus === 'review' && (
                     <div className="flex gap-2 mb-4">
                        <Button size="sm" variant="outline" className="w-full text-green-600 border-green-300 hover:bg-green-50 hover:text-green-700">
                            <ThumbsUp className="ml-1 h-4 w-4"/> موافقة
                        </Button>
                        <Button size="sm" variant="outline" className="w-full text-red-600 border-red-300 hover:bg-red-50 hover:text-red-700">
                            <ThumbsDown className="ml-1 h-4 w-4"/> رفض
                        </Button>
                    </div>
                )}
                
                <Separator className="my-3" />
                <div className="flex justify-between items-center text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                            <AvatarImage src={task.assignee.avatar} data-ai-hint="person" />
                            <AvatarFallback>{task.assignee.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span>{task.assignee.name}</span>
                    </div>
                     <span className={cn("text-xs font-semibold p-1 rounded-md", isOverdue ? 'text-red-600 bg-red-100' : '')}>
                        {new Date(task.dueDate).toLocaleDateString('ar-EG')}
                    </span>
                </div>
            </CardContent>
        </Card>
    )
}

export default function TasksPage() {
    const [viewMode, setViewMode] = useState<ViewMode>('board');
    const [tasks, setTasks] = useState(initialTasks);
    
    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight font-headline">إدارة المهام</h1>
                    <p className="text-muted-foreground">تنظيم، تتبع، والموافقة على جميع مهام فريقك.</p>
                </div>
                <div className="flex items-center gap-2">
                     <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline">
                                <Filter className="ml-2 h-4 w-4" />
                                تصفية
                                <ChevronDown className="mr-2 h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                            <DropdownMenuCheckboxItem checked>الأولوية</DropdownMenuCheckboxItem>
                            <DropdownMenuCheckboxItem>المسؤول</DropdownMenuCheckboxItem>
                            <DropdownMenuCheckboxItem>تاريخ الاستحقاق</DropdownMenuCheckboxItem>
                             <DropdownMenuCheckboxItem>حالة الموافقة</DropdownMenuCheckboxItem>
                        </DropdownMenuContent>
                    </DropdownMenu>

                     <div className="flex items-center rounded-md bg-muted p-1">
                        <Button variant={viewMode === 'board' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('board')}>
                            <LayoutGrid className="h-4 w-4" />
                        </Button>
                         <Button variant={viewMode === 'list' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('list')}>
                            <List className="h-4 w-4" />
                        </Button>
                    </div>

                    <Button>
                        <PlusCircle className="ml-2 h-4 w-4" />
                        إضافة مهمة
                    </Button>
                    <Button variant="outline">
                        <Bot className="ml-2 h-4 w-4" />
                        اقتراح مهام
                    </Button>
                </div>
            </div>

            {viewMode === 'board' ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
                    {Object.entries(taskColumns).map(([statusKey, columnTitle]) => (
                        <div key={statusKey} className="bg-muted/50 rounded-lg h-full w-full">
                            <h2 className="text-lg font-semibold p-4 border-b flex items-center gap-2">
                                {statusMap[statusKey as TaskStatus].icon && React.createElement(statusMap[statusKey as TaskStatus].icon, { className: `w-5 h-5 ${statusMap[statusKey as TaskStatus].color}` })}
                                {columnTitle} 
                                <span className="text-sm text-muted-foreground">({tasks.filter(t => t.status === statusKey).length})</span>
                            </h2>
                            <div className="p-4">
                                {tasks.filter(t => t.status === statusKey).map(task => <TaskCard key={task.id} task={task} />)}
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <Card>
                    <CardContent className="p-0">
                       <div className="overflow-x-auto">
                            <table className="w-full text-sm text-right">
                                <thead className="bg-muted/50">
                                    <tr>
                                        <th className="p-4 font-semibold">المهمة</th>
                                        <th className="p-4 font-semibold">العميل</th>
                                        <th className="p-4 font-semibold">المسؤول</th>
                                        <th className="p-4 font-semibold">تاريخ الاستحقاق</th>
                                        <th className="p-4 font-semibold">الحالة</th>
                                        <th className="p-4 font-semibold">الموافقة</th>
                                        <th className="p-4 font-semibold">الأولوية</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {tasks.map(task => {
                                        const StatusIcon = statusMap[task.status].icon;
                                        const ApprovalIcon = approvalStatusMap[task.approvalStatus as ApprovalStatus].icon;
                                        return (
                                        <tr key={task.id} className="border-b">
                                            <td className="p-4 font-medium flex items-center gap-2">{task.createdBy === 'ai' && <Bot className="w-4 h-4 text-blue-500" />} {task.title}</td>
                                            <td className="p-4">{task.clientName}</td>
                                            <td className="p-4">
                                                <div className="flex items-center gap-2">
                                                    <Avatar className="h-6 w-6">
                                                        <AvatarImage src={task.assignee.avatar} data-ai-hint="person" />
                                                        <AvatarFallback>{task.assignee.name.charAt(0)}</AvatarFallback>
                                                    </Avatar>
                                                    <span>{task.assignee.name}</span>
                                                </div>
                                            </td>
                                            <td className="p-4">{new Date(task.dueDate).toLocaleDateString('ar-EG')}</td>
                                            <td className="p-4">
                                                <Badge variant="outline" className="font-normal flex items-center gap-1"><StatusIcon className={`w-3 h-3 ${statusMap[task.status].color}`} /> {statusMap[task.status].text}</Badge>
                                            </td>
                                            <td className="p-4">
                                                <Badge variant="outline" className={`font-normal flex items-center gap-1 ${approvalStatusMap[task.approvalStatus as ApprovalStatus].bg} ${approvalStatusMap[task.approvalStatus as ApprovalStatus].color}`}>
                                                    <ApprovalIcon className="w-3 h-3" /> {approvalStatusMap[task.approvalStatus as ApprovalStatus].text}
                                                </Badge>
                                            </td>
                                            <td className="p-4">
                                                <Badge className={`flex items-center gap-1 text-white ${priorityMap[task.priority as keyof typeof priorityMap].color}`}>
                                                    <span>{priorityMap[task.priority as keyof typeof priorityMap].text}</span>
                                                </Badge>
                                            </td>
                                        </tr>
                                        )
                                    })}
                                </tbody>
                            </table>
                       </div>
                    </CardContent>
                </Card>
            )}
        </div>
    )
}

    

    