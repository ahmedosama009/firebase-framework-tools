
// src/app/(app)/clients/[id]/page.tsx
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { CircleUser, PlusCircle, Calendar, CheckCircle, Clock, Timer, MessageSquare, FileText } from "lucide-react";
import { Client } from "@/lib/types";
import Link from "next/link";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

// Mock data - In a real app, you'd fetch this based on the [id] param
const sampleClients: Client[] = [
    { id: "CLT001", companyId: 'alkayan-infinity', name: "شركة الأفق الجديد", email: "contact@newhorizon.com", status: "active", serviceType: "online", lastActivity: "2024-05-15" },
    { id: "CLT002", companyId: 'alkayan-infinity', name: "مؤسسة القمة الرقمية", email: "info@digitalpeak.co", status: "active", serviceType: "offline", lastActivity: "2024-05-12" },
];

const sampleRequests = [
    { id: "REQ01", title: "تصميم هوية بصرية كاملة", status: "completed", deliveryDate: "2024-06-15", comments: 5, files: 3 },
    { id: "REQ02", title: "حملة إعلانية لشهر يوليو", status: "in-progress", deliveryDate: "2024-07-20", comments: 2, files: 1 },
    { id: "REQ03", title: "محتوى سوشيال ميديا", status: "pending", deliveryDate: "2024-08-01", comments: 0, files: 0 },
];

const statusMap: { [key: string]: { text: string; icon: React.ElementType; color: string, textColor: string } } = {
    'completed': { text: 'مكتمل', icon: CheckCircle, color: 'bg-green-100 dark:bg-green-900/30', textColor: 'text-green-700 dark:text-green-300' },
    'in-progress': { text: 'قيد التنفيذ', icon: Timer, color: 'bg-blue-100 dark:bg-blue-900/30', textColor: 'text-blue-700 dark:text-blue-300' },
    'pending': { text: 'معلق', icon: Clock, color: 'bg-yellow-100 dark:bg-yellow-900/30', textColor: 'text-yellow-700 dark:text-yellow-300' },
};

export default function ClientPortalPage({ params }: { params: { id: string } }) {
    const client = sampleClients.find(c => c.id === params.id) ?? { id: params.id, name: "عميل غير موجود", email: "" };

    return (
        <div className="space-y-8">
            <header className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                    <Avatar className="h-16 w-16 bg-muted">
                        <AvatarFallback className="text-2xl font-bold bg-muted text-muted-foreground">
                            {client.name.charAt(0)}
                        </AvatarFallback>
                    </Avatar>
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight font-headline">{client.name}</h1>
                        <p className="text-muted-foreground">{client.email}</p>
                    </div>
                </div>
                 <div className="flex items-center gap-2">
                     <Link href="/clients">
                        <Button variant="outline">
                            &rarr; العودة إلى العملاء
                        </Button>
                    </Link>
                    <Button>
                        <PlusCircle className="ml-2 h-4 w-4" />
                        إنشاء طلب جديد
                    </Button>
                </div>
            </header>
            
            <Separator />

            <Card>
                <CardHeader>
                    <CardTitle>طلبات العمل</CardTitle>
                    <CardDescription>عرض ومتابعة جميع طلبات ومشاريع العميل.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {sampleRequests.map(req => {
                            const statusInfo = statusMap[req.status];
                            return (
                                <Card key={req.id} className="transition-shadow hover:shadow-md">
                                    <CardContent className="p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                                        <div className="flex-1">
                                            <Badge className={`flex items-center gap-2 py-1 px-3 text-sm mb-2 w-fit ${statusInfo.color} ${statusInfo.textColor}`}>
                                                <statusInfo.icon className="w-4 h-4" />
                                                <span>{statusInfo.text}</span>
                                            </Badge>
                                            <p className="font-semibold text-lg">{req.title}</p>
                                        </div>
                                        <div className="w-full md:w-auto flex flex-col md:items-end gap-2 text-sm text-muted-foreground">
                                             <div className="flex items-center gap-2">
                                                <Calendar className="w-4 h-4" />
                                                <span>تسليم في: {new Date(req.deliveryDate).toLocaleDateString('ar-EG')}</span>
                                            </div>
                                             <div className="flex items-center gap-4">
                                                <span className="flex items-center gap-1.5"><MessageSquare className="w-4 h-4"/> {req.comments}</span>
                                                <span className="flex items-center gap-1.5"><FileText className="w-4 h-4"/> {req.files}</span>
                                            </div>
                                        </div>
                                         <Button variant="outline" size="sm" className="w-full md:w-auto">عرض التفاصيل</Button>
                                    </CardContent>
                                </Card>
                            )
                        })}
                         {sampleRequests.length === 0 && (
                            <div className="text-center py-10 border-2 border-dashed rounded-lg">
                                <p className="text-muted-foreground">لا توجد طلبات لهذا العميل بعد.</p>
                                <Button variant="link" className="mt-2">إنشاء الطلب الأول</Button>
                            </div>
                         )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
