

import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import { ClientTable } from "@/components/clients/client-table";
import { Client } from "@/lib/types";
import { getClients } from '@/lib/data/clients';
import { Skeleton } from '@/components/ui/skeleton';

// Note: This is now a server component, fetching data directly.
export default async function ClientsPage() {
    // We assume a default or context-based brand ID for server-side fetching.
    // In a real multi-tenant app, this would come from the user's session.
    const brandId = "alkayan-infinity"; 
    
    const clients = await getClients(brandId);

    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight font-headline">إدارة العملاء</h1>
                    <p className="text-muted-foreground">عرض، إضافة، وتعديل معلومات عملائك.</p>
                </div>
                <Button>
                    <PlusCircle className="ml-2 h-4 w-4" />
                    إضافة عميل جديد
                </Button>
            </div>
            <ClientTable data={clients} />
        </div>
    )
}
