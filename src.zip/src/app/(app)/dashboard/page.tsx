
import { StatsCard } from '@/components/dashboard/stats-card';
import { RevenueChart } from '@/components/dashboard/revenue-chart';
import { UpcomingEvents } from '@/components/dashboard/upcoming-events';
import { KAiSuggestions } from '@/components/dashboard/k-ai-suggestions';
import { DollarSign, Users, Bot, Activity } from 'lucide-react';

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold tracking-tight font-headline">لوحة التحكم</h1>
        <p className="text-muted-foreground">نظرة عامة على أداء أعمالك وتوصيات الذكاء الاصطناعي.</p>
      </header>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard 
          title="إجمالي الإيرادات" 
          value="١٢٥,٤٣٠ جنيه مصري" 
          icon={DollarSign} 
          change="+20.1% من الشهر الماضي"
        />
        <StatsCard 
          title="العملاء النشطون" 
          value="٢٣٤" 
          icon={Users} 
          change="+12.5% من الشهر الماضي"
        />
        <StatsCard 
          title="محتوى تم إنشاؤه" 
          value="١,٢٠٥" 
          icon={Bot} 
          change="+٥٢٠ هذا الأسبوع"
        />
        <StatsCard 
          title="معدل النشاط" 
          value="٧٨.٥٪" 
          icon={Activity} 
          change="+2.1% من الشهر الماضي"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <KAiSuggestions />
          <div className="mt-8">
            <RevenueChart />
          </div>
        </div>
        <div>
          <UpcomingEvents />
        </div>
      </div>
    </div>
  );
}
