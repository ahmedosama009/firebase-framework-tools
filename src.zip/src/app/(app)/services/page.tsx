
'use client';

import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, ShoppingCart } from "lucide-react";
import { Service } from '@/lib/types';
import { getServices } from '@/lib/data/services';
import { Skeleton } from '@/components/ui/skeleton';
import { useBrand } from '@/components/settings/brand-provider';


export default function ServicesPage() {
    const [services, setServices] = useState<Service[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const { brand, isLoaded } = useBrand();

    useEffect(() => {
        async function loadServices() {
            if (!isLoaded || !brand.id) return;
            setIsLoading(true);
            try {
                const fetchedServices = await getServices(brand.id);
                setServices(fetchedServices);
            } catch (error) {
                console.error("Failed to load services:", error);
            } finally {
                setIsLoading(false);
            }
        }
        loadServices();
    }, [isLoaded, brand.id]);

    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight font-headline">الخدمات</h1>
                    <p className="text-muted-foreground">إدارة وعرض الخدمات التي تقدمها وكالتك.</p>
                </div>
                 <Button>
                    <PlusCircle className="ml-2 h-4 w-4" />
                    إضافة خدمة جديدة
                </Button>
            </div>
            
            {isLoading ? (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {[...Array(3)].map((_, i) => <ServiceSkeleton key={i} />)}
                </div>
            ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {services.map((service) => (
                        <Card key={service.id} className="flex flex-col">
                            <CardHeader>
                                <CardTitle>{service.name}</CardTitle>
                                <CardDescription className="text-primary font-semibold">{service.price}</CardDescription>
                            </CardHeader>
                            <CardContent className="flex-grow">
                                <p className="text-muted-foreground">{service.description}</p>
                            </CardContent>
                            <CardFooter>
                                <Button variant="outline" className="w-full">
                                    <ShoppingCart className="ml-2 h-4 w-4" />
                                    طلب الخدمة
                                </Button>
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
}


const ServiceSkeleton = () => (
    <Card className="flex flex-col">
        <CardHeader>
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-1/2 mt-2" />
        </CardHeader>
        <CardContent className="flex-grow space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
        </CardContent>
        <CardFooter>
            <Skeleton className="h-10 w-full" />
        </CardFooter>
    </Card>
);
