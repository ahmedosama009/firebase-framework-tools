
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import { SalesTable } from "@/components/sales/sales-table";
import { Sale } from "@/lib/types";

// Mock data for sales
const sampleSales: Sale[] = [
    { id: "SALE001", clientName: "شركة الأفق الجديد", clientId: "CLT001", amount: 5000, date: "2024-07-20", source: "campaign", service: "باقة التسويق الرقمي" },
    { id: "SALE002", clientName: "مؤسسة القمة الرقمية", clientId: "CLT002", amount: 8000, date: "2024-07-18", source: "b2b", service: "تصميم الهوية البصرية" },
    { id: "SALE003", clientName: "رواد المستقبل للتجارة", clientId: "CLT004", amount: 3500, date: "2024-07-15", source: "direct", service: "إدارة حسابات التواصل" },
    { id: "SALE004", clientName: "حلول إبداع المتحدة", clientId: "CLT003", amount: 2500, date: "2024-07-12", source: "word_of_mouth", service: "كتابة المحتوى" },
    { id: "SALE005", clientName: "الشركة العالمية للتقنية", clientId: "CLT006", amount: 12000, date: "2024-07-10", source: "campaign", service: "باقة الشركات" },
    { id: "SALE006", clientName: "شركة الأفق الجديد", clientId: "CLT001", amount: 2000, date: "2024-07-05", source: "b2b", service: "تصوير المنتجات" },
];


export default function SalesPage() {
    return (
        <div className="space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight font-headline">إدارة المبيعات</h1>
                    <p className="text-muted-foreground">تتبع وتحليل جميع عمليات البيع ومصادرها.</p>
                </div>
                <Button>
                    <PlusCircle className="ml-2 h-4 w-4" />
                    إضافة عملية بيع
                </Button>
            </div>
            <SalesTable data={sampleSales} />
        </div>
    )
}
