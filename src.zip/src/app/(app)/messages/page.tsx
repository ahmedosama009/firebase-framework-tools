
'use client'

import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Bot, User, MessageSquarePlus, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NewMessageDialog } from "@/components/messages/new-message-dialog";
import { Textarea } from "@/components/ui/textarea";

type ConversationType = 'client' | 'team' | 'ai';

const conversations: { id: string; name: string; avatar: string; lastMessage: string; time: string; unread: number; type: ConversationType, assistant?: string }[] = [
    { id: 'CONV001', name: 'أحمد العلي (عميل)', avatar: 'https://placehold.co/100x100.png', lastMessage: 'تمام، سأقوم بمراجعة التصاميم.', time: '10:45 ص', unread: 2, type: 'client' },
    { id: 'CONV005', name: 'نورة سالم (عميل)', avatar: 'https://placehold.co/100x100.png', lastMessage: 'شكرًا ليلى، هذا مفيد جدًا!', time: '11:20 ص', unread: 0, type: 'client', assistant: 'ليلى' },
    { id: 'CONV002', name: 'فاطمة السيد (فريق)', avatar: 'https://placehold.co/100x100.png', lastMessage: 'هل يمكنك إرسال تقرير الأداء؟', time: 'أمس', unread: 0, type: 'team' },
    { id: 'CONV003', name: 'المساعد K (نظام)', avatar: '', lastMessage: 'اقتراح: تحسين نبرة المحتوى.', time: '12:30 م', unread: 1, type: 'ai' },
    { id: 'CONV004', name: 'خالد المصري (فريق)', avatar: 'https://placehold.co/100x100.png', lastMessage: 'تم إطلاق الحملة الإعلانية بنجاح.', time: 'منذ يومين', unread: 0, type: 'team' },
];

const initialMessages: { [key: string]: any[] } = {
    'CONV001': [
        { id: 'MSG01', role: 'other', content: 'مرحباً، هل تم الانتهاء من التعديلات على الشعار؟', time: '10:30 ص', sender: 'أحمد العلي' },
        { id: 'MSG02', role: 'me', content: 'أهلاً أحمد، نعم، لقد أرسلتها عبر البريد الإلكتروني للتو.', time: '10:32 ص' },
        { id: 'MSG03', role: 'other', content: 'ممتاز، وصلني. سألقي نظرة.', time: '10:33 ص', sender: 'أحمد العلي' },
        { id: 'MSG02a', role: 'me-assistant', content: 'للتذكير، التعديلات تتضمن تغيير الألوان حسب طلبك الأخير.', time: '10:34 ص', sender: 'سالي' },
        { id: 'MSG04', role: 'other', content: 'تمام، سأقوم بمراجعة التصاميم.', time: '10:45 ص', sender: 'أحمد العلي' },
    ],
    'CONV005': [
        { id: 'MSG10', role: 'other', content: 'مرحباً، أود الاستفسار عن باقة التسويق الرقمي.', time: '11:15 ص', sender: 'نورة سالم' },
        { id: 'MSG11', role: 'assistant', content: 'أهلاً بكِ نورة، أنا ليلى. باقة التسويق الرقمي تشمل إدارة حملات التواصل الاجتماعي ومحركات البحث. هل لديكِ أي أسئلة محددة عنها؟', time: '11:16 ص', sender: 'ليلى' },
        { id: 'MSG12', role: 'other', content: 'نعم، كم عدد المنصات التي تتم إدارتها في الباقة؟', time: '11:18 ص', sender: 'نورة سالم' },
        { id: 'MSG13', role: 'assistant', content: 'الباقة تشمل إدارة 3 منصات من اختيارك. هل تودين معرفة المزيد؟', time: '11:19 ص', sender: 'ليلى' },
        { id: 'MSG14', role: 'other', content: 'شكرًا ليلى، هذا مفيد جدًا!', time: '11:20 ص', sender: 'نورة سالم' },
    ],
    'CONV002': [
         { id: 'MSG21', role: 'other', content: 'هل يمكنك إرسال تقرير الأداء؟', time: 'أمس', sender: 'فاطمة السيد' },
    ],
    'CONV003': [
        { id: 'MSG31', role: 'assistant', content: 'اقتراح: تحسين نبرة المحتوى لزيادة التفاعل.', time: '12:30 م', sender: 'المساعد K' },
    ],
    'CONV004': [
        { id: 'MSG41', role: 'other', content: 'تم إطلاق الحملة الإعلانية بنجاح.', time: 'منذ يومين', sender: 'خالد المصري' },
    ],
};

const messageTemplates = [
    { id: 'TPL01', name: 'عرض ترويجي', content: 'مرحباً [اسم العميل]، يسعدنا أن نقدم لك عرضًا خاصًا على باقتنا الاحترافية. خصم 20% لفترة محدودة!' },
    { id: 'TPL02', name: 'متابعة', content: 'مرحباً [اسم العميل]، نود المتابعة بخصوص استفسارك الأخير. هل لديك أي أسئلة أخرى؟' },
    { id: 'TPL03', name: 'إعلان خدمة جديدة', content: 'نحن متحمسون لإعلان إطلاق خدمتنا الجديدة [اسم الخدمة]! تعرف على المزيد من خلال موقعنا.' },
];

const contactGroups = [
    { id: 'GRP01', name: 'عملاء محتملون' },
    { id: 'GRP02', name: 'عملاء الباقة الأساسية' },
    { id: 'GRP03', name: 'شركاء النجاح' },
];

type MessageRole = 'me' | 'other' | 'assistant' | 'me-assistant';

export default function MessagesPage() {
    const [selectedConversation, setSelectedConversation] = useState(conversations[0]);
    const [messages, setMessages] = useState<any[]>(initialMessages[conversations[0].id]);
    const [newMessage, setNewMessage] = useState('');
    const [isNewMessageDialogOpen, setIsNewMessageDialogOpen] = useState(false);
    const [activeTab, setActiveTab] = useState('all');


    const handleSelectConversation = (conv: typeof conversations[0]) => {
        setSelectedConversation(conv);
        setMessages(initialMessages[conv.id] || []);
    }

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !selectedConversation) return;
        const newMsg = {
            id: `MSG${Date.now()}`,
            role: 'me' as const,
            content: newMessage,
            time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
        };
        setMessages([...messages, newMsg]);
        setNewMessage('');
    }

    const filteredConversations = (type: ConversationType | 'all') => {
        if (type === 'all') return conversations;
        return conversations.filter(c => c.type === type);
    }
    
    const getMessageAvatar = (role: MessageRole) => {
        switch (role) {
            case 'me':
            case 'me-assistant':
                return <AvatarImage src="https://placehold.co/100x100.png" alt="User" data-ai-hint="person" />;
            case 'assistant':
                 return <AvatarFallback><Bot size={18} /></AvatarFallback>;
            default:
                 return <AvatarImage src={selectedConversation.avatar} alt={selectedConversation.name} data-ai-hint="person" />;
        }
    }


    return (
        <div className="flex flex-col h-[calc(100vh-120px)] bg-background border rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-12 h-full overflow-hidden">
                {/* Conversations List */}
                <div className="md:col-span-4 lg:col-span-3 border-l flex flex-col bg-muted/20">
                     <div className="p-4 border-b shrink-0 space-y-4">
                         <div className="flex items-center justify-between">
                            <h1 className="text-xl font-bold tracking-tight font-headline">صندوق الوارد</h1>
                            <Button variant="ghost" size="icon" onClick={() => setIsNewMessageDialogOpen(true)}>
                                <MessageSquarePlus className="h-5 w-5" />
                            </Button>
                         </div>
                         <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input placeholder="بحث..." className="pr-9 bg-background" />
                        </div>
                    </div>
                     <Tabs defaultValue="all" onValueChange={setActiveTab} className="flex flex-col flex-grow">
                        <TabsList className="grid w-full grid-cols-4 h-auto rounded-none p-0 bg-muted/50">
                            <TabsTrigger value="all" className="rounded-none data-[state=active]:bg-background">الكل</TabsTrigger>
                            <TabsTrigger value="client" className="rounded-none data-[state=active]:bg-background">العملاء</TabsTrigger>
                            <TabsTrigger value="team" className="rounded-none data-[state=active]:bg-background">الفريق</TabsTrigger>
                            <TabsTrigger value="ai" className="rounded-none data-[state=active]:bg-background">الذكاء الاصطناعي</TabsTrigger>
                        </TabsList>
                        
                        <ScrollArea className="flex-grow">
                             {filteredConversations(activeTab as ConversationType | 'all').map(conv => (
                                 <div key={conv.id}
                                     className={cn(
                                        "flex items-start gap-3 p-4 cursor-pointer border-b hover:bg-muted/50",
                                         selectedConversation?.id === conv.id && "bg-muted"
                                     )}
                                     onClick={() => handleSelectConversation(conv)}
                                 >
                                    <Avatar className="h-12 w-12 border-2" data-ai-hint={conv.type === 'ai' ? '' : 'person'}>
                                        {conv.type !== 'ai' ? 
                                         <AvatarImage src={conv.avatar} alt={conv.name} />
                                         : <AvatarFallback><Bot /></AvatarFallback>}
                                        <AvatarFallback>{conv.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1 overflow-hidden">
                                        <div className="flex justify-between items-center">
                                            <p className="font-semibold truncate">{conv.name}</p>
                                            <p className="text-xs text-muted-foreground shrink-0">{conv.time}</p>
                                        </div>
                                        <div className="flex justify-between items-start mt-1">
                                             <p className="text-sm text-muted-foreground truncate w-[calc(100%-30px)]">{conv.lastMessage}</p>
                                             {conv.unread > 0 && <Badge className="w-5 h-5 flex items-center justify-center p-0 shrink-0">{conv.unread}</Badge>}
                                        </div>
                                        {conv.assistant && <Badge variant="outline" className="mt-2 text-xs">تتم بواسطة {conv.assistant}</Badge>}
                                    </div>
                                 </div>
                            ))}
                        </ScrollArea>
                    </Tabs>
                </div>

                {/* Chat Display */}
                <div className="md:col-span-8 lg:col-span-9 flex flex-col h-full">
                    {selectedConversation ? (
                        <>
                            <div className="p-4 border-b flex items-center justify-between gap-3 bg-background/80 shrink-0">
                                <div className="flex items-center gap-3">
                                    <Avatar className="h-10 w-10">
                                        {selectedConversation.type !== 'ai' ? 
                                            <AvatarImage src={selectedConversation.avatar} alt={selectedConversation.name} data-ai-hint="person" />
                                            : <AvatarFallback><Bot /></AvatarFallback>}
                                        <AvatarFallback>{selectedConversation.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <h2 className="text-lg font-semibold">{selectedConversation.name}</h2>
                                        {selectedConversation.assistant && <Badge variant="secondary" className="text-xs">تتم بواسطة {selectedConversation.assistant}</Badge>}
                                    </div>
                                </div>
                            </div>
                            <ScrollArea className="flex-grow p-4 bg-muted/10">
                                <div className="space-y-6">
                                    {messages.map((msg: any) => (
                                        <div key={msg.id} className={cn("flex items-end gap-3", msg.role === 'me' || msg.role === 'me-assistant' ? "justify-end" : "justify-start")}>
                                            {msg.role !== 'me' && msg.role !== 'me-assistant' && (
                                                <Avatar className="w-8 h-8">
                                                    {getMessageAvatar(msg.role)}
                                                    <AvatarFallback>{msg.sender ? msg.sender.charAt(0) : 'U'}</AvatarFallback>
                                                </Avatar>
                                            )}
                                            <div className="space-y-1 max-w-xs md:max-w-md lg:max-w-2xl">
                                                <div className={cn(
                                                    "rounded-xl px-4 py-2 text-sm shadow-sm",
                                                    msg.role === 'me' ? 'bg-primary text-primary-foreground rounded-br-none' 
                                                    : msg.role === 'me-assistant' ? 'bg-secondary text-secondary-foreground rounded-br-none'
                                                    : 'bg-background rounded-bl-none'
                                                )}>
                                                    {msg.content}
                                                </div>
                                                <div className={cn("flex items-center gap-2 text-xs text-muted-foreground px-1", msg.role === 'me' || msg.role === 'me-assistant' ? 'justify-end' : 'justify-start')}>
                                                    {msg.role === 'me-assistant' && <Bot className="w-3 h-3 text-blue-500" />}
                                                    {msg.role === 'assistant' && <span className="font-medium text-xs">{msg.sender}</span>}
                                                    <span>{msg.time}</span>
                                                </div>
                                            </div>
                                            {(msg.role === 'me' || msg.role === 'me-assistant') && (
                                                <Avatar className="w-8 h-8">
                                                    {getMessageAvatar(msg.role)}
                                                    <AvatarFallback>U</AvatarFallback>
                                                </Avatar>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </ScrollArea>
                            <div className="p-4 border-t bg-background shrink-0">
                                <form onSubmit={handleSendMessage} className="relative">
                                    <Textarea
                                        placeholder="اكتب رسالتك..."
                                        className="flex-1 pr-14 min-h-[60px]"
                                        value={newMessage}
                                        onChange={(e) => setNewMessage(e.target.value)}
                                    />
                                    <Button type="submit" size="icon" className="absolute left-3 top-1/2 -translate-y-1/2">
                                        <Send className="h-5 w-5" />
                                    </Button>
                                </form>
                            </div>
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-full text-muted-foreground">
                            <p>الرجاء تحديد محادثة لعرضها.</p>
                        </div>
                    )}
                </div>
            </div>
            <NewMessageDialog 
                isOpen={isNewMessageDialogOpen}
                setIsOpen={setIsNewMessageDialogOpen}
                contacts={conversations.filter(c => c.type === 'client' || c.type === 'team')}
                groups={contactGroups}
                templates={messageTemplates}
            />
        </div>
    );
}
