

"use client"

import { ColumnDef } from "@tanstack/react-table"
import { Client } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, ArrowUpDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Checkbox } from "../ui/checkbox"
import Link from "next/link"

export const columns: ColumnDef<Client>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "name",
    header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            الاسم
            <ArrowUpDown className="mr-2 h-4 w-4" />
          </Button>
        )
      },
    cell: ({ row }) => {
        return (
          <Link href={`/clients/${row.original.id}`}>
            <div className="font-medium hover:underline">{row.original.name}</div>
          </Link>
        )
    }
  },
  {
    accessorKey: "status",
    header: "الحالة",
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return <Badge variant={status === "active" ? "default" : "secondary"}>{status === "active" ? "نشط" : "غير نشط"}</Badge>
    }
  },
  {
    accessorKey: "serviceType",
    header: "نوع الخدمة",
     cell: ({ row }) => {
      const serviceType = row.getValue("serviceType") as string;
      return <span>{serviceType === "online" ? "أونلاين" : "أوفلاين"}</span>
    }
  },
  {
    accessorKey: "email",
    header: "البريد الإلكتروني",
  },
  {
    accessorKey: "lastActivity",
     header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            آخر نشاط
            <ArrowUpDown className="mr-2 h-4 w-4" />
          </Button>
        )
      },
    cell: ({ row }) => {
        return <span>{new Date(row.original.lastActivity).toLocaleDateString('ar-EG')}</span>
    }
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const client = row.original
 
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">فتح القائمة</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
            <DropdownMenuItem
              onClick={() => navigator.clipboard.writeText(client.id)}
            >
              نسخ معرف العميل
            </DropdownMenuItem>
            <DropdownMenuSeparator />
             <Link href={`/clients/${client.id}`}>
                <DropdownMenuItem>
                    عرض واجهة العميل
                </DropdownMenuItem>
            </Link>
            <DropdownMenuItem>تعديل</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )
    },
  },
]
