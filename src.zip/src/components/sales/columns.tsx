
"use client"

import { ColumnDef } from "@tanstack/react-table"
import { Sale, SaleSource } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, ArrowUpDown, TrendingUp, Users, MessagesSquare, Handshake } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Checkbox } from "../ui/checkbox"
import Link from "next/link"

const sourceMap: { [key in SaleSource]: { text: string; icon: React.ElementType; color: string } } = {
    'campaign': { text: 'حملة إعلانية', icon: TrendingUp, color: 'bg-blue-100 text-blue-800' },
    'direct': { text: 'تسويق مباشر', icon: Handshake, color: 'bg-green-100 text-green-800' },
    'b2b': { text: 'B2B', icon: Users, color: 'bg-purple-100 text-purple-800' },
    'word_of_mouth': { text: 'توصية', icon: MessagesSquare, color: 'bg-yellow-100 text-yellow-800' },
};

export const columns: ColumnDef<Sale>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "clientName",
    header: "العميل",
    cell: ({ row }) => {
        return (
          <Link href={`/clients/${row.original.clientId}`}>
            <div className="font-medium hover:underline">{row.original.clientName}</div>
          </Link>
        )
    }
  },
  {
    accessorKey: "service",
    header: "الخدمة/الباقة",
  },
  {
    accessorKey: "amount",
    header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            المبلغ
            <ArrowUpDown className="mr-2 h-4 w-4" />
          </Button>
        )
    },
    cell: ({ row }) => {
        const amount = parseFloat(row.getValue("amount"))
        const formatted = new Intl.NumberFormat("ar-EG", {
          style: "currency",
          currency: "EGP",
        }).format(amount)
   
        return <div className="font-medium">{formatted}</div>
    }
  },
  {
    accessorKey: "source",
    header: "مصدر البيعة",
    cell: ({ row }) => {
      const source = row.getValue("source") as SaleSource;
      const sourceInfo = sourceMap[source];
      if (!sourceInfo) return null;

      return (
        <Badge variant="outline" className={`gap-1.5 ${sourceInfo.color}`}>
            <sourceInfo.icon className="h-3.5 w-3.5" />
            {sourceInfo.text}
        </Badge>
      )
    },
    filterFn: (row, id, value) => {
        return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: "date",
     header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            تاريخ البيع
            <ArrowUpDown className="mr-2 h-4 w-4" />
          </Button>
        )
      },
    cell: ({ row }) => {
        return <span>{new Date(row.original.date).toLocaleDateString('ar-EG')}</span>
    }
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const sale = row.original
 
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">فتح القائمة</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
            <DropdownMenuItem>عرض الفاتورة</DropdownMenuItem>
            <DropdownMenuItem>تعديل</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )
    },
  },
]
