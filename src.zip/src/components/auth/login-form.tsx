'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { useRouter } from 'next/navigation';

const GoogleIcon = () => (
  <svg className="mr-2 h-4 w-4" viewBox="0 0 48 48">
    <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z" />
    <path fill="#FF3D00" d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691z" />
    <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238C29.211 35.091 26.715 36 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z" />
    <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303c-.792 2.237-2.231 4.166-4.087 5.571l6.19 5.238C42.012 36.417 44 30.836 44 24c0-1.341-.138-2.65-.389-3.917z" />
  </svg>
);

const WhatsAppIcon = () => (
    <svg className="mr-2 h-5 w-5" viewBox="0 0 24 24" fill="currentColor" >
        <path fill="#25D366" d="M19.33 4.67A11.91 11.91 0 0 0 12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12h.01c2.17 0 4.29-.58 6.17-1.7l4.08 1.08l-1.12-3.99a12.01 12.01 0 0 0 2.2-6.72c0-6.63-5.37-12-12-12z" />
        <path fill="white" d="M16.42 13.4c-.1-.14-.34-.23-.72-.42c-.37-.18-.54-.23-2.17-1.08c-1.63-.84-.92-1.03-1.3-1.73s-1.13-1.87-1.37-2.12c-.25-.24-.5-.24-.74-.24c-.24 0-.48.05-.68.1c-.2.05-.52.23-.78.5c-.27.28-.9.9-1.1 2.13s-.2 2.37.1 2.6c.3.24.6.38.78.48c.18.1.35.14.52.23c.17.1.34.14.47.23c.13.1.2.18.2.28s.05.23-.05.42c-.1.18-.52.6-1.1 1.2c-.57.6-1.14 1.2-1.5 1.3c-.34.1-.7.05-1.03-.1c-.33-.14-1.37-.65-2.62-2.12c-1.25-1.47-2.1-3.3-2.17-3.45c-.08-.14-.6-1.3.1-2.5c.7-1.2 1.42-1.5 1.8-1.55c.37-.05.74-.05.98-.05c.24 0 .48 0 .68.05c.2.05.47-.1.73-.78c.27-.68.47-1.3.52-1.43c.04-.13.1-.23.18-.23c.08 0 .17 0 .26 0h.18c.08 0 .22 0 .3.05c.08.05.18.1.26.18c.08.08.13.18.18.28c.04.1.23.6.42 1.2s.38 1.2.43 1.3c.05.1.1.18.2.28c.1.1.2.14.3.18c.1.05.2.1.3.1s.2.05.28.05c.08 0 .2-.05.3-.1c.1-.05.2-.1.28-.14c.08-.05.17-.1.26-.14c.08-.05.17-.1.26-.14c.1-.05.18-.1.27-.14c.08-.05.17-.1.26-.14c.1-.05.18-.1.27-.14l.18-.1c.08 0 .17.05.26.1c.08.05.17.1.26.18s.17.18.26.28c.08.1.17.2.26.3c.08.1.17.2.26.3c.08.1.17.2.26.3l.18.2c.08.1.17.2.26.3c.08.1.17.2.26.3c.08.1.17.2.26.3c.18.2.3.4.4.63c.1.23.14.48.14.73c0 .24-.05.48-.14.68c-.1.2-.23.38-.4.52z"/>
    </svg>
);

export function LoginForm() {
  const router = useRouter();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you'd handle form validation and submission here.
    // For this scaffold, we'll just navigate to the dashboard.
    router.push('/dashboard');
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Button variant="outline" className="w-full">
          <GoogleIcon />
          Google
        </Button>
        <Button variant="outline" className="w-full">
          <WhatsAppIcon />
          WhatsApp
        </Button>
      </div>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2 text-muted-foreground">
            أو أكمل بالبريد الإلكتروني
          </span>
        </div>
      </div>

      <form onSubmit={handleLogin} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">البريد الإلكتروني</Label>
          <Input id="email" type="email" placeholder="name@example.com" required />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">كلمة المرور</Label>
            <a href="#" className="text-sm text-accent hover:underline">
              نسيت كلمة المرور؟
            </a>
          </div>
          <Input id="password" type="password" required />
        </div>
        <Button type="submit" className="w-full">
          تسجيل الدخول
        </Button>
      </form>
    </div>
  );
}
