// src/components/spaces/task-board.tsx
'use client'

import React, { useState, useEffect } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { TouchBackend } from 'react-dnd-touch-backend';
import { Card, CardContent } from '@/components/ui/card';
import { Task, TaskStatus } from '@/lib/types';
import { cn } from '@/lib/utils';
import { CheckCircle, Clock, GripVertical } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';


interface TaskCardProps {
    task: Task;
    index: number;
    moveCard: (dragIndex: number, hoverIndex: number, status: TaskStatus) => void;
}

const ItemType = 'CARD';

const TaskCard: React.FC<TaskCardProps> = ({ task, index, moveCard }) => {
  const ref = React.useRef<HTMLDivElement>(null);

  const [, drop] = useDrop({
    accept: ItemType,
    hover(item: { index: number; status: TaskStatus }, monitor) {
      if (!ref.current) {
        return;
      }
      const dragIndex = item.index;
      const hoverIndex = index;
      const dragStatus = item.status;

      if (dragIndex === hoverIndex && dragStatus === task.status) {
        return;
      }
      moveCard(dragIndex, hoverIndex, task.status);
      item.index = hoverIndex;
      item.status = task.status;
    },
  });

  const [{ isDragging }, drag, preview] = useDrag({
    type: ItemType,
    item: { id: task.id, index, status: task.status },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  preview(drop(ref));

  return (
    <div ref={ref} style={{ opacity: isDragging ? 0.5 : 1 }} className="mb-3">
        <Card className="hover:shadow-md transition-shadow group">
            <CardContent className="p-3 flex items-center gap-2">
                <div ref={drag} className="cursor-move p-1 text-muted-foreground group-hover:text-foreground">
                   <GripVertical className="w-5 h-5"/>
                </div>
                <p className="flex-grow text-sm font-medium">{task.title}</p>
            </CardContent>
        </Card>
    </div>
  );
};


interface TaskColumnProps {
    status: TaskStatus;
    title: string;
    tasks: Task[];
    moveCard: (dragIndex: number, hoverIndex: number, sourceStatus: TaskStatus, targetStatus: TaskStatus) => void;
}


const TaskColumn: React.FC<TaskColumnProps> = ({ status, title, tasks, moveCard }) => {
    const ref = React.useRef<HTMLDivElement>(null);
    const [, drop] = useDrop({
        accept: ItemType,
        drop: (item: { id: string; index: number; status: TaskStatus }) => {
            if (item.status !== status) {
                moveCard(item.index, tasks.length, item.status, status);
            }
        },
    });

    drop(ref);
    
    const statusMap = {
        'todo': { icon: Clock, color: 'text-gray-500' },
        'in-progress': { icon: Clock, color: 'text-blue-500' },
        'completed': { icon: CheckCircle, color: 'text-green-500' },
    };

    const StatusIcon = statusMap[status].icon;

    return (
        <div ref={ref} className="bg-muted/50 rounded-lg h-full w-full">
            <h3 className="text-lg font-semibold p-4 border-b flex items-center gap-2">
                <StatusIcon className={`w-5 h-5 ${statusMap[status].color}`} />
                 {title}
                <span className="text-sm text-muted-foreground">({tasks.length})</span>
            </h3>
            <div className="p-4 min-h-[200px]">
                {tasks.map((task, index) => (
                    <TaskCard 
                        key={task.id} 
                        index={index} 
                        task={task} 
                        moveCard={(dragIndex, hoverIndex) => moveCard(dragIndex, hoverIndex, status, status)}
                    />
                ))}
                 {tasks.length === 0 && (
                    <div className="text-center text-sm text-muted-foreground py-10 border-2 border-dashed rounded-lg">
                        اسحب المهام إلى هنا
                    </div>
                 )}
            </div>
        </div>
    );
};


interface TaskBoardProps {
    initialTasks: Task[];
    setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
}

export const TaskBoard: React.FC<TaskBoardProps> = ({ initialTasks, setTasks }) => {
    const isMobile = useIsMobile();
    const DndBackend = isMobile ? TouchBackend : HTML5Backend;

    const moveCard = (dragIndex: number, hoverIndex: number, sourceStatus: TaskStatus, targetStatus: TaskStatus) => {
        setTasks(prevTasks => {
            const newTasks = [...prevTasks];
            const sourceTasks = newTasks.filter(t => t.status === sourceStatus);
            const [draggedCard] = sourceTasks.splice(dragIndex, 1);
            
            if (!draggedCard) return newTasks;

            const otherTasks = newTasks.filter(t => t.status !== sourceStatus);

            if (sourceStatus === targetStatus) {
                // Moving within the same column
                sourceTasks.splice(hoverIndex, 0, draggedCard);
                return [...otherTasks, ...sourceTasks];
            } else {
                // Moving to a different column
                draggedCard.status = targetStatus;
                const targetTasks = newTasks.filter(t => t.status === targetStatus);
                targetTasks.splice(hoverIndex, 0, draggedCard);

                const finalTasks = newTasks.filter(t => t.id !== draggedCard.id);
                finalTasks.push(draggedCard);

                // This is a simplified re-ordering. For more complex scenarios,
                // you might want a more sophisticated state structure.
                // For now, we'll just re-group them.
                const grouped = finalTasks.reduce((acc, task) => {
                    acc[task.status] = acc[task.status] || [];
                    acc[task.status].push(task);
                    return acc;
                }, {} as Record<TaskStatus, Task[]>);

                return [
                    ...(grouped.todo || []),
                    ...(grouped['in-progress'] || []),
                    ...(grouped.completed || [])
                ];
            }
        });
    };

    const columns: { status: TaskStatus; title: string }[] = [
        { status: 'todo', title: 'قيد الانتظار' },
        { status: 'in-progress', title: 'قيد التنفيذ' },
        { status: 'completed', title: 'مكتمل' },
    ];

    return (
        <DndProvider backend={DndBackend}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
                {columns.map(col => (
                    <TaskColumn
                        key={col.status}
                        status={col.status}
                        title={col.title}
                        tasks={initialTasks.filter(t => t.status === col.status)}
                        moveCard={moveCard}
                    />
                ))}
            </div>
        </DndProvider>
    );
};
