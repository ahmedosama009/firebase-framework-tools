'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '../ui/textarea';
import { Space } from '@/lib/types';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CreateSpaceDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  onCreateSpace: (newSpace: Omit<Space, 'generatedContent' | 'tasks'>) => void;
}

export function CreateSpaceDialog({ isOpen, setIsOpen, onCreateSpace }: CreateSpaceDialogProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!name.trim() || !description.trim()) {
      toast({
        title: 'خطأ في الإدخال',
        description: 'الرجاء ملء اسم ووصف مساحة العمل.',
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);
    // Simulate creation
    await new Promise(resolve => setTimeout(resolve, 500));

    try {
      const newSpace: Omit<Space, 'generatedContent' | 'tasks'> = {
        id: `SP${Date.now()}`,
        name,
        description,
        createdAt: new Date().toISOString(),
        status: 'تخطيط',
        tasksCount: 0,
        teamAvatars: []
      };
      onCreateSpace(newSpace);
      toast({
        title: 'نجاح!',
        description: 'تم إنشاء مساحة العمل بنجاح.',
      });
      setIsOpen(false);
      setName('');
      setDescription('');
    } catch (error) {
      toast({
        title: 'حدث خطأ',
        description: 'فشل إنشاء مساحة العمل. الرجاء المحاولة مرة أخرى.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>إنشاء مساحة عمل جديدة</DialogTitle>
          <DialogDescription>
            ابدأ حملة جديدة أو خطة محتوى. صف الفكرة العامة هنا.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم الحملة / المساحة</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: حملة إطلاق مجموعة الصيف"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">وصف تفصيلي</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="صف أهداف الحملة، الجمهور المستهدف، والرسالة الرئيسية..."
              className="min-h-[120px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>
            إلغاء
          </Button>
          <Button type="submit" onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                جاري الإنشاء...
              </>
            ) : (
              'أنشئ مساحة العمل'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
