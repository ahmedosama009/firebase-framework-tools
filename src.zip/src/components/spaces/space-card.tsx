

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Space } from '@/lib/types';
import { Button } from '../ui/button';
import { MoreVertical, Calendar, CheckCircle, ClipboardList, Clock } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../ui/dropdown-menu';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import Link from 'next/link';

interface SpaceCardProps {
    space: Space;
}

const statusMap = {
    'تخطيط': { icon: ClipboardList, color: 'bg-yellow-500' },
    'قيد التنفيذ': { icon: Clock, color: 'bg-blue-500' },
    'مكتمل': { icon: CheckCircle, color: 'bg-green-500' },
};

export function SpaceCard({ space }: SpaceCardProps) {
    const statusInfo = statusMap[space.status as keyof typeof statusMap] || statusMap['تخطيط'];
    const progressValue = space.status === 'مكتمل' ? 100 : (space.status === 'قيد التنفيذ' ? 60 : 25);

    return (
        <Card className="flex flex-col hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-start justify-between">
                <div>
                    <CardTitle className="font-headline text-lg">{space.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1 text-xs mt-1">
                       <Calendar className="w-3 h-3"/>
                        {new Date(space.createdAt).toLocaleDateString('ar-EG', { month: 'long', day: 'numeric' })}
                    </CardDescription>
                </div>
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                            <Link href={`/spaces/${space.id}`} className="w-full">عرض التفاصيل</Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem>إدارة المهام</DropdownMenuItem>
                        <DropdownMenuItem>تعديل</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">أرشفة</DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </CardHeader>
            <CardContent className="flex-grow space-y-4">
                <p className="text-sm text-muted-foreground">{space.description}</p>
                
                <div>
                     <Progress value={progressValue} className="h-2" />
                     <div className="flex justify-between items-center mt-2">
                        <Badge variant="outline" className="flex items-center gap-1.5 py-1">
                            <span className={`w-2 h-2 rounded-full ${statusInfo.color}`}></span>
                            <span>{space.status}</span>
                        </Badge>
                        <div className="flex items-center text-sm text-muted-foreground">
                            <ClipboardList className="w-4 h-4 ml-1" />
                            <span>{space.tasksCount} مهام</span>
                        </div>
                    </div>
                </div>

            </CardContent>
            <CardFooter className="justify-between items-center">
                <div className="flex -space-x-2 rtl:space-x-reverse overflow-hidden">
                    {space.teamAvatars?.map((avatar, index) => (
                        <Avatar key={index} className="w-8 h-8 border-2 border-card">
                            <AvatarImage src={avatar} data-ai-hint="person" />
                            <AvatarFallback>{index}</AvatarFallback>
                        </Avatar>
                    ))}
                </div>
                <Button asChild variant="secondary" size="sm">
                    <Link href={`/spaces/${space.id}`}>
                        فتح مساحة العمل
                    </Link>
                </Button>
            </CardFooter>
        </Card>
    );
}
