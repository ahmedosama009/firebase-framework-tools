
// src/components/icons/logo.tsx
'use client';
import * as React from 'react';
import Image from 'next/image';
import { useBrand } from '@/components/settings/brand-provider';

const DefaultLogo = (props: React.SVGProps<SVGSVGElement>) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 160 40"
      width="180"
      height="50"
      {...props}
    >
        <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" style={{ stopColor: 'hsl(var(--primary))', stopOpacity: 1 }} />
                <stop offset="100%" style={{ stopColor: 'hsl(var(--accent))', stopOpacity: 1 }} />
            </linearGradient>
        </defs>
        
        {/* Circle Background */}
        <circle cx="20" cy="20" r="18" fill="hsl(var(--primary))" fillOpacity="0.1" />
        
        {/* Icon */}
        <g transform="translate(-10, 0) scale(0.8)">
             <path d="M19.4,3.7c-0.9-0.9-2-1.3-3.4-1.3c-1.3,0-2.5,0.4-3.4,1.3c-0.9,0.9-1.3,2-1.3,3.4c0,1.3,0.4,2.5,1.3,3.4  c0.9,0.9,2,1.3,3.4,1.3c1.3,0,2.5-0.4,3.4-1.3c0.9-0.9,1.3-2,1.3-3.4C20.7,5.7,20.3,4.5,19.4,3.7z M16,10.4c-1,0-1.8-0.3-2.4-1  c-0.6-0.6-1-1.5-1-2.4c0-1,0.3-1.8,1-2.4c0.6-0.6,1.5-1,2.4-1c1,0,1.8,0.3,2.4,1c0.6,0.6,1,1.5,1,2.4c0,1-0.3,1.8-1,2.4  C17.8,10.1,17,10.4,16,10.4z" transform="translate(15, 13)" fill="url(#grad1)" />
             <path d="M26.2,25H5.8c-1.1,0-2-0.9-2-2V8.1c0-1.1,0.9-2,2-2h6.5v2.6H5.8C5.5,8.7,5.2,9,5.2,9.3v14.4  c0,0.3,0.2,0.6,0.6,0.6h20.5c0.3,0,0.6-0.2,0.6-0.6V9.3c0-0.3-0.2-0.6-0.6-0.6h-6.5V6.1h6.5c1.1,0,2,0.9,2,2v14.9  C28.2,24.1,27.3,25,26.2,25z" transform="translate(15, 13)" fill="url(#grad1)"/>
        </g>
        
        {/* Text */}
        <text
            x="98"
            y="50%"
            dominantBaseline="middle"
            textAnchor="middle"
            fontFamily="'Poppins', 'Tajawal', sans-serif"
            fontSize="24"
            fontWeight="bold"
            fill="url(#grad1)"
        >
            Infinity
        </text>
    </svg>
);


export const Logo = (props: React.SVGProps<SVGSVGElement> & {className?: string}) => {
  const { brand, isLoaded } = useBrand();

  if (!isLoaded || !brand.logoUrl) {
    return <DefaultLogo {...props} />;
  }

  return (
    <Image 
      src={brand.logoUrl} 
      alt={brand.companyName || 'Company Logo'} 
      width={180}
      height={50}
      style={{ objectFit: 'contain', width: '180px', height: '50px' }}
      {...props as any}
    />
  );
};
