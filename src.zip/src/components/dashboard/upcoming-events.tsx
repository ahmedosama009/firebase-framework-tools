import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'

const events = [
    { name: "اجتماع مع العميل 'أ'", time: '10:00 صباحًا', person: 'أحمد محمود' },
    { name: "مكالمة متابعة", time: '2:00 مساءً', person: 'فاطمة علي' },
    { name: "عرض تجريبي للمنتج", time: '4:30 مساءً', person: 'يوسف خالد' },
]

export function UpcomingEvents() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>الأحداث القادمة</CardTitle>
        <CardDescription>لديك {events.length} مواعيد اليوم.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {events.map((event, index) => (
             <div key={index} className="flex items-center gap-4">
                <Avatar className="h-9 w-9">
                    <AvatarImage src={`https://placehold.co/100x100.png?text=${event.person.charAt(0)}`} alt="Avatar" data-ai-hint="person" />
                    <AvatarFallback>{event.person.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">{event.name}</p>
                    <p className="text-sm text-muted-foreground">{event.person}</p>
                </div>
                <div className="text-sm font-medium">{event.time}</div>
            </div>
        ))}
      </CardContent>
    </Card>
  )
}
