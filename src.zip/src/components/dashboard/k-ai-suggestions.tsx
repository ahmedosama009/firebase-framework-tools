
'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lightbulb, TrendingUp, Megaphone, Check, Zap, Bot, BrainCircuit, Target, Sparkles, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Badge } from '../ui/badge';
import { cn } from '@/lib/utils';

const initialSuggestions = [
    {
        id: 'sug1',
        icon: BrainCircuit,
        title: 'اقتراح: تحسين نبرة المحتوى',
        description: 'المساعد "نورا" لاحظ أن تفاعل الجمهور يزيد مع النبرة "الودية". نقترح تحديث هوية العلامة التجارية.',
        action: 'تحديث الهوية',
        category: 'تحسين',
        categoryColor: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300 border-blue-200 dark:border-blue-700'
    },
    {
        id: 'sug2',
        icon: Target,
        title: 'فرصة: استغلال موضوع رائج',
        description: 'تحليل "راية" يظهر اهتماماً متزايداً بـ "التصميم المستدام". يمكن إنشاء محتوى حول هذا الموضوع.',
        action: 'إنشاء مساحة جديدة',
        category: 'فرصة',
        categoryColor: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300 border-green-200 dark:border-green-700'
    },
    {
        id: 'sug3',
        icon: Sparkles,
        title: 'توصية: إطلاق حملة جديدة',
        description: 'بناءً على أداء الحملات السابقة، يقترح "فلك" إطلاق حملة تركز على "عروض نهاية الأسبوع".',
        action: 'إدارة الحملات',
        category: 'توصية',
        categoryColor: 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300 border-purple-200 dark:border-purple-700'
    },
];

export function KAiSuggestions() {
    const [suggestions, setSuggestions] = useState(initialSuggestions);
    const [dismissed, setDismissed] = useState<string[]>([]);

    const handleDismiss = (id: string) => {
        setDismissed(prev => [...prev, id]);
    };

    const activeSuggestions = suggestions.filter(s => !dismissed.includes(s.id));

    return (
        <Card className="shadow-lg border-primary/20">
            <CardHeader>
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-full">
                        <Bot className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                        <CardTitle className="font-headline text-xl">صندوق الوارد للمساعد K</CardTitle>
                        <CardDescription>اقتراحات وتوصيات ذكية لتحسين أعمالك.</CardDescription>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                {activeSuggestions.length > 0 ? activeSuggestions.map((item) => (
                    <div key={item.id} className={cn(
                        "flex items-start gap-4 p-4 rounded-lg bg-muted/50 transition-all hover:bg-muted"
                    )}>
                        <div className="p-3 bg-background rounded-full border">
                            <item.icon className="w-5 h-5 text-accent" />
                        </div>
                        <div className="flex-1">
                            <div className='flex items-center justify-between'>
                                <h4 className="font-semibold">{item.title}</h4>
                                <Badge variant="outline" className={`border-0 ${item.categoryColor}`}>{item.category}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1 mb-3">{item.description}</p>
                            <div className="flex gap-2">
                                <Button size="sm">
                                    <Zap className="ml-1 h-4 w-4" />
                                    {item.action}
                                </Button>
                                <Button size="sm" variant="ghost" onClick={() => handleDismiss(item.id)}>
                                    <ThumbsUp className="ml-1 h-4 w-4" />
                                    مفيد
                                </Button>
                                 <Button size="sm" variant="ghost" onClick={() => handleDismiss(item.id)} className="text-muted-foreground">
                                    <ThumbsDown className="ml-1 h-4 w-4" />
                                    غير مفيد
                                </Button>
                            </div>
                        </div>
                    </div>
                )) : (
                     <div className="text-center py-10 text-muted-foreground">
                        <Check className="mx-auto h-12 w-12 text-green-500" />
                        <p className="mt-4 font-semibold">لا توجد اقتراحات جديدة!</p>
                        <p className="text-sm">لقد اطلعت على جميع التوصيات الحالية.</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
