
'use client';

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Bot, Send } from 'lucide-react';

interface Contact {
  id: string;
  name: string;
}

interface Group {
  id: string;
  name: string;
}

interface Template {
  id: string;
  name: string;
  content: string;
}

interface NewMessageDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  contacts: Contact[];
  groups: Group[];
  templates: Template[];
}

export function NewMessageDialog({
  isOpen,
  setIsOpen,
  contacts,
  groups,
  templates,
}: NewMessageDialogProps) {
  const [recipient, setRecipient] = useState('');
  const [message, setMessage] = useState('');
  const { toast } = useToast();

  const handleTemplateChange = (templateId: string) => {
    const template = templates.find((t) => t.id === templateId);
    if (template) {
      setMessage(template.content);
    }
  };

  const handleSend = () => {
    if (!recipient || !message.trim()) {
      toast({
        title: 'خطأ',
        description: 'الرجاء تحديد مستلم وكتابة رسالة.',
        variant: 'destructive',
      });
      return;
    }
    // In a real app, you would handle the sending logic here.
    toast({
      title: 'تم الإرسال بنجاح!',
      description: `تم إرسال رسالتك إلى ${recipient}.`,
    });
    setIsOpen(false);
    setRecipient('');
    setMessage('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>رسالة جديدة</DialogTitle>
          <DialogDescription>
            ابدأ محادثة جديدة مع أحد العملاء أو أرسل رسالة جماعية.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="recipient">إلى:</Label>
            <Select onValueChange={setRecipient} value={recipient}>
              <SelectTrigger id="recipient">
                <SelectValue placeholder="اختر مستلمًا أو مجموعة" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <Label className="px-2 py-1.5 text-xs font-semibold">المجموعات</Label>
                  {groups.map((group) => (
                    <SelectItem key={group.id} value={group.name}>
                      {group.name}
                    </SelectItem>
                  ))}
                </SelectGroup>
                <SelectGroup>
                  <Label className="px-2 py-1.5 text-xs font-semibold">الأفراد</Label>
                  {contacts.map((contact) => (
                    <SelectItem key={contact.id} value={contact.name}>
                      {contact.name}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
             <div className="flex justify-between items-center">
                <Label htmlFor="message">الرسالة:</Label>
                <Select onValueChange={handleTemplateChange}>
                    <SelectTrigger className="w-auto h-8 text-xs px-2 border-dashed">
                        <SelectValue placeholder="استخدام قالب..." />
                    </SelectTrigger>
                    <SelectContent>
                        {templates.map(template => (
                             <SelectItem key={template.id} value={template.id}>{template.name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
             </div>
            <Textarea
              id="message"
              placeholder="اكتب رسالتك هنا..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="min-h-[150px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>
            إلغاء
          </Button>
          <Button onClick={handleSend}>
            <Send className="ml-2 h-4 w-4" />
            إرسال
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
