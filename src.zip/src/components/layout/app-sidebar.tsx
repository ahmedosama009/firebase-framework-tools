

'use client';

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarSeparator,
} from '@/components/ui/sidebar';
import { Logo } from '@/components/icons/logo';
import {
  LayoutDashboard,
  Users,
  Box,
  Settings,
  LogOut,
  ChevronDown,
  Briefcase,
  BadgeDollarSign,
  MessageSquare,
  Bot,
  Calendar,
  ClipboardCheck,
  Users2,
  Phone,
  DollarSign,
  Download,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import { Button } from '../ui/button';
import { useBrand } from '../settings/brand-provider';

const menuItems = [
  { href: '/dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
  { href: '/sales', label: 'المبيعات', icon: DollarSign },
  { href: '/clients', label: 'العملاء', icon: Users },
  { href: '/tasks', label: 'المهام', icon: ClipboardCheck },
  { href: '/team', label: 'الفريق', icon: Users2 },
  { href: '/calendar', label: 'التقويم', icon: Calendar },
  { href: '/call-center', label: 'مركز الاتصال', icon: Phone },
  { href: '/messages', label: 'الرسائل', icon: MessageSquare },
  { href: '/spaces', label: 'المساحات', icon: Box },
  { href: '/services', label: 'الخدمات', icon: Briefcase },
  { href: '/pricing', label: 'التسعير', icon: BadgeDollarSign },
  { href: '/assistants', label: 'المساعدين', icon: Bot },
  { href: '/settings', label: 'الإعدادات', icon: Settings },
];

export function AppSidebar() {
  const pathname = usePathname();
  const { brand } = useBrand();

  return (
    <Sidebar>
        <SidebarHeader>
          <Logo />
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {menuItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname.startsWith(item.href) && (item.href !== '/settings' || pathname === item.href) || (item.href === '/settings' && pathname.startsWith('/settings'))}
                >
                  <Link href={item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
            <SidebarSeparator className="my-2" />
             <SidebarMenuItem>
                <SidebarMenuButton>
                    <Download />
                    <span>تحميل التطبيق</span>
                </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarContent>
        <SidebarSeparator />
        <SidebarFooter>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="w-full justify-between h-auto p-2">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="https://placehold.co/100x100.png" alt="User" data-ai-hint="person" />
                    <AvatarFallback>U</AvatarFallback>
                  </Avatar>
                  <div className="text-right">
                    <p className="text-sm font-medium">{brand.companyName || 'اسم الشركة'}</p>
                    <p className="text-xs text-muted-foreground">مستخدم تجريبي</p>
                  </div>
                </div>
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
               <DropdownMenuItem>
                <LogOut className="mr-2 h-4 w-4" />
                <span>تسجيل الخروج</span>
               </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </SidebarFooter>
    </Sidebar>
  );
}
