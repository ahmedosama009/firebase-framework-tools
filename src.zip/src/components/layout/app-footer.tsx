
export function AppFooter() {
    return (
        <footer className="py-2 px-4 md:px-6 border-t bg-background text-center text-xs text-muted-foreground">
            <p>&copy; 2025 Infinity Alkayan. All Rights Reserved.</p>
            <p className="mt-1">Alkayan Marketing Agency &reg; 2020-2025</p>
        </footer>
    );
}
