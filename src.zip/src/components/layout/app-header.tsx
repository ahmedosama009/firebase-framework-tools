

'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  Bell,
  Menu,
  Search,
  MessageSquare,
  Phone,
} from 'lucide-react';
import { AppSidebar } from './app-sidebar';
import { useSidebar } from '../ui/sidebar';
import Link from 'next/link';

export function AppHeader() {
  const { toggleSidebar } = useSidebar();

  return (
    <header className="flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6 sticky top-0 z-30">
        <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="md:hidden"
        >
            <Menu className="h-6 w-6" />
            <span className="sr-only">Toggle navigation menu</span>
        </Button>

      <div className="relative flex-1">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="ابحث في المنصة..."
          className="w-full appearance-none bg-muted pl-8 shadow-none md:w-2/3 lg:w-1/3"
        />
      </div>
      <div className="flex items-center gap-2">
        <Button asChild variant="ghost" size="icon" className="rounded-full">
          <Link href="/messages">
            <MessageSquare className="h-5 w-5" />
            <span className="sr-only">Toggle messages</span>
          </Link>
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full">
          <Bell className="h-5 w-5" />
          <span className="sr-only">Toggle notifications</span>
        </Button>
      </div>
    </header>
  );
}
