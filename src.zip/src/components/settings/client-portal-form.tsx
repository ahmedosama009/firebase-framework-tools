

"use client"

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { useState, useEffect } from "react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card"
import { Switch } from "../ui/switch"
import { Textarea } from "../ui/textarea"
import { toast } from "@/hooks/use-toast"
import { Checkbox } from "../ui/checkbox"
import { ExternalLink } from "lucide-react"
import { getServices } from "@/lib/data/services"
import { getPricingPlans } from "@/lib/data/pricing"
import { Service, PricingPlan } from "@/lib/types"

const clientPortalSchema = z.object({
  portalEnabled: z.boolean().default(false).optional(),
  welcomeMessage: z.string().optional(),
  availableItems: z.array(z.string()).refine((value) => value.some((item) => item), {
    message: "يجب عليك اختيار خدمة أو عرض واحد على الأقل.",
  }),
})

type ClientPortalValues = z.infer<typeof clientPortalSchema>

export function ClientPortalForm() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [allItems, setAllItems] = useState<{ id: string; label: string; group: string; }[]>([]);
    
    useEffect(() => {
        async function loadData() {
            // In a real app, this should fetch based on the logged-in user's companyId
            const services = await getServices('alkayan-infinity');
            const plans = await getPricingPlans();
            const combinedItems = [
                ...services.map(s => ({ id: s.id, label: s.name, group: "الخدمات" })),
                ...plans.map(p => ({ id: p.id, label: p.name, group: "الباقات" }))
            ];
            setAllItems(combinedItems);
        }
        loadData();
    }, []);

    const form = useForm<ClientPortalValues>({
        resolver: zodResolver(clientPortalSchema),
        defaultValues: {
            portalEnabled: true,
            welcomeMessage: "مرحباً بك في واجهة العميل الخاصة بك. من هنا يمكنك متابعة طلباتك وإنشاء طلبات جديدة.",
            availableItems: [], // Default will be set after data loads
        },
    });

    useEffect(() => {
        if(allItems.length > 0) {
            form.reset({
                ...form.getValues(),
                availableItems: [allItems[0].id, allItems.find(item => item.group === "الباقات")?.id ?? '']
            })
        }
    }, [allItems, form]);
    
    function onSubmit(data: ClientPortalValues) {
        setIsSubmitting(true);
        console.log(data);
        
        toast({
            title: "تم الحفظ بنجاح!",
            description: "تم تحديث إعدادات واجهة العملاء.",
        });
        setIsSubmitting(false);
    }

  return (
    <Card>
        <CardHeader>
            <div className="flex items-center justify-between">
                <div>
                    <CardTitle>إعدادات واجهة العملاء</CardTitle>
                    <CardDescription>
                        إدارة الإعدادات التي يواجهها عملاؤك عند التفاعل مع علامتك التجارية.
                    </CardDescription>
                </div>
                <Button asChild variant="outline">
                    <Link href="/clients/CLT001" target="_blank">
                       <ExternalLink className="ml-2 h-4 w-4" />
                        معاينة الواجهة
                    </Link>
                </Button>
            </div>
        </CardHeader>
        <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                
                <FormField
                    control={form.control}
                    name="portalEnabled"
                    render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                            <FormLabel className="text-base">تفعيل واجهة العملاء</FormLabel>
                            <FormDescription>
                                السماح للعملاء بتسجيل الدخول إلى واجهة خاصة بهم لمتابعة الطلبات.
                            </FormDescription>
                        </div>
                        <FormControl>
                            <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            />
                        </FormControl>
                        </FormItem>
                    )}
                />

                 <FormField
                  control={form.control}
                  name="welcomeMessage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>رسالة ترحيبية في الواجهة</FormLabel>
                      <FormControl>
                        <Textarea placeholder="اكتب رسالة ترحيبية لعملائك..." {...field} />
                      </FormControl>
                      <FormDescription>
                        ستظهر هذه الرسالة لعملائك عند دخولهم لواجهتهم الخاصة.
                      </FormDescription>
                    </FormItem>
                  )}
                />

                 <FormField
                    control={form.control}
                    name="availableItems"
                    render={() => (
                        <FormItem>
                        <div className="mb-4">
                            <FormLabel className="text-base">الخدمات والعروض المتاحة للطلب</FormLabel>
                            <FormDescription>
                                اختر الخدمات والباقات التي يمكن للعميل طلبها مباشرة من خلال الواجهة.
                            </FormDescription>
                        </div>
                        <div className="space-y-4">
                            {['الخدمات', 'الباقات'].map((group) => (
                                <div key={group} className="rounded-lg border p-4">
                                     <FormLabel className="text-lg font-semibold mb-2 block">{group}</FormLabel>
                                     <div className="space-y-2">
                                        {allItems.filter(item => item.group === group).map((item) => (
                                            <FormField
                                            key={item.id}
                                            control={form.control}
                                            name="availableItems"
                                            render={({ field }) => {
                                                return (
                                                <FormItem
                                                    key={item.id}
                                                    className="flex flex-row items-start space-x-3 space-y-0"
                                                >
                                                    <FormControl>
                                                    <Checkbox
                                                        checked={field.value?.includes(item.id)}
                                                        onCheckedChange={(checked) => {
                                                        return checked
                                                            ? field.onChange([...(field.value || []), item.id])
                                                            : field.onChange(
                                                                field.value?.filter(
                                                                (value) => value !== item.id
                                                                )
                                                            )
                                                        }}
                                                    />
                                                    </FormControl>
                                                    <FormLabel className="font-normal">
                                                        {item.label}
                                                    </FormLabel>
                                                </FormItem>
                                                )
                                            }}
                                            />
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                         <FormMessage>{form.formState.errors.availableItems?.message}</FormMessage>
                        </FormItem>
                    )}
                    />


                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "جارٍ الحفظ..." : "حفظ التعديلات"}
                </Button>
              </form>
            </Form>
        </CardContent>
    </Card>
  )
}
