

"use client"

import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, CheckCircle, CreditCard, ExternalLink, Bot, Box, Users, Infinity as InfinityIcon } from "lucide-react";
import { getServices } from "@/lib/data/services";
import { getPricingPlans } from "@/lib/data/pricing";
import { Service, PricingPlan } from "@/lib/types";
import Link from "next/link";
import { Skeleton } from "../ui/skeleton";
import { useBrand } from "./brand-provider";
import { Separator } from "../ui/separator";

const limitIcons = {
    spaces: Box,
    assistants: Bot,
    teamMembers: Users,
    aiInteractions: InfinityIcon
};

const limitLabels = {
    spaces: "مساحة عمل",
    assistants: "مساعد ذكي",
    teamMembers: "عضو فريق",
    aiInteractions: "تفاعل ذكاء اصطناعي"
};

export function SubscriptionSettings() {
    const [services, setServices] = useState<Service[]>([]);
    const [plans, setPlans] = useState<PricingPlan[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const { brand, isLoaded } = useBrand();

    useEffect(() => {
        async function fetchData() {
            if (!brand.id) return;
            try {
                const [fetchedServices, fetchedPlans] = await Promise.all([
                    getServices(brand.id),
                    getPricingPlans()
                ]);
                setServices(fetchedServices);
                setPlans(fetchedPlans);
            } catch (error) {
                console.error("Failed to fetch subscription data:", error);
            } finally {
                setIsLoading(false);
            }
        }
        if(isLoaded) {
            fetchData();
        }
    }, [isLoaded, brand.id]);

    const currentPlan = plans.find(p => p.isCurrent) || plans[1]; // Mock current plan

    if (isLoading) {
        return <SubscriptionSkeleton />
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>باقتك الحالية</CardTitle>
                    <CardDescription>نظرة عامة على اشتراكك الحالي والميزات المضمنة.</CardDescription>
                </CardHeader>
                {currentPlan && (
                    <CardContent>
                        <div className="p-6 rounded-lg border-2 border-primary bg-primary/5">
                            <div className="flex flex-col md:flex-row items-start justify-between gap-4">
                                <div>
                                    <h3 className="text-2xl font-bold text-primary flex items-center gap-2">
                                        {currentPlan.name}
                                        <Badge className="text-xs bg-primary/20 text-primary border-primary/30">الباقة الحالية</Badge>
                                    </h3>
                                    <p className="text-muted-foreground mt-1">{currentPlan.description}</p>
                                </div>
                                <div className="text-right shrink-0">
                                     <p className="text-2xl font-bold">{currentPlan.price} <span className="text-base font-normal text-muted-foreground">{currentPlan.priceUnit}</span></p>
                                     <p className="text-sm text-muted-foreground">تتجدد في: 15 يوليو, 2024</p>
                                </div>
                            </div>
                            <Separator className="my-6" />
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                                <div>
                                    <h4 className="font-semibold mb-3">الميزات الأساسية</h4>
                                    <ul className="space-y-3">
                                        {currentPlan.features.map((feature, index) => (
                                            <li key={index} className="flex items-center gap-2">
                                                <CheckCircle className="text-green-500 w-5 h-5" />
                                                <span className="flex-1">{feature}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold mb-3">حدود الاستخدام</h4>
                                    <ul className="space-y-3">
                                        {Object.entries(currentPlan.limits).map(([key, value]) => {
                                            const Icon = limitIcons[key as keyof typeof limitIcons];
                                            const label = limitLabels[key as keyof typeof limitLabels];
                                            return (
                                                <li key={key} className="flex items-center gap-2 text-sm">
                                                    <Icon className="text-muted-foreground w-4 h-4"/>
                                                    <span className="flex-1">{label}</span>
                                                    <span className="font-semibold">{value === 'unlimited' ? 'غير محدود' : value}</span>
                                                </li>
                                            )
                                        })}
                                    </ul>
                                </div>
                             </div>
                            <div className="mt-6 flex flex-col sm:flex-row gap-3">
                                <Button asChild>
                                    <Link href="/pricing">تغيير الباقة</Link>
                                </Button>
                                <Button variant="outline">
                                    <CreditCard className="ml-2 h-4 w-4"/>
                                    إدارة الفواتير
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                )}
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>الخدمات المتاحة</CardTitle>
                    <CardDescription>تصفح جميع الخدمات والباقات التي يمكنك إتاحتها لعملائك.</CardDescription>
                </CardHeader>
                <CardContent>
                   <div className="space-y-4">
                        <div>
                             <h4 className="text-lg font-semibold mb-2">الباقات</h4>
                             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {plans.map(plan => (
                                    <div key={plan.id} className="p-4 rounded-md border">
                                        <p className="font-bold">{plan.name}</p>
                                        <p className="text-sm text-muted-foreground">{plan.price} {plan.priceUnit}</p>
                                    </div>
                                ))}
                             </div>
                        </div>
                         <div>
                             <h4 className="text-lg font-semibold mb-2">الخدمات الفردية</h4>
                             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {services.map(service => (
                                    <div key={service.id} className="p-4 rounded-md border">
                                        <p className="font-bold">{service.name}</p>
                                        <p className="text-sm text-muted-foreground">{service.price}</p>
                                    </div>
                                ))}
                             </div>
                        </div>
                   </div>
                   <div className="mt-6">
                        <Button variant="link" asChild>
                            <Link href="/pricing">
                                تعديل الخدمات والباقات <ExternalLink className="mr-2 h-4 w-4" />
                            </Link>
                        </Button>
                   </div>
                </CardContent>
            </Card>
        </div>
    )
}


const SubscriptionSkeleton = () => (
    <div className="space-y-6">
        <Card>
            <CardHeader>
                <Skeleton className="h-6 w-1/4" />
                <Skeleton className="h-4 w-1/2 mt-2" />
            </CardHeader>
            <CardContent>
                 <div className="p-6 rounded-lg border">
                    <div className="flex justify-between">
                        <div className="space-y-2">
                            <Skeleton className="h-8 w-48" />
                            <Skeleton className="h-4 w-64" />
                        </div>
                         <div className="space-y-2 text-right">
                             <Skeleton className="h-8 w-32" />
                             <Skeleton className="h-4 w-40" />
                         </div>
                    </div>
                    <div className="mt-6 space-y-3">
                        <Skeleton className="h-5 w-full" />
                        <Skeleton className="h-5 w-full" />
                        <Skeleton className="h-5 w-4/5" />
                    </div>
                 </div>
            </CardContent>
        </Card>
         <Card>
            <CardHeader>
                <Skeleton className="h-6 w-1/3" />
                <Skeleton className="h-4 w-3/4 mt-2" />
            </CardHeader>
            <CardContent className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
            </CardContent>
        </Card>
    </div>
)
