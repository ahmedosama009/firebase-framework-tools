

'use client';

import { useState, useRef, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '../ui/textarea';
import { Assistant } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Upload, Loader2, Info } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '../ui/tooltip';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

interface EditAssistantDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  assistant: Assistant;
  onSave: (updatedAssistant: Assistant) => void;
}

const assistantSchema = z.object({
  name: z.string().min(2, { message: "يجب أن يكون الاسم حرفين على الأقل." }),
  role: z.string().min(10, { message: "يجب أن يكون الوصف 10 أحرف على الأقل." }),
  avatarUrl: z.string().optional(),
  visible: z.boolean(),
  language: z.string(),
  entrypoint: z.enum(['pre_login', 'post_login', 'dashboard', 'background', 'on_demand', 'realtime', 'auto']),
  promptStyle: z.string().optional(),
  access: z.array(z.string()).optional(),
});

type AssistantFormValues = z.infer<typeof assistantSchema>;

export function EditAssistantDialog({ isOpen, setIsOpen, assistant, onSave }: EditAssistantDialogProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);

  const { control, register, handleSubmit, formState: { errors, isSubmitting, isDirty }, reset, watch, setValue } = useForm<AssistantFormValues>({
    resolver: zodResolver(assistantSchema),
    defaultValues: {
      ...assistant,
      avatarUrl: assistant.avatarUrl || '',
    }
  });

  useEffect(() => {
    reset({
      ...assistant,
      avatarUrl: assistant.avatarUrl || '',
    });
  }, [assistant, reset]);

  const watchedAvatar = watch('avatarUrl');

  const handleAvatarUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsUploading(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = reader.result as string;
        setValue("avatarUrl", dataUrl, { shouldValidate: true, shouldDirty: true });
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const processSubmit = (data: AssistantFormValues) => {
    const updatedAssistant: Assistant = {
      ...assistant,
      ...data,
    };
    onSave(updatedAssistant);
    toast({
      title: 'تم الحفظ بنجاح!',
      description: `تم تحديث بيانات المساعد ${data.name}.`,
    });
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>تعديل المساعد: {assistant.name}</DialogTitle>
          <DialogDescription>
            قم بتحديث تفاصيل المساعد وسلوكه ليناسب احتياجاتك.
          </DialogDescription>
        </DialogHeader>
        <TooltipProvider>
        <form onSubmit={handleSubmit(processSubmit)} className="space-y-4 pt-4">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={watchedAvatar} alt={assistant.name} data-ai-hint="avatar" />
                <AvatarFallback>{assistant.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="flex-grow">
                <Label>صورة المساعد</Label>
                 <input
                    type="file"
                    accept="image/*"
                    ref={fileInputRef}
                    onChange={handleAvatarUpload}
                    className="hidden"
                />
                <Button type="button" variant="outline" className="w-full mt-1" onClick={() => fileInputRef.current?.click()} disabled={isUploading}>
                    {isUploading ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Upload className="ml-2 h-4 w-4" />}
                    تغيير الصورة
                </Button>
                {errors.avatarUrl && <p className="text-sm text-destructive mt-1">{errors.avatarUrl.message}</p>}
              </div>
            </div>

          <div>
            <Label htmlFor="name">اسم المساعد</Label>
            <Input id="name" {...register('name')} />
            {errors.name && <p className="text-sm text-destructive mt-1">{errors.name.message}</p>}
          </div>

          <div>
            <Label htmlFor="role">الدور (الوصف الوظيفي)</Label>
            <Textarea id="role" {...register('role')} />
            {errors.role && <p className="text-sm text-destructive mt-1">{errors.role.message}</p>}
          </div>
          
          <div>
            <Label htmlFor="promptStyle">أسلوب المساعد</Label>
            <Input id="promptStyle" placeholder="مثال: ودود، واضح، مشجع" {...register('promptStyle')} />
            {errors.promptStyle && <p className="text-sm text-destructive mt-1">{errors.promptStyle.message}</p>}
          </div>
          
           <Controller
            name="visible"
            control={control}
            render={({ field }) => (
                <div className="flex items-center justify-between rounded-lg border p-3">
                    <Label htmlFor="visible-switch" className="flex-grow">مرئي للمستخدم النهائي</Label>
                    <div className="flex items-center gap-2">
                       <Switch
                        id="visible-switch"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                       />
                       <span className="text-sm font-medium">{field.value ? 'مرئي' : 'مخفي'}</span>
                    </div>
                </div>
            )}
           />

            <Controller
                name="entrypoint"
                control={control}
                render={({ field }) => (
                    <div>
                        <Label>نقطة الدخول (Entrypoint)</Label>
                        <Select onValueChange={field.onChange} value={field.value}>
                            <SelectTrigger>
                                <SelectValue placeholder="اختر نقطة الدخول..." />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="pre_login">قبل تسجيل الدخول</SelectItem>
                                <SelectItem value="post_login">بعد تسجيل الدخول</SelectItem>
                                <SelectItem value="dashboard">لوحة التحكم</SelectItem>
                                <SelectItem value="background">خلفية</SelectItem>
                                <SelectItem value="on_demand">عند الطلب</SelectItem>
                                <SelectItem value="realtime">فوري</SelectItem>
                                <SelectItem value="auto">تلقائي</SelectItem>
                            </SelectContent>
                        </Select>
                        {errors.entrypoint && <p className="text-sm text-destructive mt-1">{errors.entrypoint.message}</p>}
                    </div>
                )}
            />

          <DialogFooter>
            <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>
              إلغاء
            </Button>
            <Button type="submit" disabled={isSubmitting || !isDirty}>
              {isSubmitting ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : 'حفظ التغييرات'}
            </Button>
          </DialogFooter>
        </form>
        </TooltipProvider>
      </DialogContent>
    </Dialog>
  );
}
