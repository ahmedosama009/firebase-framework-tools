
"use client"

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { useEffect, useState, useRef } from "react"
import Image from "next/image"
import { doc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";

import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select"
import { toast } from "@/hooks/use-toast"
import { useBrand } from "./brand-provider"
import { Textarea } from "../ui/textarea"
import { BrandIdentity } from "@/lib/types"
import { Banknote, Briefcase, Upload, Loader2 } from "lucide-react"
import { Separator } from "../ui/separator"

const brandFormSchema = z.object({
  id: z.string(), // Keep the ID for saving
  companyName: z.string().min(2, {
    message: "يجب أن يكون اسم الشركة حرفين على الأقل.",
  }),
  companyDescription: z.string().min(10, {
    message: "يجب أن يكون وصف الشركة 10 أحرف على الأقل.",
  }),
  knowledgeBase: z.string().min(20, {
    message: "يجب أن تكون قاعدة المعرفة 20 حرفًا على الأقل.",
  }),
  language: z.enum(["ar", "en"]),
  tone: z.string().min(1, "نبرة المحتوى مطلوبة"),
  style: z.string().min(1, "أسلوب الكتابة مطلوب"),
  logoUrl: z.string().url({ message: "الرجاء إدخال رابط صحيح." }).optional().or(z.literal("")),
  legalInfo: z.object({
    legalName: z.string().optional(),
    address: z.string().optional(),
    taxId: z.string().optional(),
    registrationNumber: z.string().optional(),
  }).optional(),
  bankingInfo: z.object({
    bankName: z.string().optional(),
    accountNumber: z.string().optional(),
    iban: z.string().optional(),
  }).optional(),
})

type BrandFormValues = z.infer<typeof brandFormSchema>


export function BrandForm() {
    const { brand, setBrand, isLoaded } = useBrand();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const form = useForm<BrandFormValues>({
        resolver: zodResolver(brandFormSchema),
        values: brand,
    });

    useEffect(() => {
        if (isLoaded) {
            form.reset(brand);
        }
    }, [isLoaded, brand, form.reset]);

    const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const dataUrl = reader.result as string;
                form.setValue("logoUrl", dataUrl, { shouldValidate: true, shouldDirty: true });
            };
            reader.readAsDataURL(file);
        }
    };
    
    async function onSubmit(data: BrandFormValues) {
        setIsSubmitting(true);
        
        const updatedBrandData = { ...brand, ...data };

        try {
            const companyRef = doc(db, "companies", data.id);
            await setDoc(companyRef, updatedBrandData, { merge: true });
            
            // Update the context provider state
            setBrand(updatedBrandData);

            toast({
                title: "تم الحفظ بنجاح!",
                description: "تم تحديث إعدادات هوية الشركة في قاعدة البيانات.",
            });
            form.reset(updatedBrandData); // Resets the dirty state
        } catch (error) {
            console.error("Error saving brand identity:", error);
            toast({
                title: "خطأ",
                description: "فشل حفظ البيانات. الرجاء المحاولة مرة أخرى.",
                variant: "destructive",
            });
        } finally {
            setIsSubmitting(false);
        }
    }

  return (
    <Card>
        <CardHeader>
            <CardTitle>إعدادات الشركة</CardTitle>
            <CardDescription>
                إدارة تفاصيل الشركة والهوية البصرية واللغوية والمعلومات القانونية والبنكية.
            </CardDescription>
        </CardHeader>
        <CardContent>
            { !isLoaded ? (
                <div className="flex justify-center items-center h-64">
                    <Loader2 className="w-8 h-8 animate-spin" />
                </div>
            ) : (
                <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                    
                    <FormField
                    control={form.control}
                    name="companyName"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>اسم الشركة</FormLabel>
                        <FormControl>
                            <Input placeholder="اسم شركتك الذي يظهر للعملاء" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <FormField
                    control={form.control}
                    name="companyDescription"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>وصف الشركة</FormLabel>
                        <FormControl>
                            <Textarea placeholder="وصف موجز لشركتك" {...field} />
                        </FormControl>
                        <FormDescription>
                            هذا الوصف سيساعد الذكاء الاصطناعي على فهم نشاطك التجاري.
                        </FormDescription>
                        <FormMessage />
                        </FormItem>
                    )}
                    />

                    <FormItem>
                        <FormLabel>شعار الشركة</FormLabel>
                        <div className="flex items-center gap-4">
                            <div className="w-20 h-20 rounded-md border flex items-center justify-center bg-muted overflow-hidden">
                                {form.watch("logoUrl") ? (
                                    <Image src={form.watch("logoUrl")!} alt="شعار الشركة" width={80} height={80} style={{ objectFit: 'contain' }} />
                                ) : (
                                    <span className="text-xs text-muted-foreground">لا شعار</span>
                                )}
                            </div>
                            <FormControl>
                                <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                                    <Upload className="ml-2 h-4 w-4" />
                                    رفع شعار
                                </Button>
                            </FormControl>
                            <input
                                type="file"
                                accept="image/*"
                                ref={fileInputRef}
                                onChange={handleLogoUpload}
                                className="hidden"
                            />
                        </div>
                        <FormMessage>{form.formState.errors.logoUrl?.message}</FormMessage>
                    </FormItem>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                            control={form.control}
                            name="language"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>اللغة المفضلة</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="اختر لغة" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    <SelectItem value="ar">العربية</SelectItem>
                                    <SelectItem value="en">English</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />

                        <FormField
                            control={form.control}
                            name="tone"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>نبرة المحتوى</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="اختر نبرة" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    <SelectItem value="احترافي">احترافي</SelectItem>
                                    <SelectItem value="ودي">ودي</SelectItem>
                                    <SelectItem value="فكاهي">فكاهي</SelectItem>
                                    <SelectItem value="راقية">راقية</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="style"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>أسلوب الكتابة</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value}>
                                    <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="اختر أسلوب" />
                                    </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    <SelectItem value="إقناعي">إقناعي</SelectItem>
                                    <SelectItem value="وصفي">وصفي</SelectItem>
                                    <SelectItem value="سردي">سردي</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>

                    <FormField
                    control={form.control}
                    name="knowledgeBase"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>قاعدة المعرفة</FormLabel>
                        <FormControl>
                            <Textarea placeholder="أضف هنا أي معلومات تريد أن يعرفها الذكاء الاصطناعي عن شركتك، مثل المنتجات، الخدمات، الجمهور المستهدف، إرشادات معينة، إلخ." {...field} className="min-h-[150px]" />
                        </FormControl>
                        <FormDescription>
                            هذه هي قاعدة المعرفة الأساسية التي سيعتمد عليها المساعدون في جميع مهامهم.
                        </FormDescription>
                        <FormMessage />
                        </FormItem>
                    )}
                    />

                    <Separator />

                    {/* Legal Information Section */}
                    <div className="space-y-4">
                        <div className="flex items-center gap-2">
                            <Briefcase className="w-5 h-5 text-muted-foreground"/>
                            <h3 className="text-lg font-semibold">المعلومات القانونية</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                                control={form.control}
                                name="legalInfo.legalName"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>الاسم القانوني للشركة</FormLabel>
                                    <FormControl>
                                        <Input placeholder="الاسم المسجل في السجل التجاري" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="legalInfo.address"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>العنوان الرسمي</FormLabel>
                                    <FormControl>
                                        <Input placeholder="العنوان المسجل للشركة" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="legalInfo.registrationNumber"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>رقم السجل التجاري</FormLabel>
                                    <FormControl>
                                        <Input placeholder="123456789" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="legalInfo.taxId"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>الرقم الضريبي</FormLabel>
                                    <FormControl>
                                        <Input placeholder="123-456-789" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                    </div>

                    <Separator />
                    
                    {/* Banking Information Section */}
                    <div className="space-y-4">
                        <div className="flex items-center gap-2">
                            <Banknote className="w-5 h-5 text-muted-foreground"/>
                            <h3 className="text-lg font-semibold">المعلومات البنكية</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                                control={form.control}
                                name="bankingInfo.bankName"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>اسم البنك</FormLabel>
                                    <FormControl>
                                        <Input placeholder="اسم البنك" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="bankingInfo.accountNumber"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>رقم الحساب</FormLabel>
                                    <FormControl>
                                        <Input placeholder="رقم حساب الشركة" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <FormField
                            control={form.control}
                            name="bankingInfo.iban"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>رقم الحساب المصرفي الدولي (IBAN)</FormLabel>
                                <FormControl>
                                    <Input placeholder="SA03 8000 0000 6080 1016 7519" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                    
                    <Button type="submit" disabled={isSubmitting || !form.formState.isDirty}>
                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : null}
                    {isSubmitting ? "جارٍ الحفظ..." : "حفظ التعديلات"}
                    </Button>
                </form>
                </Form>
            )}
        </CardContent>
    </Card>
  )
}
