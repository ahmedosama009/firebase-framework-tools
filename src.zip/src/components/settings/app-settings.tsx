

"use client"

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { useState, useEffect } from "react"
import { useTheme } from "next-themes"
import { toast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { cn } from "@/lib/utils"
import { Check, Languages, Palette, Type, ZoomIn, Paintbrush } from "lucide-react"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select"
import { Label } from "../ui/label"
import { Input } from "../ui/input"
import { colord } from "colord";


const appSettingsSchema = z.object({
  enableIntegrations: z.boolean().default(false).optional(),
})

type AppSettingsFormValues = z.infer<typeof appSettingsSchema>

const defaultValues: Partial<AppSettingsFormValues> = {
  enableIntegrations: true,
}

const colorThemes = [
    { name: 'Default', primary: '221 83% 53%', accent: '173 95% 42%', background: '220 20% 98%', foreground: '220 15% 25%' },
    { name: 'Oceanic', primary: '205 90% 28%', accent: '215 80% 55%', background: '210 40% 98%', foreground: '210 50% 15%' },
    { name: 'Sunset', primary: '25 95% 53%', accent: '355 85% 65%', background: '20 40% 98%', foreground: '20 50% 15%' },
    { name: 'Forest', primary: '120 39% 31%', accent: '140 45% 45%', background: '110 20% 98%', foreground: '120 40% 10%' },
];

const fonts = [
    { name: 'Tajawal', value: "'Tajawal', 'Poppins', sans-serif" },
    { name: 'Cairo', value: "'Cairo', 'Poppins', sans-serif" },
    { name: 'Noto Sans Arabic', value: "'Noto Sans Arabic', 'Poppins', sans-serif" },
];

const hslStringToHex = (hsl: string) => colord(`hsl(${hsl})`).toHex();
const hexToHslString = (hex: string) => {
    const { h, s, l } = colord(hex).toHsl();
    return `${h} ${s}% ${l}%`;
};

export function AppSettingsForm() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { theme: mode, setTheme: setMode } = useTheme();
    const [activeColorTheme, setActiveColorTheme] = useState('');
    const [fontSize, setFontSize] = useState(16);
    const [language, setLanguage] = useState('ar');
    const [selectedFont, setSelectedFont] = useState(fonts[0].value);
    
    // State for custom theme builder
    const [customColors, setCustomColors] = useState({
        primary: hslStringToHex(colorThemes[0].primary),
        accent: hslStringToHex(colorThemes[0].accent),
        background: hslStringToHex(colorThemes[0].background),
        foreground: hslStringToHex(colorThemes[0].foreground),
    });

    const applyTheme = (theme: { name?: string, primary: string, accent: string, background: string, foreground: string }) => {
        const root = document.documentElement;
        root.style.setProperty('--primary-hsl', theme.primary);
        root.style.setProperty('--accent-hsl', theme.accent);
        root.style.setProperty('--background-hsl', theme.background);
        root.style.setProperty('--foreground-hsl', theme.foreground);
        
        if (theme.name) {
            setActiveColorTheme(theme.name);
            localStorage.setItem('appColorThemeName', theme.name);
            // when selecting a preset, also update the custom color pickers
            setCustomColors({
                primary: hslStringToHex(theme.primary),
                accent: hslStringToHex(theme.accent),
                background: hslStringToHex(theme.background),
                foreground: hslStringToHex(theme.foreground),
            })
        } else {
             // This is a custom theme
            setActiveColorTheme('Custom');
            localStorage.setItem('appColorThemeName', 'Custom');
        }
        
        localStorage.setItem('appCustomColors', JSON.stringify({
            primary: theme.primary,
            accent: theme.accent,
            background: theme.background,
            foreground: theme.foreground,
        }));
    }

    const handleCustomColorChange = (colorName: keyof typeof customColors, hexValue: string) => {
        const newCustomColors = { ...customColors, [colorName]: hexValue };
        setCustomColors(newCustomColors);
        
        const customTheme = {
            primary: hexToHslString(newCustomColors.primary),
            accent: hexToHslString(newCustomColors.accent),
            background: hexToHslString(newCustomColors.background),
            foreground: hexToHslString(newCustomColors.foreground),
        };
        
        applyTheme(customTheme);
    };

    useEffect(() => {
        const savedThemeName = localStorage.getItem('appColorThemeName') || 'Default';
        let themeToApply;
        
        if (savedThemeName === 'Custom') {
            const savedCustomColors = JSON.parse(localStorage.getItem('appCustomColors') || '{}');
            themeToApply = { ...colorThemes[0], ...savedCustomColors, name: 'Custom' };
        } else {
            themeToApply = colorThemes.find(t => t.name === savedThemeName) || colorThemes[0];
        }
        
        applyTheme(themeToApply);

        const savedFont = localStorage.getItem('appFont') || fonts[0].value;
        applyFont(savedFont);
        
        const savedFontSize = localStorage.getItem('appFontSize') || '16';
        applyFontSize(parseInt(savedFontSize, 10));
        
        const savedLang = localStorage.getItem('appLang') || 'ar';
        applyLanguage(savedLang);
        
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const applyFont = (fontValue: string) => {
        document.documentElement.style.setProperty('--font-body', fontValue);
        document.documentElement.style.setProperty('--font-headline', fontValue);
        localStorage.setItem('appFont', fontValue);
        setSelectedFont(fontValue);
    }
    
    const applyFontSize = (size: number) => {
        document.documentElement.style.fontSize = `${size}px`;
        setFontSize(size);
        localStorage.setItem('appFontSize', size.toString());
    }
    
    const applyLanguage = (lang: string) => {
        document.documentElement.lang = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        setLanguage(lang);
        localStorage.setItem('appLang', lang);
    }

    const form = useForm<AppSettingsFormValues>({
        resolver: zodResolver(appSettingsSchema),
        defaultValues,
    })

    function onSubmit(data: AppSettingsFormValues) {
        setIsSubmitting(true)
        console.log("App Settings Data:", data)
        toast({
            title: "تم الحفظ بنجاح!",
            description: "تم تحديث إعدادات التطبيق.",
        })
        setIsSubmitting(false)
    }

    const SettingsSection = ({ icon: Icon, title, description, children }: { icon: React.ElementType, title: string, description: string, children: React.ReactNode }) => (
        <Card>
            <CardHeader className="flex flex-row items-start gap-4">
                 <div className="p-2 bg-primary/10 rounded-full text-primary">
                    <Icon className="h-6 w-6" />
                 </div>
                 <div>
                    <CardTitle className="text-lg">{title}</CardTitle>
                    <CardDescription>{description}</CardDescription>
                </div>
            </CardHeader>
            <CardContent>
                {children}
            </CardContent>
        </Card>
    );

    const ColorSwatch = ({ color, name }: { color: string, name: string }) => (
        <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full border" style={{ backgroundColor: color }}></div>
            <span className="text-sm">{name}</span>
        </div>
    );

    return (
        <div className="space-y-6">
            <SettingsSection icon={Palette} title="الثيمات الجاهزة" description="اختر لوحة ألوان جاهزة كنقطة بداية.">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                    {colorThemes.map((theme) => {
                        const isActive = activeColorTheme === theme.name;
                        return (
                            <Card 
                                key={theme.name} 
                                onClick={() => applyTheme(theme)} 
                                className={cn("cursor-pointer transition-all", isActive ? "border-primary ring-2 ring-primary" : "hover:border-primary/50")}
                            >
                                <CardHeader>
                                    <CardTitle className="text-base">{theme.name}</CardTitle>
                                </CardHeader>
                                <CardContent className="grid grid-cols-2 gap-x-4 gap-y-2">
                                    <ColorSwatch color={`hsl(${theme.primary})`} name="الأساسي"/>
                                    <ColorSwatch color={`hsl(${theme.accent})`} name="المميز"/>
                                    <ColorSwatch color={`hsl(${theme.background})`} name="الخلفية"/>
                                    <ColorSwatch color={`hsl(${theme.foreground})`} name="النص"/>
                                </CardContent>
                            </Card>
                        )
                    })}
                </div>
            </SettingsSection>
            
            <SettingsSection icon={Paintbrush} title="تكوين ثيم مخصص" description="صمم لوحة الألوان الخاصة بك لتناسب علامتك التجارية بدقة.">
                 <Card className={cn("transition-all", activeColorTheme === 'Custom' && "border-primary ring-2 ring-primary")}>
                    <CardContent className="p-4">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                           {Object.entries(customColors).map(([name, value]) => (
                                <div key={name} className="space-y-1.5">
                                    <Label className="capitalize">{name}</Label>
                                    <Input
                                        type="color"
                                        value={value}
                                        className="h-10 p-1"
                                        onChange={(e) => handleCustomColorChange(name as keyof typeof customColors, e.target.value)}
                                    />
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </SettingsSection>


             <SettingsSection icon={Type} title="الخطوط" description="اختر الخط المناسب لواجهة المستخدم.">
                 <Select onValueChange={applyFont} value={selectedFont}>
                    <SelectTrigger className="w-full md:w-1/2">
                        <SelectValue placeholder="اختر خطًا..." />
                    </SelectTrigger>
                    <SelectContent>
                        {fonts.map(font => (
                             <SelectItem key={font.name} value={font.value} style={{fontFamily: font.value}}>{font.name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </SettingsSection>

            <SettingsSection icon={ZoomIn} title="حجم الخط" description="تحكم في حجم النص الأساسي للتطبيق.">
                <div className="flex items-center gap-4">
                    <Slider
                        value={[fontSize]}
                        max={20}
                        min={12}
                        step={1}
                        onValueChange={(value) => applyFontSize(value[0])}
                        className="flex-1"
                    />
                    <span className="font-mono text-lg w-10 text-center">{fontSize}px</span>
                </div>
            </SettingsSection>

            <SettingsSection icon={Languages} title="اللغة والمنطقة" description="اختر اللغة الأساسية لواجهة التطبيق.">
                 <Select onValueChange={applyLanguage} value={language}>
                    <SelectTrigger className="w-full md:w-1/2">
                        <SelectValue placeholder="اختر لغة..." />
                    </SelectTrigger>
                    <SelectContent>
                         <SelectItem value="ar">العربية (Arabic)</SelectItem>
                         <SelectItem value="en">الإنجليزية (English)</SelectItem>
                    </SelectContent>
                </Select>
            </SettingsSection>
            
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>الإعدادات المتقدمة</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <FormField
                                control={form.control}
                                name="enableIntegrations"
                                render={({ field }) => (
                                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                                        <div className="space-y-0.5">
                                            <FormLabel className="text-base">تفعيل التكامل مع APIs</FormLabel>
                                            <FormDescription>
                                                السماح للتطبيق بالتكامل مع خدمات خارجية.
                                            </FormDescription>
                                        </div>
                                        <FormControl>
                                            <Switch
                                                checked={field.value}
                                                onCheckedChange={field.onChange}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </CardContent>
                    </Card>

                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? "جارٍ الحفظ..." : "حفظ الإعدادات المتقدمة"}
                    </Button>
                </form>
            </Form>
        </div>
    )
}
