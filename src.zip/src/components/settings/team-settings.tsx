
"use client"

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { useState } from "react"
import { toast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "../ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar"
import { Separator } from "../ui/separator"
import { PlusCircle } from "lucide-react"

type Role = "مدير" | "عضو فريق" | "مشاهد";

const initialTeamMembers = [
    { id: "USR001", name: "أحمد العلي", role: "مدير" as Role, email: "ahmad@example.com", avatar: "https://placehold.co/100x100.png?text=A" },
    { id: "USR002", name: "فاطمة السيد", role: "عضو فريق" as Role, email: "fatima@example.com", avatar: "https://placehold.co/100x100.png?text=F" },
    { id: "USR003", name: "خالد المصري", role: "عضو فريق" as Role, email: "khalid@example.com", avatar: "https://placehold.co/100x100.png?text=K" },
    { id: "USR004", name: "سارة إبراهيم", role: "مشاهد" as Role, email: "sara@example.com", avatar: "https://placehold.co/100x100.png?text=S" },
];

const inviteMemberSchema = z.object({
  email: z.string().email("البريد الإلكتروني المدخل غير صالح."),
  role: z.enum(["admin", "member", "viewer"]),
})

type InviteMemberFormValues = z.infer<typeof inviteMemberSchema>

export function TeamSettingsForm() {
    const [teamMembers, setTeamMembers] = useState(initialTeamMembers);

    const form = useForm<InviteMemberFormValues>({
        resolver: zodResolver(inviteMemberSchema),
        defaultValues: {
            email: "",
            role: "member",
        },
    })

    function onSubmit(data: InviteMemberFormValues) {
        console.log("Invite Data:", data)
        toast({
            title: "تم إرسال الدعوة!",
            description: `تم إرسال دعوة إلى ${data.email} للانضمام إلى الفريق.`,
        })
        form.reset();
    }
    
    const handleRoleChange = (memberId: string, newRole: Role) => {
        setTeamMembers(prevMembers => 
            prevMembers.map(member => 
                member.id === memberId ? { ...member, role: newRole } : member
            )
        );
        toast({
            title: "تم تحديث الدور بنجاح!",
        });
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>دعوة أعضاء جدد</CardTitle>
                    <CardDescription>
                        إرسال دعوات للانضمام إلى فريق عملك وتحديد أدوارهم.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col md:flex-row items-end gap-4">
                            <FormField
                                control={form.control}
                                name="email"
                                render={({ field }) => (
                                    <FormItem className="flex-grow">
                                        <FormLabel>البريد الإلكتروني للعضو</FormLabel>
                                        <FormControl>
                                            <Input placeholder="name@example.com" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="role"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>الدور</FormLabel>
                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                            <FormControl>
                                                <SelectTrigger className="w-full md:w-[180px]">
                                                    <SelectValue placeholder="اختر دورًا" />
                                                </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                                <SelectItem value="admin">مدير</SelectItem>
                                                <SelectItem value="member">عضو فريق</SelectItem>
                                                <SelectItem value="viewer">مشاهد</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </FormItem>
                                )}
                            />
                            <Button type="submit" disabled={form.formState.isSubmitting}>
                                <PlusCircle className="ml-2 h-4 w-4" />
                                إرسال دعوة
                            </Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>الأعضاء الحاليون</CardTitle>
                    <CardDescription>
                        إدارة أدوار وصلاحيات أعضاء الفريق المسجلين.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {teamMembers.map((member, index) => (
                       <div key={member.id}>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <Avatar className="h-10 w-10">
                                        <AvatarImage src={member.avatar} data-ai-hint="person" />
                                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{member.name}</p>
                                        <p className="text-sm text-muted-foreground">{member.email}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                     <Select 
                                         value={member.role}
                                         onValueChange={(value: Role) => handleRoleChange(member.id, value)}
                                     >
                                        <SelectTrigger className="w-[150px]">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="مدير">مدير</SelectItem>
                                            <SelectItem value="عضو فريق">عضو فريق</SelectItem>
                                            <SelectItem value="مشاهد">مشاهد</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600">إزالة</Button>
                                </div>
                            </div>
                            {index < teamMembers.length - 1 && <Separator className="mt-4" />}
                       </div>
                    ))}
                </CardContent>
            </Card>
        </div>
    )
}
