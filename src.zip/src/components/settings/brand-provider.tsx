
"use client";

import { BrandIdentity, Assistant } from "@/lib/types";
import React, { createContext, useContext, useState, useEffect } from "react";
import { initializeFirebaseClient } from "@/lib/firebase";
import { doc, onSnapshot, Firestore } from "firebase/firestore";

// Default data used when Firestore is not available or configured.
const defaultAssistants: Assistant[] = [
    { id: "leila", name: "ليلى", role: "مساعدة استقبال ومبيعات", visible: true, language: "ar", entrypoint: "pre_login", access: ["public", "sales"], promptStyle: "ودود، واضح، مشجع" },
    { id: "sally", name: "سالي", role: "مديرة تنفيذية واستشارية", visible: true, language: "ar", entrypoint: "post_login", access: ["marketing", "review", "admin"], promptStyle: "تحليلي، استشاري، رسمي" },
    { id: "infinity", name: "إنفينيتي", role: "دعم فني للمنصة", visible: true, language: "ar", entrypoint: "post_login", access: ["support", "tech"], promptStyle: "محايد، تقني، سريع" },
    { id: "noura", name: "نورا", role: "مساعد داخلي للتحليل والتخطيط", visible: true, language: "ar,en", entrypoint: "dashboard", access: ["internal", "analytics"], promptStyle: "تحليلي، دقيق، موجه للنتائج" },
    { id: "k", name: "K", role: "مدير مشروع تفاعلي لصاحب العمل", visible: false, entrypoint: "background", access: ["owner", "suggestions"], promptStyle: "ذكي، شخصي، مبادر" },
    { id: "k2", name: "K2", role: "نظام إداري مشترك", visible: false, entrypoint: "background", access: ["shared_memory", "team"], promptStyle: "تنسيقي، خلفي، شامل" },
    { id: "ki_researcher1", name: "KI الباحث 1", role: "باحث خارجي", visible: false, entrypoint: "on_demand", access: ["external_search"], promptStyle: "تحقيقي، عالمي" },
    { id: "ki_researcher2", name: "KI الباحث 2", role: "محلل داخلي للبيانات", visible: false, entrypoint: "realtime", access: ["internal_analytics"], promptStyle: "مرجعي، باطني" },
    { id: "ki_executor", name: "KI Executor", role: "منفّذ مهام (كود / صور / محتوى)", visible: false, entrypoint: "auto", access: ["code", "content", "images"], promptStyle: "وظيفي، مباشر" },
];

const defaultBrand: BrandIdentity = {
  id: "alkayan-infinity",
  companyName: "انفنتي الكيان",
  companyDescription: "للتكنولوجيا الحديثة والتسويق الرقمي والدعايه والاعلان. اهلا بيك فالمستقبل",
  knowledgeBase: "نحن نقدم باقات متنوعة تشمل التسويق الرقمي، تصميم الهوية البصرية، وإدارة حسابات التواصل. نستهدف الشركات الناشئة والمتوسطة في السعودية. يجب أن تكون جميع المخرجات باللغة العربية الفصحى وبنبرة احترافية.",
  tone: "احترافي",
  style: "إقناعي",
  language: "ar",
  logoUrl: "",
  assistants: defaultAssistants,
  legalInfo: { legalName: "", address: "", taxId: "", registrationNumber: "" },
  bankingInfo: { bankName: "", accountNumber: "", iban: "" },
  aiPolicy: { reviewRequired: true, enableImages: false, enableCodeGeneration: false, guardLevel: "high" },
};

interface BrandContextType {
  brand: BrandIdentity;
  setBrand: (brand: BrandIdentity) => void;
  isLoaded: boolean;
}

const BrandContext = createContext<BrandContextType | undefined>(undefined);

export const BrandProvider = ({ children }: { children: React.ReactNode }) => {
  const [brand, setBrandState] = useState<BrandIdentity>(defaultBrand);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // This effect runs only on the client side
    const firebaseConfig = {
      apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
      authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
      projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
      storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
      messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
      appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
    };
    
    // Detailed check for each environment variable
    if (!firebaseConfig.projectId) {
      console.warn("Firebase Initialization Failed: NEXT_PUBLIC_FIREBASE_PROJECT_ID is missing in your .env file. Falling back to default data.");
      setBrandState(defaultBrand);
      setIsLoaded(true); // Stop loading on critical failure, but allow app to run
      return;
    }

    const db = initializeFirebaseClient(firebaseConfig);

    async function fetchBrandData() {
        if (!db) {
            console.error("Firestore DB is not initialized. Check your Firebase config.");
            setBrandState(defaultBrand);
            setIsLoaded(true); // Set loaded to true to prevent infinite loading
            return;
        }

        const companyId = 'alkayan-infinity'; // In a real app, this might come from auth state
        const docRef = doc(db, "companies", companyId);

        const unsubscribe = onSnapshot(docRef, (docSnap) => {
            if (docSnap.exists()) {
                setBrandState(docSnap.data() as BrandIdentity);
            } else {
                console.warn(`Company with ID "${companyId}" not found in Firestore. Using default data.`);
                setBrandState(defaultBrand);
            }
            setIsLoaded(true);
        }, (error) => {
            console.error("Error fetching brand data from Firestore:", error);
            // Fallback to default data in case of error
            setBrandState(defaultBrand);
            setIsLoaded(true);
        });

        return () => unsubscribe();
    }

    fetchBrandData();

  }, []);

  const setBrand = (newBrand: BrandIdentity) => {
    setBrandState(newBrand);
  };

  return (
    <BrandContext.Provider value={{ brand, setBrand, isLoaded }}>
      {children}
    </BrandContext.Provider>
  );
};

export const useBrand = () => {
  const context = useContext(BrandContext);
  if (context === undefined) {
    throw new Error("useBrand must be used within a BrandProvider");
  }
  return context;
};
