
'use client';

import { useState, useRef, useEffect, useActionState, useTransition } from 'react';
import { useFormStatus } from 'react-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Bot, Send, User, Loader2, ArrowLeft } from 'lucide-react';
import { cn } from '@/lib/utils';
import { askLeila, checkSignupReadinessAction } from '@/lib/actions';
import type { ChatMessage, SignupData } from '@/lib/types';
import { useBrand } from '../settings/brand-provider';
import Link from 'next/link';

const initialLeilaState = {
  response: 'مرحباً! أنا ليلى، مساعدتك الذكية في الكيان. كيف يمكنني خدمتك اليوم؟',
};

function ChatSubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="icon" disabled={pending} aria-label="Send message">
      {pending ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
    </Button>
  );
}

export function LeilaChat() {
  const [leilaState, formAction] = useActionState(askLeila, initialLeilaState);
  const [signupState, signupAction] = useActionState(checkSignupReadinessAction, { isReadyForSignup: false });
  const { brand } = useBrand();
  const [isPending, startTransition] = useTransition();

  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', role: 'assistant', content: initialLeilaState.response },
  ]);
  const [signupData, setSignupData] = useState<SignupData | null>(null);

  const formRef = useRef<HTMLFormElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Effect to handle Leila's responses
  useEffect(() => {
    if (leilaState.response && messages[messages.length - 1]?.content !== leilaState.response) {
      const newAssistantMessage: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: leilaState.response,
      };
      const updatedMessages = [...messages, newAssistantMessage];
      setMessages(updatedMessages);

      // After assistant replies, check for signup readiness
      const readinessFormData = new FormData();
      const history = updatedMessages.filter(m => m.role === 'user' || m.role === 'assistant').map(({role, content}) => ({role, content}));
      readinessFormData.set('history', JSON.stringify(history));
      startTransition(() => {
        signupAction(readinessFormData);
      });
    }
  }, [leilaState.response]);

  // Effect to handle signup readiness check result
  useEffect(() => {
    if (signupState.isReadyForSignup) {
        setSignupData(signupState as SignupData);
    }
  }, [signupState]);
  
  // Effect to scroll to bottom of chat
  useEffect(() => {
    if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]');
        if(viewport) {
             viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [messages, signupData]);

  const handleFormSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if(signupData) return; // Disable form if signup is ready

    const formData = new FormData(event.currentTarget);
    const query = formData.get('query') as string;

    if (!query.trim()) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
    };
    
    setMessages((prev) => [...prev, userMessage]);

    formRef.current?.reset();

    const history = [...messages, userMessage].map(({role, content}) => ({role, content}));
    formData.set('history', JSON.stringify(history));
    
    if (brand.knowledgeBase) {
      formData.set('knowledgeBase', brand.knowledgeBase);
    }

    formAction(formData);
  };

  return (
    <Card className="w-full max-w-md mx-auto shadow-2xl rounded-2xl">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 font-headline">
          <Bot className="w-7 h-7 text-accent" />
          <span>مساعدة المبيعات الذكية - ليلى</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] w-full pr-4" ref={scrollAreaRef}>
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  'flex items-start gap-3',
                  message.role === 'user' ? 'justify-end' : 'justify-start'
                )}
              >
                {message.role === 'assistant' && (
                  <Avatar className="w-8 h-8 border-2 border-accent">
                    <AvatarFallback><Bot size={18} /></AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={cn(
                    'max-w-[75%] rounded-xl px-4 py-2 text-sm',
                    message.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  )}
                >
                  {message.content}
                </div>
                 {message.role === 'user' && (
                  <Avatar className="w-8 h-8">
                     <AvatarFallback><User size={18} /></AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
             {signupData?.isReadyForSignup && (
                <div className="flex items-start gap-3 justify-start">
                     <Avatar className="w-8 h-8 border-2 border-green-500">
                        <AvatarFallback><Bot size={18} /></AvatarFallback>
                    </Avatar>
                    <div className="max-w-[75%] rounded-xl px-4 py-3 text-sm bg-green-100 dark:bg-green-900/50 text-green-900 dark:text-green-200 space-y-3">
                       <p className="font-semibold">خطوة أخيرة!</p>
                       <p> بناءً على معلوماتك، قمت بإنشاء حساب لك للانطلاق فورًا. يمكنك التحقق من بريدك الإلكتروني لاحقًا.</p>
                        <Button asChild className="w-full">
                          <Link href="/dashboard">
                            الدخول إلى لوحة التحكم
                            <ArrowLeft className="mr-2 h-4 w-4" />
                          </Link>
                        </Button>
                    </div>
                </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter>
        <form ref={formRef} onSubmit={handleFormSubmit} className="flex w-full items-center gap-2">
           <Input
            name="query"
            placeholder={signupData?.isReadyForSignup ? "تم إنشاء حسابك بنجاح!" : "اسأل عن خدماتنا..."}
            className="flex-1"
            required
            disabled={!!signupData?.isReadyForSignup}
          />
          <ChatSubmitButton />
        </form>
      </CardFooter>
    </Card>
  );
}
