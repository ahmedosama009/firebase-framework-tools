
import { initializeApp, getApps, getApp, FirebaseOptions } from "firebase/app";
import { getFirestore, Firestore } from "firebase/firestore";

let db: Firestore | null = null;

// This function can be called from server components or client components.
export function initializeFirebaseClient(config: FirebaseOptions): Firestore {
    if (getApps().length === 0) {
        if (!config || !config.projectId) {
            console.error("Firebase config is not populated. Make sure you have set up your .env file correctly.");
            throw new Error("Firebase config is not populated.");
        }
        const app = initializeApp(config);
        db = getFirestore(app);
    } else {
        if (!db) {
            const app = getApp();
            db = getFirestore(app);
        }
    }
    return db;
}

// Export a getter function to ensure the db instance is available
export function getDb() {
    // This function can be problematic if initialization is not guaranteed to have happened first.
    // It's safer to rely on the return value from initializeFirebaseClient.
    return db;
}
