

export interface Client {
  id: string;
  companyId: string; // Added to associate client with a company
  name: string;
  email: string;
  status: 'active' | 'inactive';
  serviceType: 'online' | 'offline';
  lastActivity: string;
}

export type SaleSource = 'campaign' | 'direct' | 'b2b' | 'word_of_mouth';

export interface Sale {
  id: string;
  clientName: string;
  clientId: string;
  amount: number;
  date: string;
  source: SaleSource;
  service: string;
}

export interface AssistantTool {
  id: 'web_search' | 'data_analysis' | 'task_creation' | string;
  name: string;
  description: string;
  enabled: boolean;
}

export interface Assistant {
  id: string;
  name: string;
  role: string; // jobDescription is now role
  visible: boolean;
  language: string;
  entrypoint: 'pre_login' | 'post_login' | 'dashboard' | 'background' | 'on_demand' | 'realtime' | 'auto';
  access: string[];
  promptStyle: string;
  // Kept for UI compatibility, can be removed/refactored later
  jobDescription?: string;
  avatarUrl?: string;
  status?: 'active' | 'inactive';
  instructions?: string;
  tools?: AssistantTool[];
}

export interface BrandIdentity {
  id: string; // Unique identifier for the company/brand
  companyName: string;
  companyDescription: string;
  knowledgeBase: string;
  tone: string;
  style: string;
  language: 'ar' | 'en';
  logoUrl?: string;
  assistants: Assistant[];
  legalInfo?: {
    legalName?: string;
    address?: string;
    taxId?: string;
    registrationNumber?: string;
  };
  bankingInfo?: {
    bankName?: string;
    accountNumber?: string;
    iban?: string;
  };
  aiPolicy?: {
    reviewRequired: boolean;
    enableImages: boolean;
    enableCodeGeneration: boolean;
    guardLevel: 'none' | 'low' | 'medium' | 'high';
  };
}

export type TaskStatus = 'todo' | 'in-progress' | 'completed';

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
}


export interface Space {
  id: string;
  name: string;
  description: string;
  generatedContent: string;
  createdAt: string;
  status: 'تخطيط' | 'قيد التنفيذ' | 'مكتمل';
  tasksCount: number;
  teamAvatars: string[];
  tasks?: Task[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export interface SignupData {
    isReadyForSignup: boolean;
    fullName?: string;
    email?: string;
    companyName?: string;
    gravatarUrl?: string;
}

export interface Service {
    id: string;
    name: string;
    description: string;
    price: string;
}

export interface PricingPlan {
    id: string;
    name: string;
    description: string;
    price: string;
    priceUnit: string;
    features: string[];
    limits: {
        spaces: number | 'unlimited';
        assistants: number | 'unlimited';
        teamMembers: number | 'unlimited';
        aiInteractions: number | 'unlimited';
    };
    isPopular: boolean;
    isCurrent?: boolean; // Added to indicate the user's current plan
    colorClass?: string;
}
