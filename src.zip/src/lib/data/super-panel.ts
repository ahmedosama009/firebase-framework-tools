
'use server'

import { db } from "@/lib/firebase";
import { collection, getDocs, doc } from "firebase/firestore";
import { BrandIdentity } from "@/lib/types";

// This interface combines the company ID, its brand data, and its stats.
export interface ICompanyData {
    id: string;
    brand: BrandIdentity;
    stats: {
        clientCount: number;
        teamMemberCount: number;
    };
}

// Function to get all companies and their basic stats
export async function getCompanies(): Promise<ICompanyData[]> {
    try {
        const companiesCol = collection(db, "companies");
        const companySnapshot = await getDocs(companiesCol);

        if (companySnapshot.empty) {
            console.log("No companies found. You may need to run the init script.");
            return [];
        }

        const companiesData: ICompanyData[] = await Promise.all(
            companySnapshot.docs.map(async (companyDoc) => {
                const companyId = companyDoc.id;
                const brand = companyDoc.data() as BrandIdentity;

                // Fetch stats for each company
                const clientsCol = collection(db, "companies", companyId, "clients");
                const teamMemberCount = brand.assistants?.length || 0;

                const clientsSnapshot = await getDocs(clientsCol);

                return {
                    id: companyId,
                    brand: brand,
                    stats: {
                        clientCount: clientsSnapshot.size,
                        teamMemberCount: teamMemberCount,
                    },
                };
            })
        );

        return companiesData;
    } catch (error) {
        console.error("Error fetching companies data for Super Panel: ", error);
        return [];
    }
}
