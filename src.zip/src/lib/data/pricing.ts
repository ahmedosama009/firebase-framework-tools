// In a real app, this would be a call to Firestore.
// For now, it's a mock that simulates a network request.
import { PricingPlan } from "@/lib/types";

const mockPricingPlans: PricingPlan[] = [
    {
        id: "plan_basic",
        name: "الباقة الأساسية",
        description: "مثالية للشركات الناشئة التي تبدأ رحلتها الرقمية.",
        price: "1,999",
        priceUnit: "جنيه/شهرياً",
        features: [
            "إدارة حسابين سوشيال ميديا",
            "8 تصاميم شهرياً",
            "خطة محتوى شهرية",
            "تقرير أداء أساسي"
        ],
        limits: {
            spaces: 5,
            assistants: 2,
            teamMembers: 1,
            aiInteractions: 500
        },
        isPopular: false,
        colorClass: "bg-blue-500",
    },
    {
        id: "plan_pro",
        name: "الباقة الاحترافية",
        description: "للشركات النامية التي تسعى لتوسيع نطاقها.",
        price: "3,499",
        priceUnit: "جنيه/شهرياً",
        features: [
            "إدارة 3 حسابات سوشيال ميديا",
            "15 تصميم شهرياً",
            "حملة إعلانية واحدة (غير شاملة الميزانية)",
            "تقرير أداء تفصيلي"
        ],
        limits: {
            spaces: 20,
            assistants: 4,
            teamMembers: 5,
            aiInteractions: 2000
        },
        isPopular: true,
        isCurrent: true, // Mock that this is the current plan
        colorClass: "bg-purple-600",
    },
    {
        id: "plan_enterprise",
        name: "باقة الشركات",
        description: "حلول متكاملة مصممة خصيصًا للشركات الكبيرة.",
        price: "تواصل معنا",
        priceUnit: "",
        features: [
            "إدارة +4 حسابات سوشيال ميديا",
            "تصاميم ومحتوى مخصص",
            "إدارة حملات إعلانية متقدمة",
            "تحليل سوق ومنافسين"
        ],
        limits: {
            spaces: 'unlimited',
            assistants: 'unlimited',
            teamMembers: 'unlimited',
            aiInteractions: 'unlimited'
        },
        isPopular: false,
        colorClass: "bg-gray-800",
    }
];

export async function getPricingPlans(): Promise<PricingPlan[]> {
    // Simulate a network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockPricingPlans;
}
