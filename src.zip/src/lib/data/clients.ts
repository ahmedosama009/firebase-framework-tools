// src/lib/data/clients.ts
import { Client } from "@/lib/types";
import { db } from "@/lib/firebase";
import { collection, getDocs, doc, writeBatch, query } from "firebase/firestore";

const createMockClients = (companyId: string): Client[] => [
    { id: "CLT001", companyId, name: "شركة الأفق الجديد", email: "contact@newhorizon.com", status: "active", serviceType: "online", lastActivity: "2024-05-15" },
    { id: "CLT002", companyId, name: "مؤسسة القمة الرقمية", email: "info@digitalpeak.co", status: "active", serviceType: "offline", lastActivity: "2024-05-12" },
    { id: "CLT003", companyId, name: "حلول إبداع المتحدة", email: "support@creative-sol.net", status: "inactive", serviceType: "online", lastActivity: "2024-03-20" },
    { id: "CLT004", companyId, name: "رواد المستقبل للتجارة", email: "sales@futurepioneers.com", status: "active", serviceType: "online", lastActivity: "2024-05-18" },
    { id: "CLT005", companyId, name: "مجموعة الإنجاز العصري", email: "projects@modernachieve.com", status: "inactive", serviceType: "offline", lastActivity: "2024-01-30" },
    { id: "CLT006", companyId, name: "الشركة العالمية للتقنية", email: "tech@global-innov.com", status: "active", serviceType: "online", lastActivity: "2024-05-17" },
];

async function seedClients(companyId: string) {
    if (!companyId) return;
    const clientsCollectionRef = collection(db, "companies", companyId, "clients");
    const snapshot = await getDocs(query(clientsCollectionRef));

    if (snapshot.empty) {
        console.log(`Clients collection for company ${companyId} is empty, seeding data...`);
        const batch = writeBatch(db);
        const mockClients = createMockClients(companyId);
        mockClients.forEach((client) => {
            const docRef = doc(db, "companies", companyId, "clients", client.id);
            batch.set(docRef, client);
        });
        await batch.commit();
        console.log("Client seeding complete for company:", companyId);
    }
}

export async function getClients(companyId: string): Promise<Client[]> {
    if (!companyId) {
        console.error("Company ID is required to fetch clients.");
        return [];
    }

    try {
        await seedClients(companyId);
        const clientsCollectionRef = collection(db, "companies", companyId, "clients");
        const snapshot = await getDocs(clientsCollectionRef);
        const clients = snapshot.docs.map(doc => doc.data() as Client);
        return clients;
    } catch (error) {
        console.error("Error fetching clients from Firestore: ", error);
        return [];
    }
}
