
// In a real app, this would be a call to Firestore.
import { Service } from "@/lib/types";
import { db } from "@/lib/firebase";
import { collection, getDocs, doc, writeBatch, query } from "firebase/firestore";

const mockServices: Service[] = [
    {
        id: "SVC001",
        name: "باقة التسويق الرقمي",
        description: "إدارة متكاملة لحملاتك على وسائل التواصل الاجتماعي ومحركات البحث لزيادة الوعي بعلامتك التجارية وتحقيق أهدافك.",
        price: "تبدأ من 5,000 جنيه/شهرياً"
    },
    {
        id: "SVC002",
        name: "تصميم الهوية البصرية",
        description: "نصمم لك هوية بصرية فريدة تعكس قصة علامتك التجارية، تشمل الشعار، الألوان، والخطوط لتميزك في السوق.",
        price: "تبدأ من 8,000 جنيه"
    },
    {
        id: "SVC003",
        name: "إدارة حسابات التواصل",
        description: "إنشاء محتوى جذاب ونشره بانتظام على منصاتك الاجتماعية، مع التفاعل المستمر مع جمهورك لتعزيز الولاء.",
        price: "تبدأ من 3,500 جنيه/شهرياً"
    },
    {
        id: "SVC004",
        name: "كتابة المحتوى",
        description: "نصوص إبداعية وإعلانية للمواقع، المدونات، والحملات التسويقية، مصممة خصيصًا لجذب انتباه جمهورك المستهدف.",
        price: "تعتمد على المشروع"
    },
    {
        id: "SVC005",
        name: "تصوير المنتجات",
        description: "جلسات تصوير احترافية تبرز جمال منتجاتك وتزيد من جاذبيتها للمشترين المحتملين.",
        price: "تبدأ من 2,000 جنيه"
    }
];

// Function to add mock data to Firestore if the collection is empty for a specific company
async function seedServices(companyId: string) {
    if (!companyId) return;
    const servicesCollectionRef = collection(db, "companies", companyId, "services");
    const snapshot = await getDocs(query(servicesCollectionRef));
    if (snapshot.empty) {
        console.log(`Services collection for company ${companyId} is empty, seeding data...`);
        const batch = writeBatch(db);
        mockServices.forEach((service) => {
            const docRef = doc(db, "companies", companyId, "services", service.id);
            batch.set(docRef, service);
        });
        await batch.commit();
        console.log("Seeding complete for company:", companyId);
    }
}


export async function getServices(companyId: string): Promise<Service[]> {
    if (!companyId) {
        console.error("Company ID is required to fetch services.");
        return [];
    }

    try {
        await seedServices(companyId); // Seed data if needed
        const servicesCollectionRef = collection(db, "companies", companyId, "services");
        const snapshot = await getDocs(servicesCollectionRef);
        const services = snapshot.docs.map(doc => doc.data() as Service);
        return services;
    } catch (error) {
        console.error("Error fetching services from Firestore: ", error);
        // Fallback to mock data in case of error (optional)
        return [];
    }
}
