
'use server';

import { z } from 'zod';
import { leilaAISalesAssistant } from '@/ai/flows/leila-ai-sales-assistant';
import { generateContentForSpace } from '@/ai/flows/generate-content-for-space';
import { checkSignupReadiness } from '@/ai/flows/check-signup-readiness';
import { suggestTasksForSpace } from '@/ai/flows/suggest-tasks-for-space';
import { BrandIdentity } from './types';

const chatSchema = z.object({
  history: z.array(
    z.object({
      role: z.enum(['user', 'assistant']),
      content: z.string(),
    })
  ),
  query: z.string(),
  knowledgeBase: z.string().optional(),
});

export async function askLeila(prevState: any, formData: FormData) {
  const validatedFields = chatSchema.safeParse({
    history: JSON.parse(formData.get('history') as string || '[]'),
    query: formData.get('query'),
    knowledgeBase: formData.get('knowledgeBase')
  });

  if (!validatedFields.success) {
    return {
      response: 'Invalid input.',
    };
  }

  try {
    const { history, query, knowledgeBase } = validatedFields.data;
    const result = await leilaAISalesAssistant({
      query,
      history,
      knowledgeBase,
      language: 'ar',
    });
    return { response: result.response };
  } catch (error) {
    console.error(error);
    return {
      response: 'عذراً، حدث خطأ ما. يرجى المحاولة مرة أخرى.',
    };
  }
}

const generateContentSchema = z.object({
  spaceDescription: z.string(),
  brandIdentity: z.any(),
});

export async function generateSpaceContent(description: string, brandIdentity: BrandIdentity) {
    if (!description || !brandIdentity) {
        throw new Error("Missing description or brand identity");
    }

    try {
        const result = await generateContentForSpace({
            spaceDescription: description,
            brandIdentity: brandIdentity,
        });
        return result.generatedContent;
    } catch (error) {
        console.error(error);
        throw new Error("Failed to generate content.");
    }
}


const signupReadinessSchema = z.object({
    history: z.array(
      z.object({
        role: z.enum(['user', 'assistant']),
        content: z.string(),
      })
    ),
  });
  
  export async function checkSignupReadinessAction(prevState: any, formData: FormData) {
    const validatedFields = signupReadinessSchema.safeParse({
      history: JSON.parse(formData.get('history') as string || '[]'),
    });
  
    if (!validatedFields.success) {
      return { isReadyForSignup: false, error: 'Invalid history' };
    }
  
    try {
      const { history } = validatedFields.data;
      const result = await checkSignupReadiness({ history });
      // In a real app, you would now save the user to the database if isReadyForSignup is true
      return result;
    } catch (error) {
      console.error(error);
      return { isReadyForSignup: false, error: 'AI check failed' };
    }
  }

export async function suggestTasksForSpaceAction(spaceDescription: string, generatedContent?: string) {
    if (!spaceDescription) {
        throw new Error("Missing Space description");
    }

    try {
        const result = await suggestTasksForSpace({
            spaceDescription,
            generatedContent,
        });
        return result.tasks;
    } catch (error) {
        console.error(error);
        throw new Error("Failed to suggest tasks.");
    }
}
