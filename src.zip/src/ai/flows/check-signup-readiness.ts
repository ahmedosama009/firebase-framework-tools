
'use server';

/**
 * @fileOverview An AI agent that checks if a conversation contains enough information to sign up a new user.
 *
 * - checkSignupReadiness - A function that handles the signup readiness check.
 * - CheckSignupReadinessInput - The input type for the checkSignupReadiness function.
 * - CheckSignupReadinessOutput - The return type for the checkSignupReadiness function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import crypto from 'crypto-js';

const CheckSignupReadinessInputSchema = z.object({
  history: z.array(z.object({
    role: z.enum(['user', 'assistant']),
    content: z.string(),
  })).describe('The full conversation history between the user and the assistant.'),
});
export type CheckSignupReadinessInput = z.infer<typeof CheckSignupReadinessInputSchema>;

const CheckSignupReadinessOutputSchema = z.object({
  isReadyForSignup: z.boolean().describe("Set to true if you have extracted the user's full name, email, and company name from the conversation. Otherwise, set to false."),
  fullName: z.string().optional().describe("The user's full name, extracted from the conversation."),
  email: z.string().optional().describe("The user's email address, extracted from the conversation."),
  companyName: z.string().optional().describe("The user's company name, extracted from the conversation."),
  gravatarUrl: z.string().optional().describe("The generated Gravatar URL for the user's email."),
});
export type CheckSignupReadinessOutput = z.infer<typeof CheckSignupReadinessOutputSchema>;

export async function checkSignupReadiness(input: CheckSignupReadinessInput): Promise<CheckSignupReadinessOutput> {
  return checkSignupReadinessFlow(input);
}

const prompt = ai.definePrompt({
  name: 'checkSignupReadinessPrompt',
  input: { schema: CheckSignupReadinessInputSchema },
  output: { schema: CheckSignupReadinessOutputSchema },
  prompt: `You are an expert data extraction agent. Your task is to analyze a conversation and determine if a user has provided enough information to create an account for them.

To create an account, you MUST have the following three pieces of information:
1.  User's Full Name
2.  User's Email Address
3.  User's Company Name

Review the conversation history provided below.

Conversation History:
{{#each history}}
  {{role}}: {{content}}
{{/each}}

Analyze the conversation and extract the required information. If you have successfully extracted all three pieces of information, set 'isReadyForSignup' to true and fill in the 'fullName', 'email', and 'companyName' fields. If any of the information is missing, set 'isReadyForSignup' to false.

Do not make up information. Only use what is explicitly provided in the conversation.
`,
});

const checkSignupReadinessFlow = ai.defineFlow(
  {
    name: 'checkSignupReadinessFlow',
    inputSchema: CheckSignupReadinessInputSchema,
    outputSchema: CheckSignupReadinessOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);

    if (output && output.isReadyForSignup && output.email) {
        const trimmedEmail = output.email.trim().toLowerCase();
        const hash = crypto.MD5(trimmedEmail).toString();
        output.gravatarUrl = `https://www.gravatar.com/avatar/${hash}?d=identicon`;
    }

    return output!;
  }
);
