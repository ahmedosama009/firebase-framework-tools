
'use server';
/**
 * @fileOverview AI Sales Assistant flow for handling onboarding and service selection inquiries.
 *
 * - leilaAISalesAssistant - A function that handles the sales assistant conversation.
 * - LeilaAISalesAssistantInput - The input type for the leilaAISalesAssistant function.
 * - LeilaAISalesAssistantOutput - The return type for the leilaAISalesAssistant function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const LeilaAISalesAssistantInputSchema = z.object({
  query: z.string().describe('The user query about onboarding or service selection.'),
  language: z.enum(['ar', 'en']).default('ar').describe('The preferred language for the response (Arabic or English).'),
  knowledgeBase: z.string().optional().describe('A knowledge base with critical information about the company, its products, and guidelines.'),
  history: z.array(z.object({
    role: z.enum(['user', 'assistant']),
    content: z.string(),
  })).optional().describe('The conversation history.'),
});
export type LeilaAISalesAssistantInput = z.infer<typeof LeilaAISalesAssistantInputSchema>;

const LeilaAISalesAssistantOutputSchema = z.object({
  response: z.string().describe('The AI assistant response to the user query.'),
});
export type LeilaAISalesAssistantOutput = z.infer<typeof LeilaAISalesAssistantOutputSchema>;

export async function leilaAISalesAssistant(input: LeilaAISalesAssistantInput): Promise<LeilaAISalesAssistantOutput> {
  return leilaAISalesAssistantFlow(input);
}

const prompt = ai.definePrompt({
  name: 'leilaAISalesAssistantPrompt',
  input: {schema: LeilaAISalesAssistantInputSchema},
  output: {schema: LeilaAISalesAssistantOutputSchema},
  prompt: `You are Leila, an AI sales assistant for AlKayan AI Hub. You are visible to users before login.
Your primary goal is to answer onboarding and service selection questions, helping potential users quickly understand the platform's capabilities and determine if it meets their needs.

You are fluent in both Arabic and English. Respond in the user's preferred language ({{language}}), but default to Arabic if not specified.
If the user's query is out of your scope or requires a transfer to a human assistant, indicate that you will transfer the conversation.

{{#if knowledgeBase}}
### Company Knowledge Base ###
You MUST use the following information as your primary source of truth to answer questions.
"""
{{{knowledgeBase}}}
"""
{{/if}}

Here's the conversation history:
{{#each history}}
  {{role}}: {{content}}
{{/each}}

User query: {{{query}}}`,
});

const leilaAISalesAssistantFlow = ai.defineFlow(
  {
    name: 'leilaAISalesAssistantFlow',
    inputSchema: LeilaAISalesAssistantInputSchema,
    outputSchema: LeilaAISalesAssistantOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
