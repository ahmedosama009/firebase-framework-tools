
'use server';

/**
 * @fileOverview AI agent that suggests a list of tasks based on a "Space" description.
 *
 * - suggestTasksForSpace - A function that suggests tasks for a given space.
 * - SuggestTasksForSpaceInput - The input type for the function.
 * - SuggestTasksForSpaceOutput - The return type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const TaskSchema = z.object({
  title: z.string().describe('A clear, actionable title for the task.'),
});

const SuggestTasksForSpaceInputSchema = z.object({
  spaceDescription: z.string().describe('A detailed description of the marketing campaign or space.'),
  generatedContent: z.string().optional().describe('The AI-generated content for the space, if available.'),
});
export type SuggestTasksForSpaceInput = z.infer<typeof SuggestTasksForSpaceInputSchema>;

const SuggestTasksForSpaceOutputSchema = z.object({
  tasks: z.array(TaskSchema).describe('A list of suggested tasks to execute the campaign.'),
});
export type SuggestTasksForSpaceOutput = z.infer<typeof SuggestTasksForSpaceOutputSchema>;

export async function suggestTasksForSpace(input: SuggestTasksForSpaceInput): Promise<SuggestTasksForSpaceOutput> {
  return suggestTasksForSpaceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestTasksForSpacePrompt',
  input: { schema: SuggestTasksForSpaceInputSchema },
  output: { schema: SuggestTasksForSpaceOutputSchema },
  prompt: `You are an expert project manager for a marketing agency. Your job is to break down a campaign idea into a list of actionable tasks for the team.

Analyze the campaign description and any provided content below. Based on this information, generate a list of specific, actionable tasks needed to bring this campaign to life.

Campaign Description:
{{{spaceDescription}}}

{{#if generatedContent}}
Generated Content / Ideas:
{{{generatedContent}}}
{{/if}}

Generate a list of tasks. The tasks should be clear and concise.
`,
});

const suggestTasksForSpaceFlow = ai.defineFlow(
  {
    name: 'suggestTasksForSpaceFlow',
    inputSchema: SuggestTasksForSpaceInputSchema,
    outputSchema: SuggestTasksForSpaceOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
