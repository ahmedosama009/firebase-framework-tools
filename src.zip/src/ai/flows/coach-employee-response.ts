
'use server';
/**
 * @fileOverview An AI coaching agent that reviews employee responses to customers.
 *
 * - coachEmployeeResponse - A function that provides feedback on an employee's response.
 * - CoachEmployeeResponseInput - The input type for the coachEmployeeResponse function.
 * - CoachEmployeeResponseOutput - The return type for the coachEmployeeResponse function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const BrandIdentitySchema = z.object({
  tone: z.string().describe('The desired tone of the content (e.g., professional, friendly, humorous).'),
  style: z.string().describe('The desired writing style (e.g., formal, informal, persuasive).'),
  language: z.string().describe('The preferred language for the content (e.g., Arabic, English).'),
  companyDescription: z.string().describe('Description of the company.'),
  companyName: z.string().describe('The name of the company.'),
  knowledgeBase: z.string().describe('A knowledge base with critical information about the company, its products, and guidelines.'),
  logoUrl: z.string().optional(),
  aiPolicy: z.object({
    reviewRequired: z.boolean(),
    enableImages: z.boolean(),
    enableCodeGeneration: z.boolean(),
    guardLevel: z.enum(['none', 'low', 'medium', 'high']),
  }).optional(),
});

const CoachEmployeeResponseInputSchema = z.object({
  customerQuery: z.string().describe('The original message or query from the customer.'),
  employeeResponse: z.string().describe("The employee's proposed response to the customer."),
  conversationHistory: z.array(z.object({
    role: z.enum(['user', 'assistant']),
    content: z.string(),
  })).optional().describe('The conversation history with the customer.'),
  brandIdentity: BrandIdentitySchema,
});
export type CoachEmployeeResponseInput = z.infer<typeof CoachEmployeeResponseInputSchema>;

const CoachEmployeeResponseOutputSchema = z.object({
  feedback: z.string().describe("Constructive feedback for the employee regarding their response."),
  isApproved: z.boolean().describe("Whether the employee's response is approved to be sent as is."),
  suggestedImprovement: z.string().optional().describe("An improved version of the response, if applicable."),
});
export type CoachEmployeeResponseOutput = z.infer<typeof CoachEmployeeResponseOutputSchema>;


export async function coachEmployeeResponse(input: CoachEmployeeResponseInput): Promise<CoachEmployeeResponseOutput> {
  return coachEmployeeResponseFlow(input);
}

const prompt = ai.definePrompt({
  name: 'coachEmployeeResponsePrompt',
  input: {schema: CoachEmployeeResponseInputSchema},
  output: {schema: CoachEmployeeResponseOutputSchema},
  prompt: `You are an expert AI Communication Coach named "K". Your role is to review responses written by customer service agents to ensure they are professional, on-brand, accurate, and effective.

### Brand Identity & Knowledge Base ###
You must adhere to the following brand guidelines and knowledge base.
Company Name: {{{brandIdentity.companyName}}}
Company Description: {{{brandIdentity.companyDescription}}}
Tone: {{{brandIdentity.tone}}}
Style: {{{brandIdentity.style}}}
Language: {{{brandIdentity.language}}}

Knowledge Base: 
"""
{{{brandIdentity.knowledgeBase}}}
"""

### Task ###
Review the employee's response to the customer's query, considering the conversation history.

**Conversation History:**
{{#each conversationHistory}}
  {{role}}: {{content}}
{{/each}}

**Customer's Latest Query:**
"{{{customerQuery}}}"

**Employee's Proposed Response:**
"{{{employeeResponse}}}"

### Your Analysis ###
1.  **Assess Quality:** Evaluate the response based on tone, style, clarity, accuracy, and empathy.
2.  **Check Brand Alignment:** Does the response align with the company's brand identity ({{{brandIdentity.tone}}}, {{{brandIdentity.style}}})?
3.  **Provide Feedback:** Give concise, constructive feedback to the employee. Start by acknowledging something positive, then provide suggestions for improvement.
4.  **Approve or Suggest:**
    - If the response is excellent and needs no changes, set \`isApproved\` to true and provide positive feedback.
    - If the response is good but could be slightly better, set \`isApproved\` to true, provide feedback, and offer a \`suggestedImprovement\`.
    - If the response has significant issues (e.g., incorrect information, wrong tone), set \`isApproved\` to false, explain why in the feedback, and provide a corrected \`suggestedImprovement\`.

Your feedback should be encouraging and educational, helping the employee grow.
`,
});

const coachEmployeeResponseFlow = ai.defineFlow(
  {
    name: 'coachEmployeeResponseFlow',
    inputSchema: CoachEmployeeResponseInputSchema,
    outputSchema: CoachEmployeeResponseOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    return output!;
  }
);
