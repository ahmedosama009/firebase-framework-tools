
'use server';

/**
 * @fileOverview AI content generation for a given "Space" (service/offering).  The
 * content is generated based on the space's description and the brand identity
 * of the company that owns the space, including AI safety policies.
 *
 * - generateContentForSpace - A function that handles the content generation process.
 * - GenerateContentForSpaceInput - The input type for the generateContentForSpace function.
 * - GenerateContentForSpaceOutput - The return type for the generateContentForSpace function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateContentForSpaceInputSchema = z.object({
  spaceDescription: z
    .string()
    .describe('A detailed description of the service or offering.'),
  brandIdentity:
    z.object({
      tone: z.string().describe('The desired tone of the content (e.g., professional, friendly, humorous).'),
      style: z.string().describe('The desired writing style (e.g., formal, informal, persuasive).'),
      language: z.string().describe('The preferred language for the content (e.g., Arabic, English).'),
      companyDescription: z.string().describe('Description of the company.'),
      companyName: z.string().describe('The name of the company.'),
      knowledgeBase: z.string().describe('A knowledge base with critical information about the company, its products, and guidelines.'),
      logoUrl: z.string().optional(),
      aiPolicy: z.object({
        reviewRequired: z.boolean(),
        enableImages: z.boolean(),
        enableCodeGeneration: z.boolean(),
        guardLevel: z.enum(['none', 'low', 'medium', 'high']),
      }).optional(),
    })
    .describe('The brand identity to be reflected in the generated content.'),
});
export type GenerateContentForSpaceInput = z.infer<typeof GenerateContentForSpaceInputSchema>;

const GenerateContentForSpaceOutputSchema = z.object({
  generatedContent: z.string().describe('The AI-generated content for the space.'),
});
export type GenerateContentForSpaceOutput = z.infer<typeof GenerateContentForSpaceOutputSchema>;

export async function generateContentForSpace(input: GenerateContentForSpaceInput): Promise<GenerateContentForSpaceOutput> {
  return generateContentForSpaceFlow(input);
}

const safetyLevelMap = {
  'none': 'BLOCK_NONE',
  'low': 'BLOCK_ONLY_HIGH',
  'medium': 'BLOCK_MEDIUM_AND_ABOVE',
  'high': 'BLOCK_LOW_AND_ABOVE',
} as const;

const prompt = ai.definePrompt({
  name: 'generateContentForSpacePrompt',
  input: {schema: GenerateContentForSpaceInputSchema},
  output: {schema: GenerateContentForSpaceOutputSchema},
  prompt: `You are an AI assistant specialized in generating content for services and offerings, also known as "Spaces". You generate content that respects the brand identity of the company.

  ### Brand Identity & Knowledge Base ###
  Company Name: {{{brandIdentity.companyName}}}
  Company Description: {{{brandIdentity.companyDescription}}}
  Tone: {{{brandIdentity.tone}}}
  Style: {{{brandIdentity.style}}}
  Language: {{{brandIdentity.language}}}
  
  Critical Knowledge Base: 
  """
  {{{brandIdentity.knowledgeBase}}}
  """
  You MUST adhere to the information and guidelines provided in the Knowledge Base.

  ### Task ###
  Generate content for the following service/offering:
  {{{spaceDescription}}}

  {{#if brandIdentity.aiPolicy.enableCodeGeneration}}
  You are allowed to generate code snippets if relevant.
  {{else}}
  You are not allowed to generate code snippets.
  {{/if}}
  `,
});

const generateContentForSpaceFlow = ai.defineFlow(
  {
    name: 'generateContentForSpaceFlow',
    inputSchema: GenerateContentForSpaceInputSchema,
    outputSchema: GenerateContentForSpaceOutputSchema,
  },
  async input => {
    const safetyLevel = input.brandIdentity.aiPolicy?.guardLevel || 'high';
    const threshold = safetyLevelMap[safetyLevel];
    
    const {output} = await prompt(input, {
        config: {
            safetySettings: [
                { category: 'HARM_CATEGORY_HATE_SPEECH', threshold },
                { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold },
                { category: 'HARM_CATEGORY_HARASSMENT', threshold },
                { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold },
            ]
        }
    });

    return output!;
  }
);
