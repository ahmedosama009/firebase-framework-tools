import { config } from 'dotenv';
config();

import '@/ai/flows/leila-ai-sales-assistant.ts';
import '@/ai/flows/generate-content-for-space.ts';
import '@/ai/flows/coach-employee-response.ts';
import '@/ai/flows/check-signup-readiness.ts';
import '@/ai/flows/suggest-tasks-for-space.ts';
